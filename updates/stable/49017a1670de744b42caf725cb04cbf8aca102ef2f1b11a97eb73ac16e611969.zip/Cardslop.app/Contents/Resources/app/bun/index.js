// @bun
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __hasOwnProp = Object.prototype.hasOwnProperty;
function __accessProp(key) {
  return this[key];
}
var __toCommonJS = (from) => {
  var entry = (__moduleCache ??= new WeakMap).get(from), desc;
  if (entry)
    return entry;
  entry = __defProp({}, "__esModule", { value: true });
  if (from && typeof from === "object" || typeof from === "function") {
    for (var key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(entry, key))
        __defProp(entry, key, {
          get: __accessProp.bind(from, key),
          enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
  }
  __moduleCache.set(from, entry);
  return entry;
};
var __moduleCache;
var __returnValue = (v) => v;
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {
      get: all[name],
      enumerable: true,
      configurable: true,
      set: __exportSetter.bind(all, name)
    });
};
var __esm = (fn, res) => () => (fn && (res = fn(fn = 0)), res);
var __require = import.meta.require ?? /* @__PURE__ */ ((x) => typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (import.meta.require ?? globalThis.__ctMetaRequire ?? globalThis.require ?? a)[b]
}) : x)(function(x) {
  const r = import.meta.require ?? globalThis.__ctMetaRequire ?? globalThis.require;
  if (r)
    return r.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});

// .hutch/devkit/api/sdks/main/events/event.ts
class ElectrobunEvent {
  name;
  data;
  _response;
  responseWasSet = false;
  constructor(name, data) {
    this.name = name;
    this.data = data;
  }
  get response() {
    return this._response;
  }
  set response(value) {
    this._response = value;
    this.responseWasSet = true;
  }
  clearResponse() {
    this._response = undefined;
    this.responseWasSet = false;
  }
}

// .hutch/devkit/api/sdks/main/events/windowEvents.ts
var windowEvents_default;
var init_windowEvents = __esm(() => {
  windowEvents_default = {
    close: (data) => new ElectrobunEvent("close", data),
    willClose: (data) => new ElectrobunEvent("will-close", data),
    resize: (data) => new ElectrobunEvent("resize", data),
    move: (data) => new ElectrobunEvent("move", data),
    focus: (data) => new ElectrobunEvent("focus", data),
    blur: (data) => new ElectrobunEvent("blur", data),
    keyDown: (data) => new ElectrobunEvent("keyDown", data),
    keyUp: (data) => new ElectrobunEvent("keyUp", data)
  };
});

// .hutch/devkit/api/sdks/main/events/webviewEvents.ts
var webviewEvents_default;
var init_webviewEvents = __esm(() => {
  webviewEvents_default = {
    willNavigate: (data) => new ElectrobunEvent("will-navigate", data),
    didNavigate: (data) => new ElectrobunEvent("did-navigate", data),
    didNavigateInPage: (data) => new ElectrobunEvent("did-navigate-in-page", data),
    didCommitNavigation: (data) => new ElectrobunEvent("did-commit-navigation", data),
    domReady: (data) => new ElectrobunEvent("dom-ready", data),
    newWindowOpen: (data) => new ElectrobunEvent("new-window-open", data),
    hostMessage: (data) => new ElectrobunEvent("host-message", data),
    downloadStarted: (data) => new ElectrobunEvent("download-started", data),
    downloadProgress: (data) => new ElectrobunEvent("download-progress", data),
    downloadCompleted: (data) => new ElectrobunEvent("download-completed", data),
    downloadFailed: (data) => new ElectrobunEvent("download-failed", data)
  };
});

// .hutch/devkit/api/sdks/main/events/trayEvents.ts
var trayEvents_default;
var init_trayEvents = __esm(() => {
  trayEvents_default = {
    trayClicked: (data) => new ElectrobunEvent("tray-clicked", data)
  };
});

// .hutch/devkit/api/sdks/main/events/ApplicationEvents.ts
var ApplicationEvents_default;
var init_ApplicationEvents = __esm(() => {
  ApplicationEvents_default = {
    applicationMenuClicked: (data) => new ElectrobunEvent("application-menu-clicked", data),
    contextMenuClicked: (data) => new ElectrobunEvent("context-menu-clicked", data),
    openUrl: (data) => new ElectrobunEvent("open-url", data),
    reopen: (data) => new ElectrobunEvent("reopen", data),
    beforeQuit: (data) => new ElectrobunEvent("before-quit", data)
  };
});

// .hutch/devkit/api/sdks/main/events/eventEmitter.ts
import EventEmitter from "events";
var ElectrobunEventEmitter, electrobunEventEmitter, eventEmitter_default;
var init_eventEmitter = __esm(() => {
  init_windowEvents();
  init_webviewEvents();
  init_trayEvents();
  init_ApplicationEvents();
  ElectrobunEventEmitter = class ElectrobunEventEmitter extends EventEmitter {
    constructor() {
      super();
    }
    emitEvent(ElectrobunEvent2, specifier) {
      if (specifier) {
        this.emit(`${ElectrobunEvent2.name}-${specifier}`, ElectrobunEvent2);
      } else {
        this.emit(ElectrobunEvent2.name, ElectrobunEvent2);
      }
    }
    events = {
      window: {
        ...windowEvents_default
      },
      webview: {
        ...webviewEvents_default
      },
      tray: {
        ...trayEvents_default
      },
      app: {
        ...ApplicationEvents_default
      }
    };
  };
  electrobunEventEmitter = new ElectrobunEventEmitter;
  eventEmitter_default = electrobunEventEmitter;
});

// .hutch/devkit/api/shared/rpc.ts
function missingTransportMethodError(methods, action) {
  const methodsString = methods.map((m) => `"${m}"`).join(", ");
  return new Error(`This RPC instance cannot ${action} because the transport did not provide one or more of these methods: ${methodsString}`);
}
function createRPC(options = {}) {
  let debugHooks = {};
  let transport = {};
  let requestHandler = undefined;
  function setTransport(newTransport) {
    if (transport.unregisterHandler)
      transport.unregisterHandler();
    transport = newTransport;
    transport.registerHandler?.(handler);
  }
  function setRequestHandler(h) {
    if (typeof h === "function") {
      requestHandler = h;
      return;
    }
    requestHandler = (method, params) => {
      const handlerFn = h[method];
      if (handlerFn)
        return handlerFn(params);
      const fallbackHandler = h._;
      if (!fallbackHandler)
        throw new Error(`The requested method has no handler: ${String(method)}`);
      return fallbackHandler(method, params);
    };
  }
  const { maxRequestTime = DEFAULT_MAX_REQUEST_TIME } = options;
  if (options.transport)
    setTransport(options.transport);
  if (options.requestHandler)
    setRequestHandler(options.requestHandler);
  if (options._debugHooks)
    debugHooks = options._debugHooks;
  let lastRequestId = 0;
  function getRequestId() {
    if (lastRequestId <= MAX_ID)
      return ++lastRequestId;
    return lastRequestId = 0;
  }
  const requestListeners = new Map;
  const requestTimeouts = new Map;
  const requestDeadlines = new Map;
  function startRequestTimeout(requestId, requestOptions) {
    const requestMaxRequestTime = requestOptions?.maxRequestTime ?? maxRequestTime;
    if (requestMaxRequestTime === Infinity || !requestListeners.has(requestId))
      return;
    requestDeadlines.set(requestId, performance.now() + requestMaxRequestTime);
    requestTimeouts.set(requestId, setTimeout(() => {
      requestTimeouts.delete(requestId);
      requestDeadlines.delete(requestId);
      const listener = requestListeners.get(requestId);
      requestListeners.delete(requestId);
      listener?.reject(new Error("RPC request timed out."));
    }, requestMaxRequestTime));
  }
  function rejectRequestSend(requestId, error) {
    const listener = requestListeners.get(requestId);
    if (!listener)
      return;
    requestListeners.delete(requestId);
    listener.reject(error instanceof Error ? error : new Error(String(error)));
  }
  function requestFn(method, ...args) {
    const params = args[0];
    const requestOptions = args[1];
    return new Promise((resolve, reject) => {
      if (!transport.send)
        throw missingTransportMethodError(["send"], "make requests");
      const requestId = getRequestId();
      const request2 = {
        type: "request",
        id: requestId,
        method,
        params
      };
      requestListeners.set(requestId, { resolve, reject });
      try {
        debugHooks.onSend?.(request2);
        const sendResult = transport.send(request2);
        if (sendResult && typeof sendResult.then === "function") {
          Promise.resolve(sendResult).then(() => startRequestTimeout(requestId, requestOptions), (error) => rejectRequestSend(requestId, error));
        } else {
          startRequestTimeout(requestId, requestOptions);
        }
      } catch (error) {
        rejectRequestSend(requestId, error);
      }
    });
  }
  const request = new Proxy(requestFn, {
    get: (target, prop, receiver) => {
      if (prop in target)
        return Reflect.get(target, prop, receiver);
      return (params, requestOptions) => requestFn(prop, params, requestOptions);
    }
  });
  const requestProxy = request;
  function sendFn(message, ...args) {
    const payload = args[0];
    if (!transport.send)
      throw missingTransportMethodError(["send"], "send messages");
    const rpcMessage = {
      type: "message",
      id: message,
      payload
    };
    debugHooks.onSend?.(rpcMessage);
    return transport.send(rpcMessage);
  }
  const send = new Proxy(sendFn, {
    get: (target, prop, receiver) => {
      if (prop in target)
        return Reflect.get(target, prop, receiver);
      return (payload) => sendFn(prop, payload);
    }
  });
  const sendProxy = send;
  const messageListeners = new Map;
  const wildcardMessageListeners = new Set;
  function addMessageListener(message, listener) {
    if (!transport.registerHandler)
      throw missingTransportMethodError(["registerHandler"], "register message listeners");
    if (message === "*") {
      wildcardMessageListeners.add(listener);
      return;
    }
    if (!messageListeners.has(message))
      messageListeners.set(message, new Set);
    messageListeners.get(message).add(listener);
  }
  function removeMessageListener(message, listener) {
    if (message === "*") {
      wildcardMessageListeners.delete(listener);
      return;
    }
    messageListeners.get(message)?.delete(listener);
    if (messageListeners.get(message)?.size === 0)
      messageListeners.delete(message);
  }
  async function handler(message) {
    debugHooks.onReceive?.(message);
    if (!("type" in message))
      throw new Error("Message does not contain a type.");
    if (message.type === "request") {
      if (!transport.send || !requestHandler)
        throw missingTransportMethodError(["send", "requestHandler"], "handle requests");
      const { id, method, params } = message;
      let response;
      try {
        response = {
          type: "response",
          id,
          success: true,
          payload: await requestHandler(method, params)
        };
      } catch (error) {
        if (!(error instanceof Error))
          throw error;
        response = {
          type: "response",
          id,
          success: false,
          error: error.message
        };
      }
      debugHooks.onSend?.(response);
      transport.send(response);
      return;
    }
    if (message.type === "response") {
      const timeout = requestTimeouts.get(message.id);
      if (timeout != null)
        clearTimeout(timeout);
      requestTimeouts.delete(message.id);
      const deadline = requestDeadlines.get(message.id);
      requestDeadlines.delete(message.id);
      const { resolve, reject } = requestListeners.get(message.id) ?? {};
      requestListeners.delete(message.id);
      if (deadline !== undefined && performance.now() >= deadline)
        reject?.(new Error("RPC request timed out."));
      else if (!message.success)
        reject?.(new Error(message.error));
      else
        resolve?.(message.payload);
      return;
    }
    if (message.type === "message") {
      for (const listener of wildcardMessageListeners)
        listener(message.id, message.payload);
      const listeners = messageListeners.get(message.id);
      if (!listeners)
        return;
      for (const listener of listeners)
        listener(message.payload);
      return;
    }
    throw new Error(`Unexpected RPC message type: ${message.type}`);
  }
  const proxy = { send: sendProxy, request: requestProxy };
  return {
    setTransport,
    setRequestHandler,
    request,
    requestProxy,
    send,
    sendProxy,
    addMessageListener,
    removeMessageListener,
    proxy
  };
}
function defineElectrobunRPC(_side, config) {
  const rpcOptions = {
    maxRequestTime: config.maxRequestTime,
    requestHandler: {
      ...config.handlers.requests,
      ...config.extraRequestHandlers
    },
    transport: {
      registerHandler: () => {}
    }
  };
  const rpc = createRPC(rpcOptions);
  const messageHandlers = config.handlers.messages;
  if (messageHandlers) {
    rpc.addMessageListener("*", (messageName, payload) => {
      const globalHandler = messageHandlers["*"];
      if (globalHandler) {
        globalHandler(messageName, payload);
      }
      const messageHandler = messageHandlers[messageName];
      if (messageHandler) {
        messageHandler(payload);
      }
    });
  }
  return rpc;
}
var MAX_ID = 10000000000, DEFAULT_MAX_REQUEST_TIME = 1000;

// .hutch/devkit/api/sdks/main/core/BuildConfig.ts
import { readFileSync } from "fs";
function isPackagedBuildChannel(channel) {
  return channel === "stable" || channel === "canary";
}
function withRuntimeMode(config, channel) {
  const resolvedChannel = channel === "stable" || channel === "canary" || channel === "dev" ? channel : "dev";
  return {
    ...config,
    buildEnvironment: resolvedChannel,
    channel: resolvedChannel,
    isPackaged: isPackagedBuildChannel(resolvedChannel)
  };
}
function fallbackBuildConfig() {
  return withRuntimeMode({
    defaultRenderer: "native",
    availableRenderers: ["native"]
  }, "dev");
}
var buildConfig = null, BuildConfig;
var init_BuildConfig = __esm(() => {
  BuildConfig = {
    get: async () => {
      if (buildConfig) {
        return buildConfig;
      }
      try {
        const resourcesDir = "Resources";
        const config = await Bun.file(`../${resourcesDir}/build.json`).json();
        let channel = "dev";
        try {
          const version = await Bun.file(`../${resourcesDir}/version.json`).json();
          channel = version.channel;
        } catch {}
        buildConfig = withRuntimeMode(config, channel);
        return buildConfig;
      } catch {
        buildConfig = fallbackBuildConfig();
        return buildConfig;
      }
    },
    getSync: () => {
      if (buildConfig) {
        return buildConfig;
      }
      try {
        const resourcesDir = "Resources";
        const config = JSON.parse(readFileSync(`../${resourcesDir}/build.json`, "utf8"));
        let channel = "dev";
        try {
          const version = JSON.parse(readFileSync(`../${resourcesDir}/version.json`, "utf8"));
          channel = version.channel;
        } catch {}
        buildConfig = withRuntimeMode(config, channel);
        return buildConfig;
      } catch {
        buildConfig = fallbackBuildConfig();
        return buildConfig;
      }
    },
    getCached: () => buildConfig
  };
});

// .hutch/devkit/api/sdks/main/core/hostTransportEncryption.ts
import { createCipheriv, randomBytes } from "crypto";
var encryptHostTransportPacket = (messageJson, secretKey) => {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", new Uint8Array(secretKey), new Uint8Array(iv));
  const encryptedData = cipher.update(messageJson, "utf8", "base64") + cipher.final("base64");
  return {
    encryptedData,
    iv: iv.toString("base64"),
    tag: cipher.getAuthTag().toString("base64")
  };
};
var init_hostTransportEncryption = () => {};

// .hutch/devkit/api/sdks/main/core/Socket.ts
var exports_Socket = {};
__export(exports_Socket, {
  sendMessageToWebviewViaSocket: () => sendMessageToWebviewViaSocket,
  removeSocketForWebview: () => removeSocketForWebview
});
var removeSocketForWebview = (webviewId) => {
  ffi.request.clearWebviewHostTransport({ id: webviewId });
}, sendMessageToWebviewViaSocket = (webviewId, message, secretKey, serialized = false) => {
  try {
    const messageJson = serialized ? message : JSON.stringify(message);
    if (process.platform === "linux" && secretKey?.byteLength === 32) {
      const encryptedPacket = encryptHostTransportPacket(messageJson, secretKey);
      if (ffi.request.sendPreEncryptedHostMessageToWebviewViaTransport({
        id: webviewId,
        encryptedPacketJson: JSON.stringify(encryptedPacket)
      })) {
        return true;
      }
    }
    return ffi.request.sendHostMessageToWebviewViaTransport({
      id: webviewId,
      messageJson
    });
  } catch (error) {
    console.error("Error sending message to webview via host transport:", error);
    return false;
  }
};
var init_Socket = __esm(() => {
  init_native();
  init_hostTransportEncryption();
});

// .hutch/devkit/api/sdks/main/core/BrowserView.ts
import { randomBytes as randomBytes2 } from "crypto";
function isRpcResponsePacket(message) {
  return typeof message === "object" && message !== null && message.type === "response";
}

class BrowserView {
  id = 0;
  hostWebviewId;
  windowId;
  renderer;
  url = null;
  html = null;
  preload = null;
  viewsRoot = null;
  allowedProtocols = {
    views: true,
    appData: false
  };
  partition = null;
  autoResize = true;
  frame = {
    x: 0,
    y: 0,
    width: 800,
    height: 600
  };
  secretKey;
  rpc;
  rpcHandler;
  hostMessageSendQueue = [];
  hostResponseSendQueue = [];
  flushingHostMessageSendQueue = false;
  hostMessageQueuedBytes = 0;
  hostMessageEnqueued = 0;
  hostMessageDrained = 0;
  hostMessagePeakQueuedBytes = 0;
  hostMessagePeakQueuedCount = 0;
  navigationRules = null;
  sandbox = false;
  startTransparent = false;
  startPassthrough = false;
  spellCheck = false;
  isRemoved = false;
  get ptr() {
    if (this.isRemoved) {
      return null;
    }
    return ffi.request.getWebviewPointer({ id: this.id });
  }
  constructor(options = defaultOptions) {
    this.url = options.url || defaultOptions.url || null;
    this.html = options.html || defaultOptions.html || null;
    this.preload = options.preload || defaultOptions.preload || null;
    this.viewsRoot = options.viewsRoot || defaultOptions.viewsRoot || null;
    this.allowedProtocols = {
      views: options.allowedProtocols?.views ?? true,
      appData: options.allowedProtocols?.appData ?? false
    };
    this.frame = {
      x: options.frame?.x ?? defaultOptions.frame.x,
      y: options.frame?.y ?? defaultOptions.frame.y,
      width: options.frame?.width ?? defaultOptions.frame.width,
      height: options.frame?.height ?? defaultOptions.frame.height
    };
    this.rpc = options.rpc;
    this.secretKey = new Uint8Array(randomBytes2(32));
    this.partition = options.partition || null;
    this.hostWebviewId = options.hostWebviewId;
    this.windowId = options.windowId ?? 0;
    this.autoResize = options.autoResize === false ? false : true;
    this.navigationRules = options.navigationRules || null;
    this.renderer = options.renderer ?? defaultOptions.renderer ?? "native";
    this.sandbox = options.sandbox ?? false;
    this.startTransparent = options.startTransparent ?? false;
    this.startPassthrough = options.startPassthrough ?? false;
    this.spellCheck = options.spellCheck ?? false;
    this.id = this.init();
    BrowserViewMap[this.id] = this;
    if (this.html) {
      setTimeout(() => {
        this.loadHTML(this.html);
      }, 100);
    }
  }
  init() {
    this.initializeRpcTransport();
    return ffi.request.createWebview({
      windowId: this.windowId,
      hostWebviewId: this.hostWebviewId ?? null,
      renderer: this.renderer,
      secretKey: this.secretKey.toString(),
      partition: this.partition,
      url: this.html ? null : this.url,
      preload: this.preload,
      viewsRoot: this.viewsRoot,
      allowedProtocols: this.allowedProtocols,
      frame: {
        width: this.frame.width,
        height: this.frame.height,
        x: this.frame.x,
        y: this.frame.y
      },
      autoResize: this.autoResize,
      navigationRules: this.navigationRules,
      sandbox: this.sandbox,
      startTransparent: this.startTransparent,
      startPassthrough: this.startPassthrough,
      spellCheck: this.spellCheck
    });
  }
  initializeRpcTransport() {
    if (!this.rpc) {
      this.rpc = BrowserView.defineRPC({
        handlers: { requests: {}, messages: {} }
      });
    }
    this.rpc.setTransport(this.createTransport());
  }
  sendHostMessageToWebviewViaExecute(jsonMessage) {
    const stringifiedMessage = typeof jsonMessage === "string" ? jsonMessage : JSON.stringify(jsonMessage);
    const wrappedMessage = `window.__electrobun.receiveMessageFromHost(${stringifiedMessage})`;
    this.executeJavascript(wrappedMessage);
  }
  sendHostMessagesToWebviewViaExecute(jsonMessages) {
    if (jsonMessages.length === 0)
      return;
    const wrappedMessages = jsonMessages.map((message) => `window.__electrobun.receiveMessageFromHost(${message});`).join(`
`);
    this.executeJavascript(wrappedMessages);
  }
  sendInternalHostMessageViaExecute(jsonMessage) {
    const stringifiedMessage = typeof jsonMessage === "string" ? jsonMessage : JSON.stringify(jsonMessage);
    const wrappedMessage = `window.__electrobun.receiveInternalMessageFromHost(${stringifiedMessage})`;
    this.executeJavascript(wrappedMessage);
  }
  executeJavascript(js) {
    if (!this.ptr || this.isRemoved) {
      return;
    }
    ffi.request.evaluateJavascriptWithNoCompletion({ id: this.id, js });
  }
  loadURL(url) {
    this.url = url;
    ffi.request.loadURLInWebView({ id: this.id, url: this.url });
  }
  loadHTML(html) {
    this.html = html;
    if (this.renderer === "cef") {
      ffi.request.setWebviewHTMLContent({ id: this.id, html });
      this.loadURL("views://internal/index.html");
    } else {
      ffi.request.loadHTMLInWebView({ id: this.id, html });
    }
  }
  setNavigationRules(rules) {
    this.navigationRules = JSON.stringify(rules);
    const rulesJson = JSON.stringify(rules);
    ffi.request.setWebviewNavigationRules({ id: this.id, rulesJson });
  }
  setSpellCheck(enabled) {
    this.spellCheck = enabled;
    return ffi.request.webviewSetSpellCheck({ id: this.id, enabled });
  }
  findInPage(searchText, options) {
    const forward = options?.forward ?? true;
    const matchCase = options?.matchCase ?? false;
    ffi.request.webviewFindInPage({
      id: this.id,
      searchText,
      forward,
      matchCase
    });
  }
  stopFindInPage() {
    ffi.request.webviewStopFind({ id: this.id });
  }
  openDevTools() {
    ffi.request.webviewOpenDevTools({ id: this.id });
  }
  closeDevTools() {
    ffi.request.webviewCloseDevTools({ id: this.id });
  }
  toggleDevTools() {
    ffi.request.webviewToggleDevTools({ id: this.id });
  }
  setPageZoom(zoomLevel) {
    ffi.request.webviewSetPageZoom({ id: this.id, zoomLevel });
  }
  getPageZoom() {
    return ffi.request.webviewGetPageZoom({ id: this.id });
  }
  on(name, handler) {
    const specificName = `${name}-${this.id}`;
    eventEmitter_default.on(specificName, handler);
  }
  createTransport = () => {
    const that = this;
    return {
      send(message) {
        return that.queueHostMessageToWebview(message);
      },
      registerHandler(handler) {
        if (that.isRemoved) {
          return;
        }
        that.rpcHandler = handler;
      }
    };
  };
  queueHostMessageToWebview(message) {
    return new Promise((markSent) => {
      if (!this.ptr || this.isRemoved) {
        markSent();
        return;
      }
      const queue = HOST_MESSAGE_RESPONSE_PRIORITY && isRpcResponsePacket(message) ? this.hostResponseSendQueue : this.hostMessageSendQueue;
      let serialized;
      try {
        serialized = JSON.stringify(message);
        if (serialized === undefined)
          throw new TypeError("RPC packet is not JSON serializable");
      } catch (error) {
        console.error("host: failed to serialize message to webview", error);
        markSent();
        return;
      }
      const bytes = Buffer.byteLength(serialized, "utf8");
      queue.push({ message: serialized, markSent, enqueuedAt: Date.now(), bytes });
      this.hostMessageQueuedBytes += bytes;
      this.hostMessageEnqueued++;
      this.hostMessagePeakQueuedBytes = Math.max(this.hostMessagePeakQueuedBytes, this.hostMessageQueuedBytes);
      this.hostMessagePeakQueuedCount = Math.max(this.hostMessagePeakQueuedCount, this.hostMessageSendQueue.length + this.hostResponseSendQueue.length);
      this.scheduleHostMessageFlush();
    });
  }
  hasQueuedHostMessages() {
    return this.hostResponseSendQueue.length > 0 || this.hostMessageSendQueue.length > 0;
  }
  takeQueuedHostMessageBatch() {
    const queue = this.hostResponseSendQueue.length > 0 ? this.hostResponseSendQueue : this.hostMessageSendQueue;
    let count = 0;
    let bytes = 0;
    while (count < queue.length && count < HOST_MESSAGE_SEND_BATCH_SIZE) {
      const nextBytes = queue[count].bytes;
      if (count > 0 && bytes + nextBytes > HOST_MESSAGE_SEND_BATCH_BYTES)
        break;
      bytes += nextBytes;
      count++;
    }
    this.hostMessageQueuedBytes -= bytes;
    this.hostMessageDrained += count;
    return queue.splice(0, count);
  }
  scheduleHostMessageFlush() {
    if (this.flushingHostMessageSendQueue)
      return;
    this.flushingHostMessageSendQueue = true;
    queueMicrotask(() => void this.flushHostMessageSendQueue());
  }
  sendQueuedHostMessageBatch(queuedMessages) {
    if (HOST_MESSAGE_SOCKET_AVAILABLE) {
      for (const queuedMessage of queuedMessages) {
        try {
          if (!sendMessageToWebviewViaSocket(this.id, queuedMessage.message, this.secretKey, true)) {
            this.sendHostMessageToWebviewViaExecute(queuedMessage.message);
          }
        } catch (error) {
          console.error("host: failed to send message to webview", error);
        } finally {
          queuedMessage.markSent();
        }
      }
      return;
    }
    try {
      this.sendHostMessagesToWebviewViaExecute(queuedMessages.map(({ message }) => message));
    } catch (error) {
      console.error("host: failed to send messages to webview", error);
    } finally {
      for (const { markSent } of queuedMessages)
        markSent();
    }
  }
  async flushHostMessageSendQueue() {
    try {
      let turnStarted = performance.now();
      while (this.hasQueuedHostMessages() && !this.isRemoved) {
        const batch = this.takeQueuedHostMessageBatch();
        this.sendQueuedHostMessageBatch(batch);
        if (this.hasQueuedHostMessages() && performance.now() - turnStarted >= HOST_MESSAGE_SEND_TURN_MS) {
          await new Promise((resolve) => setImmediate(resolve));
          turnStarted = performance.now();
        }
      }
    } finally {
      this.flushingHostMessageSendQueue = false;
      if (this.isRemoved) {
        this.resolveQueuedHostMessages();
      } else if (this.hasQueuedHostMessages()) {
        this.scheduleHostMessageFlush();
      }
    }
  }
  getHostMessageQueueStats() {
    const oldest = Math.min(this.hostMessageSendQueue[0]?.enqueuedAt ?? Infinity, this.hostResponseSendQueue[0]?.enqueuedAt ?? Infinity);
    return {
      queuedMessages: this.hostMessageSendQueue.length + this.hostResponseSendQueue.length,
      queuedBytes: this.hostMessageQueuedBytes,
      oldestMessageAgeMs: Number.isFinite(oldest) ? Math.max(0, Date.now() - oldest) : 0,
      enqueuedMessages: this.hostMessageEnqueued,
      drainedMessages: this.hostMessageDrained,
      peakQueuedMessages: this.hostMessagePeakQueuedCount,
      peakQueuedBytes: this.hostMessagePeakQueuedBytes
    };
  }
  resolveQueuedHostMessages() {
    this.hostMessageQueuedBytes = 0;
    const responses = this.hostResponseSendQueue;
    const messages = this.hostMessageSendQueue;
    this.hostResponseSendQueue = [];
    this.hostMessageSendQueue = [];
    for (const entry of responses)
      entry.markSent();
    for (const entry of messages)
      entry.markSent();
  }
  remove() {
    if (this.isRemoved) {
      return;
    }
    this.isRemoved = true;
    this.resolveQueuedHostMessages();
    delete BrowserViewMap[this.id];
    removeSocketForWebview(this.id);
    this.rpc?.setTransport({
      send() {},
      registerHandler() {},
      unregisterHandler() {}
    });
    this.rpcHandler = undefined;
    try {
      ffi.request.webviewRemove({ id: this.id });
    } catch (error) {
      console.error(`Error removing webview ${this.id}:`, error);
    }
  }
  static getById(id) {
    return BrowserViewMap[id];
  }
  static ensureWrapped(id, options = {}) {
    return BrowserViewMap[id] ?? BrowserView.adoptExisting(id, options);
  }
  static adoptExisting(id, options = {}) {
    const existing = BrowserViewMap[id];
    if (existing) {
      return existing;
    }
    const ptr = ffi.request.getWebviewPointer({ id });
    if (!ptr) {
      return;
    }
    const view = Object.create(BrowserView.prototype);
    view.id = id;
    view.hostWebviewId = options.hostWebviewId;
    view.windowId = options.windowId ?? 0;
    view.renderer = options.renderer ?? defaultOptions.renderer ?? "native";
    view.url = options.url ?? defaultOptions.url ?? null;
    view.html = options.html ?? defaultOptions.html ?? null;
    view.preload = options.preload ?? defaultOptions.preload ?? null;
    view.viewsRoot = options.viewsRoot ?? defaultOptions.viewsRoot ?? null;
    view.partition = options.partition ?? null;
    view.frame = {
      x: options.frame?.x ?? defaultOptions.frame.x,
      y: options.frame?.y ?? defaultOptions.frame.y,
      width: options.frame?.width ?? defaultOptions.frame.width,
      height: options.frame?.height ?? defaultOptions.frame.height
    };
    view.secretKey = new Uint8Array(0);
    view.rpc = options.rpc;
    view.rpcHandler = undefined;
    view.hostMessageSendQueue = [];
    view.hostResponseSendQueue = [];
    view.flushingHostMessageSendQueue = false;
    view.hostMessageQueuedBytes = 0;
    view.hostMessageEnqueued = 0;
    view.hostMessageDrained = 0;
    view.hostMessagePeakQueuedBytes = 0;
    view.hostMessagePeakQueuedCount = 0;
    view.autoResize = options.autoResize === false ? false : true;
    view.navigationRules = options.navigationRules ?? null;
    view.sandbox = options.sandbox ?? false;
    view.startTransparent = options.startTransparent ?? false;
    view.startPassthrough = options.startPassthrough ?? false;
    view.spellCheck = options.spellCheck ?? false;
    view.isRemoved = false;
    BrowserViewMap[id] = view;
    return view;
  }
  static getAll() {
    return Object.values(BrowserViewMap);
  }
  static on(name, handler) {
    eventEmitter_default.on(webviewTagCreatedEvent, handler);
    return () => BrowserView.off(name, handler);
  }
  static off(_name, handler) {
    eventEmitter_default.off(webviewTagCreatedEvent, handler);
  }
  static defineRPC(config) {
    return defineElectrobunRPC("bun", config);
  }
}
function emitWebviewTagBrowserViewCreated(view) {
  eventEmitter_default.emit(webviewTagCreatedEvent, view);
}
var BrowserViewMap, webviewTagCreatedEvent, HOST_MESSAGE_SEND_BATCH_SIZE = 256, HOST_MESSAGE_SEND_BATCH_BYTES, HOST_MESSAGE_SEND_TURN_MS = 8, HOST_MESSAGE_SOCKET_AVAILABLE, HOST_MESSAGE_RESPONSE_PRIORITY, buildConfig2, defaultOptions;
var init_BrowserView = __esm(() => {
  init_native();
  init_eventEmitter();
  init_BuildConfig();
  init_Socket();
  BrowserViewMap = {};
  webviewTagCreatedEvent = Symbol("webview-tag-browser-view-created");
  HOST_MESSAGE_SEND_BATCH_BYTES = 512 * 1024;
  HOST_MESSAGE_SOCKET_AVAILABLE = process.platform !== "win32";
  HOST_MESSAGE_RESPONSE_PRIORITY = process.platform === "linux";
  buildConfig2 = BuildConfig.getSync();
  defaultOptions = {
    url: null,
    html: null,
    preload: null,
    viewsRoot: null,
    allowedProtocols: { views: true, appData: false },
    renderer: buildConfig2.defaultRenderer,
    frame: {
      x: 0,
      y: 0,
      width: 800,
      height: 600
    }
  };
});

// .hutch/devkit/api/sdks/main/webgpuContextRegistry.ts
class WebgpuContextRegistry {
  contexts = new Map;
  lastCreatedContext = null;
  get size() {
    return this.contexts.size;
  }
  get(key) {
    return this.contexts.get(key);
  }
  set(key, entry) {
    if (this.contexts.has(key)) {
      throw new Error(`WebGPU context ${key} is already registered`);
    }
    this.contexts.set(key, entry);
    this.lastCreatedContext = entry.context;
  }
  release(key) {
    const entry = this.contexts.get(key);
    if (!entry)
      return false;
    this.contexts.delete(key);
    if (this.lastCreatedContext === entry.context) {
      this.lastCreatedContext = null;
      for (const remaining of this.contexts.values()) {
        this.lastCreatedContext = remaining.context;
      }
    }
    entry.teardown();
    return true;
  }
}
function createNativeWebgpuContext(ops, initialize) {
  const instance = Number(ops.createInstance());
  if (!instance)
    throw new Error("Failed to create WGPU instance");
  let surface = 0;
  try {
    surface = Number(ops.createSurface(instance));
    if (!surface)
      throw new Error("Failed to create WGPU surface");
    return initialize({ instance, surface });
  } catch (error) {
    releaseNativeWebgpuContext({ instance, surface }, ops);
    throw error;
  }
}
function releaseNativeWebgpuContext(entry, ops) {
  if (entry.surface) {
    try {
      ops.unconfigureSurface(entry.surface);
    } catch {}
    try {
      ops.releaseSurface(entry.surface);
    } catch {}
  }
  if (entry.instance) {
    try {
      ops.releaseInstance(entry.instance);
    } catch {}
  }
}
function registerWebgpuContextRelease(key, release) {
  contextReleaseHandlers.set(key, release);
}
function releaseWebgpuContext(key) {
  const release = contextReleaseHandlers.get(key);
  if (!release)
    return false;
  contextReleaseHandlers.delete(key);
  release();
  return true;
}
var contextReleaseHandlers;
var init_webgpuContextRegistry = __esm(() => {
  contextReleaseHandlers = new Map;
});

// .hutch/devkit/api/sdks/main/core/beforeRemoveHooks.ts
class BeforeRemoveHooks {
  hooks = new Set;
  didRun = false;
  subscribe(hook) {
    if (this.didRun)
      return () => {};
    this.hooks.add(hook);
    let subscribed = true;
    return () => {
      if (!subscribed)
        return;
      subscribed = false;
      this.hooks.delete(hook);
    };
  }
  run() {
    if (this.didRun)
      return [];
    this.didRun = true;
    const hooks = [...this.hooks];
    this.hooks.clear();
    const errors = [];
    for (const hook of hooks) {
      try {
        hook();
      } catch (error) {
        errors.push(error);
      }
    }
    return errors;
  }
}

// .hutch/devkit/api/sdks/main/core/WGPUView.ts
class WGPUView {
  id = 0;
  windowId;
  autoResize = true;
  frame = {
    x: 0,
    y: 0,
    width: 800,
    height: 600
  };
  startTransparent = false;
  startPassthrough = false;
  isRemoved = false;
  beforeRemoveHooks = new BeforeRemoveHooks;
  get ptr() {
    if (this.isRemoved) {
      return null;
    }
    return ffi.request.getWGPUViewPointer({ id: this.id });
  }
  constructor(options = defaultOptions2) {
    this.frame = {
      x: options.frame?.x ?? defaultOptions2.frame.x,
      y: options.frame?.y ?? defaultOptions2.frame.y,
      width: options.frame?.width ?? defaultOptions2.frame.width,
      height: options.frame?.height ?? defaultOptions2.frame.height
    };
    this.windowId = options.windowId ?? 0;
    this.autoResize = options.autoResize === false ? false : true;
    this.startTransparent = options.startTransparent ?? false;
    this.startPassthrough = options.startPassthrough ?? false;
    this.id = this.init();
    WGPUViewMap[this.id] = this;
  }
  init() {
    return ffi.request.createWGPUView({
      windowId: this.windowId,
      frame: {
        width: this.frame.width,
        height: this.frame.height,
        x: this.frame.x,
        y: this.frame.y
      },
      autoResize: this.autoResize,
      startTransparent: this.startTransparent,
      startPassthrough: this.startPassthrough
    });
  }
  setFrame(x, y, width, height) {
    this.frame = { x, y, width, height };
    ffi.request.wgpuViewSetFrame({ id: this.id, x, y, width, height });
  }
  setTransparent(transparent) {
    ffi.request.wgpuViewSetTransparent({ id: this.id, transparent });
  }
  setAlphaBlending(enabled) {
    ffi.request.wgpuViewSetAlphaBlending({ id: this.id, enabled });
  }
  setPassthrough(passthrough) {
    ffi.request.wgpuViewSetPassthrough({ id: this.id, passthrough });
  }
  setHidden(hidden) {
    ffi.request.wgpuViewSetHidden({ id: this.id, hidden });
  }
  on(name, handler) {
    const specificName = `${name}-${this.id}`;
    eventEmitter_default.on(specificName, handler);
  }
  onBeforeRemove(handler) {
    if (this.isRemoved)
      return () => {};
    return this.beforeRemoveHooks.subscribe(handler);
  }
  remove() {
    if (this.isRemoved) {
      return;
    }
    this.isRemoved = true;
    delete WGPUViewMap[this.id];
    const hookErrors = this.beforeRemoveHooks.run();
    try {
      releaseWebgpuContext(this.id);
    } catch (e) {
      console.error(`Error releasing WebGPU context for view ${this.id}:`, e);
    }
    try {
      ffi.request.wgpuViewRemove({ id: this.id });
    } catch (e) {
      console.error(`Error removing WGPU view ${this.id}:`, e);
    }
    for (const error of hookErrors) {
      console.error(`Error before removing WGPU view ${this.id}:`, error);
    }
  }
  getNativeHandle() {
    return ffi.request.wgpuViewGetNativeHandle({ id: this.id });
  }
  static getById(id) {
    return WGPUViewMap[id];
  }
  static adoptExisting(id, options = {}) {
    const existing = WGPUViewMap[id];
    if (existing) {
      return existing;
    }
    const ptr = ffi.request.getWGPUViewPointer({ id });
    if (!ptr) {
      return;
    }
    const view = Object.create(WGPUView.prototype);
    view.id = id;
    view.windowId = options.windowId ?? 0;
    view.autoResize = options.autoResize === false ? false : true;
    view.frame = {
      x: options.frame?.x ?? defaultOptions2.frame.x,
      y: options.frame?.y ?? defaultOptions2.frame.y,
      width: options.frame?.width ?? defaultOptions2.frame.width,
      height: options.frame?.height ?? defaultOptions2.frame.height
    };
    view.startTransparent = options.startTransparent ?? false;
    view.startPassthrough = options.startPassthrough ?? false;
    view.isRemoved = false;
    view.beforeRemoveHooks = new BeforeRemoveHooks;
    WGPUViewMap[id] = view;
    return view;
  }
  static getAll() {
    return Object.values(WGPUViewMap);
  }
}
var WGPUViewMap, defaultOptions2;
var init_WGPUView = __esm(() => {
  init_native();
  init_eventEmitter();
  init_webgpuContextRegistry();
  WGPUViewMap = {};
  defaultOptions2 = {
    frame: {
      x: 0,
      y: 0,
      width: 800,
      height: 600
    },
    autoResize: true,
    startTransparent: false,
    startPassthrough: false
  };
});

// .hutch/devkit/api/preload/.generated/compiled.ts
var preloadScript = `(function(){// src/preload/encryption.ts
function base64ToUint8Array(base64) {
  const binary = atob(base64);
  if (window.__electrobunPlatform === "linux") {
    const bytes = new Uint8Array(binary.length);
    for (let i = 0;i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }
  return new Uint8Array(binary.split("").map((char) => char.charCodeAt(0)));
}
function uint8ArrayToBase64(uint8Array) {
  let binary = "";
  for (let i = 0;i < uint8Array.length; i++) {
    binary += String.fromCharCode(uint8Array[i]);
  }
  return btoa(binary);
}
function toArrayBuffer(bytes) {
  const buffer = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(buffer).set(bytes);
  return buffer;
}
async function generateKeyFromBytes(rawKey) {
  return await window.crypto.subtle.importKey("raw", toArrayBuffer(rawKey), { name: "AES-GCM" }, true, ["encrypt", "decrypt"]);
}
async function initEncryption() {
  const secretKey = await generateKeyFromBytes(new Uint8Array(window.__electrobunSecretKeyBytes));
  const encryptString = async (plaintext) => {
    const encoder = new TextEncoder;
    const encodedText = encoder.encode(plaintext);
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const encryptedBuffer = await window.crypto.subtle.encrypt({ name: "AES-GCM", iv: toArrayBuffer(iv) }, secretKey, toArrayBuffer(encodedText));
    const encryptedData = new Uint8Array(encryptedBuffer.slice(0, -16));
    const tag = new Uint8Array(encryptedBuffer.slice(-16));
    return {
      encryptedData: uint8ArrayToBase64(encryptedData),
      iv: uint8ArrayToBase64(iv),
      tag: uint8ArrayToBase64(tag)
    };
  };
  const decryptString = async (encryptedDataB64, ivB64, tagB64) => {
    const encryptedData = base64ToUint8Array(encryptedDataB64);
    const iv = base64ToUint8Array(ivB64);
    const tag = base64ToUint8Array(tagB64);
    const combinedData = new Uint8Array(encryptedData.length + tag.length);
    combinedData.set(encryptedData);
    combinedData.set(tag, encryptedData.length);
    const decryptedBuffer = await window.crypto.subtle.decrypt({ name: "AES-GCM", iv: toArrayBuffer(iv) }, secretKey, toArrayBuffer(combinedData));
    const decoder = new TextDecoder;
    return decoder.decode(decryptedBuffer);
  };
  window.__electrobun_encrypt = encryptString;
  window.__electrobun_decrypt = decryptString;
}

// src/preload/internalRpc.ts
var pendingRequests = {};
var requestId = 0;
var isProcessingQueue = false;
var sendQueue = [];
function processQueue() {
  if (isProcessingQueue) {
    setTimeout(processQueue);
    return;
  }
  if (sendQueue.length === 0)
    return;
  isProcessingQueue = true;
  const batch = JSON.stringify(sendQueue);
  sendQueue.length = 0;
  window.__electrobunInternalBridge?.postMessage(batch);
  setTimeout(() => {
    isProcessingQueue = false;
  }, 2);
}
function send(type, payload) {
  sendQueue.push(JSON.stringify({ type: "message", id: type, payload }));
  processQueue();
}
function request(type, payload) {
  return new Promise((resolve, reject) => {
    const id = \`req_\${++requestId}_\${Date.now()}\`;
    pendingRequests[id] = { resolve, reject };
    sendQueue.push(JSON.stringify({
      type: "request",
      method: type,
      id,
      params: payload,
      hostWebviewId: window.__electrobunWebviewId
    }));
    processQueue();
    setTimeout(() => {
      if (pendingRequests[id]) {
        delete pendingRequests[id];
        reject(new Error(\`Request timeout: \${type}\`));
      }
    }, 1e4);
  });
}
function handleResponse(msg) {
  if (msg && msg.type === "response" && msg.id) {
    const pending = pendingRequests[msg.id];
    if (pending) {
      delete pendingRequests[msg.id];
      if (msg.success)
        pending.resolve(msg.payload);
      else
        pending.reject(msg.payload);
    }
  }
}

// src/preload/dragRegions.ts
var DRAG_CLASS = "electrobun-webkit-app-region-drag";
var NO_DRAG_CLASS = "electrobun-webkit-app-region-no-drag";
var MIRRORED_PROPERTY = "--electrobun-app-region";
var MIRROR_ATTRIBUTE = "data-electrobun-app-region-mirror";
var APP_REGION_PROPERTIES = [
  MIRRORED_PROPERTY,
  "-webkit-app-region",
  "app-region",
  "window-drag"
];
var DRAG_REGION_COMPATIBILITY_CSS = \`
.electrobun-webkit-app-region-drag {
	-webkit-app-region: drag;
	app-region: drag;
}
.electrobun-webkit-app-region-no-drag {
	-webkit-app-region: no-drag;
	app-region: no-drag;
}
\`;
var processedSourceSignatures = new WeakMap;
var stylesheetMirrors = new Map;
var pendingLinkSignatures = new WeakMap;
var stylesheetMirroringInitialized = false;
function normalizedRegion(value) {
  const normalized = value?.trim().toLowerCase();
  if (normalized === "drag" || normalized === "no-drag")
    return normalized;
  return null;
}
function previousSignificantCharacter(source, offset) {
  let index = offset - 1;
  while (index >= 0) {
    while (index >= 0 && /\\s/.test(source[index] ?? ""))
      index--;
    if (index >= 1 && source[index] === "/" && source[index - 1] === "*") {
      const commentStart = source.lastIndexOf("/*", index - 1);
      if (commentStart < 0)
        return "";
      index = commentStart - 1;
      continue;
    }
    return source[index] ?? "";
  }
  return "";
}
function isIdentifierCharacter(character) {
  return !!character && /[a-zA-Z0-9_-]/.test(character);
}
function rewriteAppRegionDeclarations(source) {
  const propertyNames = ["-webkit-app-region", "window-drag", "app-region"];
  let output = "";
  let cursor = 0;
  let index = 0;
  while (index < source.length) {
    if (source[index] === "/" && source[index + 1] === "*") {
      const commentEnd = source.indexOf("*/", index + 2);
      index = commentEnd < 0 ? source.length : commentEnd + 2;
      continue;
    }
    if (source[index] === '"' || source[index] === "'") {
      const quote = source[index];
      index++;
      while (index < source.length) {
        if (source[index] === "\\\\") {
          index += 2;
          continue;
        }
        if (source[index] === quote) {
          index++;
          break;
        }
        index++;
      }
      continue;
    }
    let matchedProperty;
    for (const propertyName of propertyNames) {
      if (source.slice(index, index + propertyName.length).toLowerCase() === propertyName && !isIdentifierCharacter(source[index - 1]) && !isIdentifierCharacter(source[index + propertyName.length])) {
        matchedProperty = propertyName;
        break;
      }
    }
    if (matchedProperty) {
      let colonOffset = index + matchedProperty.length;
      while (/\\s/.test(source[colonOffset] ?? ""))
        colonOffset++;
      const previous = previousSignificantCharacter(source, index);
      if (source[colonOffset] === ":" && (previous === "{" || previous === ";")) {
        output += source.slice(cursor, index) + MIRRORED_PROPERTY;
        index += matchedProperty.length;
        cursor = index;
        continue;
      }
    }
    index++;
  }
  return output + source.slice(cursor);
}
function nestedRuleContainer(rule) {
  const candidate = rule;
  if (candidate.cssRules && typeof candidate.deleteRule === "function") {
    return candidate;
  }
  return null;
}
function pruneToAppRegionRules(container) {
  let hasAppRegionRule = false;
  for (let index = container.cssRules.length - 1;index >= 0; index--) {
    const rule = container.cssRules[index];
    if (!rule)
      continue;
    const style = rule.style;
    let hasAppRegionDeclaration = false;
    if (style && typeof style.getPropertyValue === "function") {
      for (let propertyIndex = style.length - 1;propertyIndex >= 0; propertyIndex--) {
        const propertyName = style.item(propertyIndex);
        if (propertyName === MIRRORED_PROPERTY) {
          hasAppRegionDeclaration = true;
        } else {
          style.removeProperty(propertyName);
        }
      }
    }
    const nested = nestedRuleContainer(rule);
    const hasNestedAppRegionRule = nested ? pruneToAppRegionRules(nested) : false;
    if (!hasAppRegionDeclaration && !hasNestedAppRegionRule) {
      container.deleteRule(index);
      continue;
    }
    hasAppRegionRule = true;
  }
  return hasAppRegionRule;
}
function serializeRules(rules) {
  let cssText = "";
  for (let index = 0;index < rules.length; index++) {
    const rule = rules[index];
    if (rule)
      cssText += \`\${rule.cssText}
\`;
  }
  return cssText;
}
function removeStylesheetMirror(source) {
  stylesheetMirrors.get(source)?.remove();
  stylesheetMirrors.delete(source);
}
function installStylesheetMirror(source, cssText, signature) {
  if (processedSourceSignatures.get(source) === signature)
    return;
  processedSourceSignatures.set(source, signature);
  removeStylesheetMirror(source);
  const mirroredCss = rewriteAppRegionDeclarations(cssText);
  if (mirroredCss === cssText || !source.parentNode)
    return;
  const mirror = source.ownerDocument.createElement("style");
  mirror.setAttribute(MIRROR_ATTRIBUTE, "");
  mirror.media = "not all";
  if (source.nonce)
    mirror.nonce = source.nonce;
  mirror.textContent = mirroredCss;
  source.parentNode.insertBefore(mirror, source.nextSibling);
  let sheet = mirror.sheet;
  if (!sheet || !pruneToAppRegionRules(sheet)) {
    mirror.remove();
    return;
  }
  mirror.textContent = serializeRules(sheet.cssRules);
  sheet = mirror.sheet;
  if (!sheet) {
    mirror.remove();
    return;
  }
  mirror.media = source.media;
  if (source.sheet?.disabled)
    sheet.disabled = true;
  stylesheetMirrors.set(source, mirror);
}
function isMirroredStyle(element) {
  return element.tagName === "STYLE" && element.hasAttribute(MIRROR_ATTRIBUTE);
}
function isStylesheetSource(element) {
  if (element.tagName === "STYLE")
    return !isMirroredStyle(element);
  return element.tagName === "LINK" && element.relList.contains("stylesheet");
}
function nodeContainsStylesheetSource(node) {
  const element = node;
  if (typeof element.matches !== "function")
    return false;
  return isStylesheetSource(element) || !!element.querySelector("style:not([data-electrobun-app-region-mirror]), link[rel~='stylesheet']");
}
function mutationsAffectStylesheets(mutations) {
  for (const mutation of mutations) {
    if (mutation.type === "attributes") {
      const element = mutation.target;
      if (element.tagName === "LINK" || isStylesheetSource(element))
        return true;
      continue;
    }
    if (mutation.type === "characterData") {
      const parent = mutation.target.parentElement;
      if (parent && isStylesheetSource(parent))
        return true;
      continue;
    }
    const target = mutation.target;
    if (typeof target.matches === "function" && isStylesheetSource(target)) {
      return true;
    }
    for (let index = 0;index < mutation.addedNodes.length; index++) {
      const node = mutation.addedNodes[index];
      if (node && nodeContainsStylesheetSource(node))
        return true;
    }
    for (let index = 0;index < mutation.removedNodes.length; index++) {
      const node = mutation.removedNodes[index];
      if (node && nodeContainsStylesheetSource(node))
        return true;
    }
  }
  return false;
}
function processStyleElement(style) {
  if (isMirroredStyle(style))
    return;
  const cssText = style.textContent ?? "";
  installStylesheetMirror(style, cssText, \`\${style.media}
\${cssText}\`);
}
function processLinkElement(link) {
  if (!link.relList.contains("stylesheet") || !link.href) {
    removeStylesheetMirror(link);
    return;
  }
  const signature = \`\${link.media}
\${link.href}\`;
  if (processedSourceSignatures.get(link) === signature || pendingLinkSignatures.get(link) === signature) {
    return;
  }
  pendingLinkSignatures.set(link, signature);
  fetch(link.href, { credentials: "same-origin" }).then((response) => {
    if (!response.ok)
      throw new Error(\`HTTP \${response.status}\`);
    return response.text();
  }).then((cssText) => {
    if (link.isConnected && \`\${link.media}
\${link.href}\` === signature) {
      installStylesheetMirror(link, cssText, signature);
    }
  }).catch(() => {}).finally(() => {
    if (pendingLinkSignatures.get(link) === signature) {
      pendingLinkSignatures.delete(link);
    }
  });
}
function scanStylesheetSources() {
  document.querySelectorAll("style, link[rel~='stylesheet']").forEach((element) => {
    if (element.tagName === "STYLE") {
      processStyleElement(element);
    } else {
      processLinkElement(element);
    }
  });
  for (const [source, mirror] of stylesheetMirrors) {
    if (!source.isConnected) {
      mirror.remove();
      stylesheetMirrors.delete(source);
    }
  }
}
function initStylesheetMirroring() {
  if (stylesheetMirroringInitialized)
    return;
  stylesheetMirroringInitialized = true;
  let scanScheduled = false;
  const scheduleScan = () => {
    if (scanScheduled)
      return;
    scanScheduled = true;
    queueMicrotask(() => {
      scanScheduled = false;
      scanStylesheetSources();
    });
  };
  new MutationObserver((mutations) => {
    if (mutationsAffectStylesheets(mutations))
      scheduleScan();
  }).observe(document, {
    attributes: true,
    attributeFilter: ["href", "media", "rel"],
    characterData: true,
    childList: true,
    subtree: true
  });
  document.addEventListener("DOMContentLoaded", scheduleScan, { once: true });
  scheduleScan();
}
function installCompatibilityStyles() {
  if (document.querySelector("style[data-electrobun-drag-region-compat]"))
    return;
  const style = document.createElement("style");
  style.setAttribute("data-electrobun-drag-region-compat", "");
  style.textContent = DRAG_REGION_COMPATIBILITY_CSS;
  const install = () => {
    if (!document.head || style.isConnected)
      return;
    document.head.insertBefore(style, document.head.firstChild);
  };
  if (document.head)
    install();
  else
    document.addEventListener("DOMContentLoaded", install, { once: true });
}
function inlineRegion(element) {
  const style = element.getAttribute?.("style");
  if (!style)
    return null;
  const match = style.match(/(?:^|;)\\s*(?:-webkit-app-region|app-region|window-drag)\\s*:\\s*(no-drag|drag)\\b/i);
  return normalizedRegion(match?.[1]);
}
function computedRegion(element, readComputedStyle) {
  try {
    const style = readComputedStyle(element);
    for (const propertyName of APP_REGION_PROPERTIES) {
      const region = normalizedRegion(style.getPropertyValue(propertyName));
      if (region)
        return region;
    }
  } catch {}
  return null;
}
function eventTargetElement(target) {
  if (!target || typeof target.getAttribute !== "function") {
    return target?.parentElement ?? null;
  }
  return target;
}
function isAppRegionDragTarget(target, readComputedStyle = (element) => window.getComputedStyle(element)) {
  let element = eventTargetElement(target);
  let foundDragRegion = false;
  while (element) {
    if (element.classList?.contains(NO_DRAG_CLASS))
      return false;
    if (element.classList?.contains(DRAG_CLASS))
      foundDragRegion = true;
    const region = inlineRegion(element) ?? computedRegion(element, readComputedStyle);
    if (region === "no-drag")
      return false;
    if (region === "drag")
      foundDragRegion = true;
    element = element.parentElement;
  }
  return foundDragRegion;
}
function registerDragRegionListeners(targetDocument, getWindowId, sendMessage = send, readComputedStyle = (element) => window.getComputedStyle(element)) {
  targetDocument.addEventListener("mousedown", (event) => {
    if (isAppRegionDragTarget(event.target, readComputedStyle)) {
      sendMessage("startWindowMove", { id: getWindowId() });
    }
  });
  targetDocument.addEventListener("mouseup", (event) => {
    if (isAppRegionDragTarget(event.target, readComputedStyle)) {
      sendMessage("stopWindowMove", { id: getWindowId() });
    }
  });
}
function initDragRegions() {
  installCompatibilityStyles();
  initStylesheetMirroring();
  registerDragRegionListeners(document, () => window.__electrobunWindowId);
}

// src/preload/externalDropFocus.ts
function initExternalDropFocusRestoration(targetWindow = window, platform = window.__electrobunPlatform, requestFocus = request, schedule = (callback) => setTimeout(callback)) {
  if (platform !== "windows")
    return;
  targetWindow.addEventListener("drop", (event) => {
    const types = Array.from(event.dataTransfer?.types ?? []);
    if (!types.includes("Files"))
      return;
    const previouslyFocusedElement = targetWindow.document.activeElement;
    schedule(() => {
      requestFocus("restoreWindowFocusAfterExternalDrop", {
        windowId: targetWindow.__electrobunWindowId
      }).catch(() => {
        return;
      }).then(() => {
        targetWindow.focus();
        if (previouslyFocusedElement && "focus" in previouslyFocusedElement && typeof previouslyFocusedElement.focus === "function") {
          previouslyFocusedElement.focus();
        }
      });
    });
  }, true);
}

// src/preload/overlaySync.ts
class OverlaySyncController {
  element;
  options;
  lastRect = { x: 0, y: 0, width: 0, height: 0 };
  resizeObserver = null;
  positionLoop = null;
  resizeHandler = null;
  burstUntil = 0;
  constructor(element, options) {
    this.element = element;
    this.options = {
      onSync: options.onSync,
      getMasks: options.getMasks ?? (() => []),
      burstIntervalMs: options.burstIntervalMs ?? 50,
      baseIntervalMs: options.baseIntervalMs ?? 100,
      burstDurationMs: options.burstDurationMs ?? 500
    };
  }
  start() {
    this.resizeObserver = new ResizeObserver(() => this.sync());
    this.resizeObserver.observe(this.element);
    const loop = () => {
      this.sync();
      const now = performance.now();
      const interval = now < this.burstUntil ? this.options.burstIntervalMs : this.options.baseIntervalMs;
      this.positionLoop = setTimeout(loop, interval);
    };
    this.positionLoop = setTimeout(loop, this.options.baseIntervalMs);
    this.resizeHandler = () => this.sync(true);
    window.addEventListener("resize", this.resizeHandler);
  }
  stop() {
    if (this.resizeObserver)
      this.resizeObserver.disconnect();
    if (this.positionLoop)
      clearTimeout(this.positionLoop);
    if (this.resizeHandler) {
      window.removeEventListener("resize", this.resizeHandler);
    }
    this.resizeObserver = null;
    this.positionLoop = null;
    this.resizeHandler = null;
  }
  forceSync() {
    this.sync(true);
  }
  setLastRect(rect) {
    this.lastRect = rect;
  }
  sync(force = false) {
    const rect = this.element.getBoundingClientRect();
    const newRect = {
      x: rect.x,
      y: rect.y,
      width: rect.width,
      height: rect.height
    };
    if (newRect.width === 0 && newRect.height === 0) {
      return;
    }
    if (!force && newRect.x === this.lastRect.x && newRect.y === this.lastRect.y && newRect.width === this.lastRect.width && newRect.height === this.lastRect.height) {
      return;
    }
    this.burstUntil = performance.now() + this.options.burstDurationMs;
    this.lastRect = newRect;
    const masks = this.options.getMasks();
    this.options.onSync(newRect, JSON.stringify(masks));
  }
}

// src/preload/webviewTagNavigation.ts
class WebviewTagNavigationQueue {
  pending = null;
  beginInitialization() {
    this.pending = null;
  }
  defer(navigation) {
    this.pending = navigation;
  }
  take() {
    const navigation = this.pending;
    this.pending = null;
    return navigation;
  }
}

// src/preload/webviewTag.ts
var webviewRegistry = {};

class ElectrobunWebviewTag extends HTMLElement {
  webviewId = null;
  maskSelectors = new Set;
  _sync = null;
  _navigationQueue = new WebviewTagNavigationQueue;
  _initializationStarted = false;
  transparent = false;
  passthroughEnabled = false;
  spellCheckEnabled = false;
  hidden = false;
  sandboxed = false;
  _eventListeners = {};
  static get observedAttributes() {
    return ["src", "html", "spellcheck"];
  }
  constructor() {
    super();
  }
  connectedCallback() {
    requestAnimationFrame(() => this.initWebview());
  }
  attributeChangedCallback(name, oldValue, newValue) {
    if (oldValue === newValue)
      return;
    if (name === "src" && newValue !== null) {
      this.navigate({ kind: "url", value: newValue });
    } else if (name === "html" && newValue !== null) {
      this.navigate({ kind: "html", value: newValue });
    } else if (name === "spellcheck" && this.webviewId !== null) {
      this.setSpellCheck(newValue !== null && newValue.toLowerCase() !== "false");
    }
  }
  disconnectedCallback() {
    if (this.webviewId !== null) {
      send("webviewTagRemove", { id: this.webviewId });
      delete webviewRegistry[this.webviewId];
    }
    if (this._sync)
      this._sync.stop();
  }
  getInitialNavigationRules() {
    const rawRules = this.getAttribute("navigation-rules");
    if (rawRules === null) {
      return null;
    }
    const trimmed = rawRules.trim();
    if (!trimmed) {
      return [];
    }
    try {
      const parsed = JSON.parse(trimmed);
      if (!Array.isArray(parsed) || !parsed.every((rule) => typeof rule === "string")) {
        throw new Error("navigation-rules must be a JSON string array");
      }
      return parsed;
    } catch (error) {
      console.error("Invalid navigation-rules attribute:", error);
      return [];
    }
  }
  async initWebview() {
    this._initializationStarted = true;
    this._navigationQueue.beginInitialization();
    const rect = this.getBoundingClientRect();
    const initialRect = {
      x: rect.x,
      y: rect.y,
      width: rect.width,
      height: rect.height
    };
    const url = this.getAttribute("src");
    const html = this.getAttribute("html");
    const preload = this.getAttribute("preload");
    const partition = this.getAttribute("partition");
    const renderer = this.getAttribute("renderer") || "native";
    const masks = this.getAttribute("masks");
    const navigationRules = this.getInitialNavigationRules();
    const sandbox = this.hasAttribute("sandbox");
    this.sandboxed = sandbox;
    const transparent = this.hasAttribute("transparent");
    const passthrough = this.hasAttribute("passthrough");
    const spellCheckAttribute = this.getAttribute("spellcheck");
    const spellCheck = spellCheckAttribute !== null && spellCheckAttribute.toLowerCase() !== "false";
    this.transparent = transparent;
    this.passthroughEnabled = passthrough;
    this.spellCheckEnabled = spellCheck;
    if (transparent)
      this.style.opacity = "0";
    if (passthrough)
      this.style.pointerEvents = "none";
    if (masks) {
      masks.split(",").forEach((s) => this.maskSelectors.add(s.trim()));
    }
    try {
      const webviewInitParams = {
        hostWebviewId: window.__electrobunWebviewId,
        windowId: window.__electrobunWindowId,
        renderer,
        url,
        html,
        preload,
        partition,
        frame: initialRect,
        sandbox,
        transparent,
        passthrough,
        spellCheck,
        ...navigationRules === null ? {} : { navigationRules }
      };
      const webviewId = await request("webviewTagInit", webviewInitParams);
      this.webviewId = webviewId;
      this.id = \`electrobun-webview-\${webviewId}\`;
      webviewRegistry[webviewId] = this;
      const pendingNavigation = this._navigationQueue.take();
      if (pendingNavigation)
        this.navigate(pendingNavigation);
      this.setupObservers(initialRect);
      this.syncDimensions(true);
      requestAnimationFrame(() => {
        Object.values(webviewRegistry).forEach((webview) => {
          if (webview !== this && webview.webviewId !== null) {
            webview.syncDimensions(true);
          }
        });
      });
    } catch (err) {
      console.error("Failed to init webview:", err);
    }
  }
  setupObservers(initialRect) {
    const getMasks = () => {
      const rect = this.getBoundingClientRect();
      const masks = [];
      this.maskSelectors.forEach((selector) => {
        try {
          document.querySelectorAll(selector).forEach((el) => {
            const mr = el.getBoundingClientRect();
            masks.push({
              x: mr.x - rect.x,
              y: mr.y - rect.y,
              width: mr.width,
              height: mr.height
            });
          });
        } catch (_e) {}
      });
      return masks;
    };
    this._sync = new OverlaySyncController(this, {
      onSync: (rect, masksJson) => {
        if (this.webviewId === null)
          return;
        send("webviewTagResize", {
          id: this.webviewId,
          frame: rect,
          masks: masksJson
        });
      },
      getMasks,
      burstIntervalMs: 10,
      baseIntervalMs: 100,
      burstDurationMs: 50
    });
    this._sync.setLastRect(initialRect);
    this._sync.start();
  }
  syncDimensions(force = false) {
    if (!this._sync)
      return;
    if (force) {
      this._sync.forceSync();
    }
  }
  navigate(navigation) {
    if (this.webviewId === null) {
      this._navigationQueue.defer(navigation);
      return;
    }
    if (navigation.kind === "url") {
      send("webviewTagUpdateSrc", {
        id: this.webviewId,
        url: navigation.value
      });
    } else {
      send("webviewTagUpdateHtml", {
        id: this.webviewId,
        html: navigation.value
      });
    }
  }
  loadURL(url) {
    if (this.getAttribute("src") === url) {
      this.navigate({ kind: "url", value: url });
    } else {
      this.setAttribute("src", url);
    }
  }
  loadHTML(html) {
    if (this.webviewId === null && !this._initializationStarted) {
      this.setAttribute("html", html);
      return;
    }
    this.navigate({ kind: "html", value: html });
  }
  reload() {
    if (this.webviewId !== null)
      send("webviewTagReload", { id: this.webviewId });
  }
  goBack() {
    if (this.webviewId !== null)
      send("webviewTagGoBack", { id: this.webviewId });
  }
  goForward() {
    if (this.webviewId !== null)
      send("webviewTagGoForward", { id: this.webviewId });
  }
  async canGoBack() {
    if (this.webviewId === null)
      return false;
    return await request("webviewTagCanGoBack", {
      id: this.webviewId
    });
  }
  async canGoForward() {
    if (this.webviewId === null)
      return false;
    return await request("webviewTagCanGoForward", {
      id: this.webviewId
    });
  }
  async setSpellCheck(enabled) {
    this.spellCheckEnabled = enabled;
    if (this.webviewId === null)
      return false;
    return await request("webviewTagSetSpellCheck", {
      id: this.webviewId,
      enabled
    });
  }
  toggleTransparent(value) {
    if (this.webviewId === null)
      return;
    this.transparent = value !== undefined ? value : !this.transparent;
    this.style.opacity = this.transparent ? "0" : "";
    send("webviewTagSetTransparent", {
      id: this.webviewId,
      transparent: this.transparent
    });
  }
  togglePassthrough(value) {
    if (this.webviewId === null)
      return;
    this.passthroughEnabled = value !== undefined ? value : !this.passthroughEnabled;
    this.style.pointerEvents = this.passthroughEnabled ? "none" : "";
    send("webviewTagSetPassthrough", {
      id: this.webviewId,
      enablePassthrough: this.passthroughEnabled
    });
  }
  toggleHidden(value) {
    if (this.webviewId === null)
      return;
    this.hidden = value !== undefined ? value : !this.hidden;
    send("webviewTagSetHidden", { id: this.webviewId, hidden: this.hidden });
  }
  addMaskSelector(selector) {
    this.maskSelectors.add(selector);
    this.syncDimensions(true);
  }
  removeMaskSelector(selector) {
    this.maskSelectors.delete(selector);
    this.syncDimensions(true);
  }
  setNavigationRules(rules) {
    if (this.webviewId !== null) {
      send("webviewTagSetNavigationRules", { id: this.webviewId, rules });
    }
  }
  findInPage(searchText, options) {
    if (this.webviewId === null)
      return;
    const forward = options?.forward !== false;
    const matchCase = options?.matchCase || false;
    send("webviewTagFindInPage", {
      id: this.webviewId,
      searchText,
      forward,
      matchCase
    });
  }
  stopFindInPage() {
    if (this.webviewId !== null)
      send("webviewTagStopFind", { id: this.webviewId });
  }
  openDevTools() {
    if (this.webviewId !== null)
      send("webviewTagOpenDevTools", { id: this.webviewId });
  }
  closeDevTools() {
    if (this.webviewId !== null)
      send("webviewTagCloseDevTools", { id: this.webviewId });
  }
  toggleDevTools() {
    if (this.webviewId !== null)
      send("webviewTagToggleDevTools", { id: this.webviewId });
  }
  executeJavascript(js) {
    if (this.webviewId === null)
      return;
    send("webviewTagExecuteJavascript", { id: this.webviewId, js });
  }
  on(event, listener) {
    if (!this._eventListeners[event])
      this._eventListeners[event] = [];
    this._eventListeners[event].push(listener);
  }
  off(event, listener) {
    if (!this._eventListeners[event])
      return;
    const idx = this._eventListeners[event].indexOf(listener);
    if (idx !== -1)
      this._eventListeners[event].splice(idx, 1);
  }
  emit(event, detail) {
    const listeners = this._eventListeners[event];
    if (listeners) {
      const customEvent = new CustomEvent(event, { detail });
      listeners.forEach((fn) => fn(customEvent));
    }
  }
  get src() {
    return this.getAttribute("src");
  }
  set src(value) {
    if (value) {
      this.setAttribute("src", value);
    } else {
      this.removeAttribute("src");
    }
  }
  get html() {
    return this.getAttribute("html");
  }
  set html(value) {
    if (value) {
      this.setAttribute("html", value);
    } else {
      this.removeAttribute("html");
    }
  }
  get preload() {
    return this.getAttribute("preload");
  }
  set preload(value) {
    if (value)
      this.setAttribute("preload", value);
    else
      this.removeAttribute("preload");
  }
  get renderer() {
    return this.getAttribute("renderer") || "native";
  }
  set renderer(value) {
    this.setAttribute("renderer", value);
  }
  get sandbox() {
    return this.sandboxed;
  }
}
function initWebviewTag() {
  if (!customElements.get("electrobun-webview")) {
    customElements.define("electrobun-webview", ElectrobunWebviewTag);
  }
  const injectStyles = () => {
    const style = document.createElement("style");
    style.textContent = \`
electrobun-webview {
	display: block;
	width: 800px;
	height: 300px;
	background: #fff;
	background-repeat: no-repeat !important;
	overflow: hidden;
}
\`;
    if (document.head?.firstChild) {
      document.head.insertBefore(style, document.head.firstChild);
    } else if (document.head) {
      document.head.appendChild(style);
    }
  };
  if (document.head) {
    injectStyles();
  } else {
    document.addEventListener("DOMContentLoaded", injectStyles);
  }
}

// src/preload/wgpuTag.ts
var wgpuTagRegistry = {};

class ElectrobunWgpuTag extends HTMLElement {
  wgpuViewId = null;
  maskSelectors = new Set;
  _sync = null;
  transparent = false;
  passthroughEnabled = false;
  hidden = false;
  _ready = false;
  _initializing = false;
  _eventListeners = {};
  constructor() {
    super();
  }
  connectedCallback() {
    requestAnimationFrame(() => {
      if (this.isConnected)
        this.initWgpuView();
    });
  }
  disconnectedCallback() {
    if (this.wgpuViewId !== null) {
      send("wgpuTagRemove", { id: this.wgpuViewId });
      delete wgpuTagRegistry[this.wgpuViewId];
      this.wgpuViewId = null;
    }
    if (this._sync)
      this._sync.stop();
    this._sync = null;
    this._ready = false;
  }
  async initWgpuView() {
    if (this._initializing || this.wgpuViewId !== null)
      return;
    this._initializing = true;
    const rect = this.getBoundingClientRect();
    const initialRect = {
      x: rect.x,
      y: rect.y,
      width: rect.width,
      height: rect.height
    };
    const transparent = this.hasAttribute("transparent");
    const passthrough = this.hasAttribute("passthrough");
    const hidden = this.hasAttribute("hidden");
    const masks = this.getAttribute("masks");
    this.transparent = transparent;
    this.passthroughEnabled = passthrough;
    this.hidden = hidden;
    if (masks) {
      masks.split(",").forEach((s) => this.maskSelectors.add(s.trim()));
    }
    if (transparent)
      this.style.opacity = "0";
    if (passthrough)
      this.style.pointerEvents = "none";
    try {
      const wgpuViewId = await request("wgpuTagInit", {
        windowId: window.__electrobunWindowId,
        frame: initialRect,
        transparent,
        passthrough
      });
      if (!this.isConnected) {
        send("wgpuTagRemove", { id: wgpuViewId });
        return;
      }
      this.wgpuViewId = wgpuViewId;
      if (!this.id) {
        this.id = \`electrobun-wgpu-\${wgpuViewId}\`;
      }
      wgpuTagRegistry[wgpuViewId] = this;
      this.setupObservers(initialRect);
      this.syncDimensions(true);
      if (hidden) {
        this.toggleHidden(true);
      }
      requestAnimationFrame(() => {
        Object.values(wgpuTagRegistry).forEach((view) => {
          if (view !== this && view.wgpuViewId !== null) {
            view.syncDimensions(true);
          }
        });
      });
      this._ready = true;
      this.emit("ready", { id: wgpuViewId });
    } catch (err) {
      console.error("Failed to init WGPU view:", err);
    } finally {
      this._initializing = false;
    }
  }
  setupObservers(initialRect) {
    const getMasks = () => {
      const rect = this.getBoundingClientRect();
      const masks = [];
      this.maskSelectors.forEach((selector) => {
        try {
          document.querySelectorAll(selector).forEach((el) => {
            const mr = el.getBoundingClientRect();
            masks.push({
              x: mr.x - rect.x,
              y: mr.y - rect.y,
              width: mr.width,
              height: mr.height
            });
          });
        } catch (_e) {}
      });
      return masks;
    };
    this._sync = new OverlaySyncController(this, {
      onSync: (rect, masksJson) => {
        if (this.wgpuViewId === null)
          return;
        send("wgpuTagResize", {
          id: this.wgpuViewId,
          frame: rect,
          masks: masksJson
        });
      },
      getMasks,
      burstIntervalMs: 10,
      baseIntervalMs: 100,
      burstDurationMs: 50
    });
    this._sync.setLastRect(initialRect);
    this._sync.start();
  }
  syncDimensions(force = false) {
    if (!this._sync)
      return;
    if (force) {
      this._sync.forceSync();
    }
  }
  toggleTransparent(value) {
    if (this.wgpuViewId === null)
      return;
    this.transparent = value !== undefined ? value : !this.transparent;
    this.style.opacity = this.transparent ? "0" : "";
    send("wgpuTagSetTransparent", {
      id: this.wgpuViewId,
      transparent: this.transparent
    });
  }
  togglePassthrough(value) {
    if (this.wgpuViewId === null)
      return;
    this.passthroughEnabled = value !== undefined ? value : !this.passthroughEnabled;
    this.style.pointerEvents = this.passthroughEnabled ? "none" : "";
    send("wgpuTagSetPassthrough", {
      id: this.wgpuViewId,
      passthrough: this.passthroughEnabled
    });
  }
  toggleHidden(value) {
    if (this.wgpuViewId === null)
      return;
    this.hidden = value !== undefined ? value : !this.hidden;
    send("wgpuTagSetHidden", { id: this.wgpuViewId, hidden: this.hidden });
  }
  runTest() {
    if (this.wgpuViewId === null)
      return;
    send("wgpuTagRunTest", { id: this.wgpuViewId });
  }
  addMaskSelector(selector) {
    this.maskSelectors.add(selector);
    this.syncDimensions(true);
  }
  removeMaskSelector(selector) {
    this.maskSelectors.delete(selector);
    this.syncDimensions(true);
  }
  on(event, listener) {
    if (!this._eventListeners[event])
      this._eventListeners[event] = [];
    this._eventListeners[event].push(listener);
    if (event === "ready" && this._ready && this.wgpuViewId !== null) {
      const readyEvent = new CustomEvent(event, {
        detail: { id: this.wgpuViewId }
      });
      queueMicrotask(() => {
        if (this._eventListeners[event]?.includes(listener)) {
          listener(readyEvent);
        }
      });
    }
  }
  off(event, listener) {
    if (!this._eventListeners[event])
      return;
    const idx = this._eventListeners[event].indexOf(listener);
    if (idx !== -1)
      this._eventListeners[event].splice(idx, 1);
  }
  emit(event, detail) {
    const listeners = this._eventListeners[event];
    if (listeners) {
      const customEvent = new CustomEvent(event, { detail });
      listeners.forEach((fn) => fn(customEvent));
    }
  }
}
function initWgpuTag() {
  if (!customElements.get("electrobun-wgpu")) {
    customElements.define("electrobun-wgpu", ElectrobunWgpuTag);
  }
  const injectStyles = () => {
    const style = document.createElement("style");
    style.textContent = \`
electrobun-wgpu {
	display: block;
	width: 800px;
	height: 300px;
	background: #000;
	overflow: hidden;
}
\`;
    if (document.head?.firstChild) {
      document.head.insertBefore(style, document.head.firstChild);
    } else if (document.head) {
      document.head.appendChild(style);
    }
  };
  if (document.head) {
    injectStyles();
  } else {
    document.addEventListener("DOMContentLoaded", injectStyles);
  }
}

// src/preload/uiTag.ts
class ElectrobunUiTag extends ElectrobunWgpuTag {
  async initWgpuView() {
    await super.initWgpuView();
    if (this.wgpuViewId !== null) {
      send("uiTagMount", {
        id: this.wgpuViewId,
        name: this.getAttribute("name") ?? ""
      });
    }
  }
}
function initUiTag() {
  if (!customElements.get("electrobun-ui")) {
    customElements.define("electrobun-ui", ElectrobunUiTag);
  }
  const injectStyles = () => {
    const style = document.createElement("style");
    style.textContent = \`
electrobun-ui {
	display: block;
	width: 400px;
	height: 300px;
}
\`;
    document.head.appendChild(style);
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", injectStyles);
  } else {
    injectStyles();
  }
}

// src/preload/events.ts
function emitWebviewEvent(eventName, detail) {
  setTimeout(() => {
    const bridge = window.__electrobunEventBridge || window.__electrobunInternalBridge;
    bridge?.postMessage(JSON.stringify({
      id: "webviewEvent",
      type: "message",
      payload: {
        id: window.__electrobunWebviewId,
        eventName,
        detail
      }
    }));
  });
}
function initHostMessageBridge(targetWindow = window, emit = emitWebviewEvent) {
  targetWindow.__electrobunSendToHost = (message) => {
    emit("host-message", JSON.stringify(message));
  };
}
function initLifecycleEvents() {
  window.addEventListener("load", () => {
    if (window === window.top) {
      emitWebviewEvent("dom-ready", document.location.href);
    }
  });
  window.addEventListener("popstate", () => {
    emitWebviewEvent("did-navigate-in-page", window.location.href);
  });
  window.addEventListener("hashchange", () => {
    emitWebviewEvent("did-navigate-in-page", window.location.href);
  });
}
var cmdKeyHeld = false;
var cmdKeyTimestamp = 0;
var CMD_KEY_THRESHOLD_MS = 500;
function isCmdHeld() {
  if (cmdKeyHeld)
    return true;
  return Date.now() - cmdKeyTimestamp < CMD_KEY_THRESHOLD_MS && cmdKeyTimestamp > 0;
}
function initCmdClickHandling() {
  window.addEventListener("keydown", (event) => {
    if (event.key === "Meta" || event.metaKey) {
      cmdKeyHeld = true;
      cmdKeyTimestamp = Date.now();
    }
  }, true);
  window.addEventListener("keyup", (event) => {
    if (event.key === "Meta") {
      cmdKeyHeld = false;
      cmdKeyTimestamp = Date.now();
    }
  }, true);
  window.addEventListener("blur", () => {
    cmdKeyHeld = false;
  });
  window.addEventListener("click", (event) => {
    if (event.metaKey || event.ctrlKey) {
      const anchor = event.target?.closest?.("a");
      if (anchor && anchor.href) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        emitWebviewEvent("new-window-open", JSON.stringify({
          url: anchor.href,
          isCmdClick: true,
          isSPANavigation: false
        }));
      }
    }
  }, true);
}
function initSPANavigationInterception() {
  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;
  history.pushState = function(state, title, url) {
    if (isCmdHeld() && url) {
      const resolvedUrl = new URL(String(url), window.location.href).href;
      emitWebviewEvent("new-window-open", JSON.stringify({
        url: resolvedUrl,
        isCmdClick: true,
        isSPANavigation: true
      }));
      return;
    }
    return originalPushState.apply(this, [state, title, url]);
  };
  history.replaceState = function(state, title, url) {
    if (isCmdHeld() && url) {
      const resolvedUrl = new URL(String(url), window.location.href).href;
      emitWebviewEvent("new-window-open", JSON.stringify({
        url: resolvedUrl,
        isCmdClick: true,
        isSPANavigation: true
      }));
      return;
    }
    return originalReplaceState.apply(this, [state, title, url]);
  };
}
function shouldApplyOverscrollPrevention(platform) {
  return platform !== "linux";
}
function initOverscrollPrevention(targetDocument = document, platform = window.__electrobunPlatform) {
  if (!shouldApplyOverscrollPrevention(platform))
    return;
  targetDocument.addEventListener("DOMContentLoaded", () => {
    const style = targetDocument.createElement("style");
    style.type = "text/css";
    style.appendChild(targetDocument.createTextNode("html, body { overscroll-behavior: none; }"));
    targetDocument.head.appendChild(style);
  });
}

// src/preload/index.ts
initEncryption().catch((err) => console.error("Failed to initialize encryption:", err));
var internalMessageHandler = (msg) => {
  handleResponse(msg);
};
var defaultUserMessageHandler = (msg) => {
  if (!window.__electrobunPendingHostMessages) {
    window.__electrobunPendingHostMessages = [];
  }
  window.__electrobunPendingHostMessages.push(msg);
};
if (!window.__electrobun) {
  window.__electrobun = {
    receiveInternalMessageFromHost: internalMessageHandler,
    receiveMessageFromHost: defaultUserMessageHandler,
    receiveInternalMessageFromBun: internalMessageHandler,
    receiveMessageFromBun: defaultUserMessageHandler
  };
} else {
  window.__electrobun.receiveInternalMessageFromHost = internalMessageHandler;
  window.__electrobun.receiveMessageFromHost = defaultUserMessageHandler;
  window.__electrobun.receiveInternalMessageFromBun = internalMessageHandler;
  window.__electrobun.receiveMessageFromBun = defaultUserMessageHandler;
}
initHostMessageBridge();
initLifecycleEvents();
initCmdClickHandling();
initSPANavigationInterception();
initOverscrollPrevention();
initDragRegions();
initExternalDropFocusRestoration();
initWebviewTag();
initWgpuTag();
initUiTag();
})();`, preloadScriptSandboxed = `(function(){// src/preload/events.ts
function emitWebviewEvent(eventName, detail) {
  setTimeout(() => {
    const bridge = window.__electrobunEventBridge || window.__electrobunInternalBridge;
    bridge?.postMessage(JSON.stringify({
      id: "webviewEvent",
      type: "message",
      payload: {
        id: window.__electrobunWebviewId,
        eventName,
        detail
      }
    }));
  });
}
function initHostMessageBridge(targetWindow = window, emit = emitWebviewEvent) {
  targetWindow.__electrobunSendToHost = (message) => {
    emit("host-message", JSON.stringify(message));
  };
}
function initLifecycleEvents() {
  window.addEventListener("load", () => {
    if (window === window.top) {
      emitWebviewEvent("dom-ready", document.location.href);
    }
  });
  window.addEventListener("popstate", () => {
    emitWebviewEvent("did-navigate-in-page", window.location.href);
  });
  window.addEventListener("hashchange", () => {
    emitWebviewEvent("did-navigate-in-page", window.location.href);
  });
}
var cmdKeyHeld = false;
var cmdKeyTimestamp = 0;
var CMD_KEY_THRESHOLD_MS = 500;
function isCmdHeld() {
  if (cmdKeyHeld)
    return true;
  return Date.now() - cmdKeyTimestamp < CMD_KEY_THRESHOLD_MS && cmdKeyTimestamp > 0;
}
function initCmdClickHandling() {
  window.addEventListener("keydown", (event) => {
    if (event.key === "Meta" || event.metaKey) {
      cmdKeyHeld = true;
      cmdKeyTimestamp = Date.now();
    }
  }, true);
  window.addEventListener("keyup", (event) => {
    if (event.key === "Meta") {
      cmdKeyHeld = false;
      cmdKeyTimestamp = Date.now();
    }
  }, true);
  window.addEventListener("blur", () => {
    cmdKeyHeld = false;
  });
  window.addEventListener("click", (event) => {
    if (event.metaKey || event.ctrlKey) {
      const anchor = event.target?.closest?.("a");
      if (anchor && anchor.href) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        emitWebviewEvent("new-window-open", JSON.stringify({
          url: anchor.href,
          isCmdClick: true,
          isSPANavigation: false
        }));
      }
    }
  }, true);
}
function initSPANavigationInterception() {
  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;
  history.pushState = function(state, title, url) {
    if (isCmdHeld() && url) {
      const resolvedUrl = new URL(String(url), window.location.href).href;
      emitWebviewEvent("new-window-open", JSON.stringify({
        url: resolvedUrl,
        isCmdClick: true,
        isSPANavigation: true
      }));
      return;
    }
    return originalPushState.apply(this, [state, title, url]);
  };
  history.replaceState = function(state, title, url) {
    if (isCmdHeld() && url) {
      const resolvedUrl = new URL(String(url), window.location.href).href;
      emitWebviewEvent("new-window-open", JSON.stringify({
        url: resolvedUrl,
        isCmdClick: true,
        isSPANavigation: true
      }));
      return;
    }
    return originalReplaceState.apply(this, [state, title, url]);
  };
}
function shouldApplyOverscrollPrevention(platform) {
  return platform !== "linux";
}
function initOverscrollPrevention(targetDocument = document, platform = window.__electrobunPlatform) {
  if (!shouldApplyOverscrollPrevention(platform))
    return;
  targetDocument.addEventListener("DOMContentLoaded", () => {
    const style = targetDocument.createElement("style");
    style.type = "text/css";
    style.appendChild(targetDocument.createTextNode("html, body { overscroll-behavior: none; }"));
    targetDocument.head.appendChild(style);
  });
}

// src/preload/index-sandboxed.ts
initHostMessageBridge();
initLifecycleEvents();
initCmdClickHandling();
initSPANavigationInterception();
initOverscrollPrevention();
})();`;

// .hutch/devkit/api/sdks/main/proc/eventBridge.ts
function isJsonRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function parseWebviewEventBridgeMessage(sourceId, rawMessage) {
  if (!rawMessage.startsWith("{"))
    return null;
  let message;
  try {
    message = JSON.parse(rawMessage);
  } catch {
    return null;
  }
  if (!isJsonRecord(message) || message["id"] !== "webviewEvent" || message["type"] !== "message" || !isJsonRecord(message["payload"])) {
    return null;
  }
  const { id, eventName, detail } = message["payload"];
  if (id !== sourceId || typeof eventName !== "string" || typeof detail !== "string") {
    return null;
  }
  return { id: sourceId, eventName, detail };
}

// .hutch/devkit/api/sdks/main/proc/ffiCString.ts
import { CString } from "bun:ffi";
function ffiCStringToString(value) {
  if (typeof value === "string")
    return value;
  return value ? new CString(value).toString() : "";
}
var init_ffiCString = () => {};

// .hutch/devkit/api/sdks/main/proc/nativeTextBitmap.ts
var init_nativeTextBitmap = () => {};

// .hutch/devkit/api/shared/platform.ts
import { platform, arch } from "os";
var platformName, archName, OS, ARCH;
var init_platform = __esm(() => {
  platformName = platform();
  archName = arch();
  OS = (() => {
    switch (platformName) {
      case "win32":
        return "win";
      case "darwin":
        return "macos";
      case "linux":
        return "linux";
      default:
        throw new Error(`Unsupported platform: ${platformName}`);
    }
  })();
  ARCH = (() => {
    switch (archName) {
      case "arm64":
        return "arm64";
      case "x64":
        return "x64";
      default:
        throw new Error(`Unsupported architecture: ${archName}`);
    }
  })();
});

// .hutch/devkit/api/shared/dialog-paths.ts
function decodeDialogPaths(payload) {
  if (payload.length === 0) {
    return [];
  }
  const value = JSON.parse(payload);
  if (!Array.isArray(value) || !value.every((path) => typeof path === "string")) {
    throw new TypeError("Invalid file-dialog path payload");
  }
  return value;
}

// .hutch/devkit/api/shared/naming.ts
function isBuildEnvironment(value) {
  return value === "stable" || value === "canary" || value === "dev";
}
function requireBuildEnvironment(value) {
  if (!isBuildEnvironment(value)) {
    throw new Error(`Unsupported build environment: ${value}`);
  }
}
function getPlatformPrefix(buildEnvironment, os, arch2) {
  requireBuildEnvironment(buildEnvironment);
  return `${buildEnvironment}-${os}-${arch2}`;
}

// .hutch/devkit/api/sdks/main/core/Utils.ts
var exports_Utils = {};
__export(exports_Utils, {
  showNotification: () => showNotification,
  showMessageBox: () => showMessageBox,
  showItemInFolder: () => showItemInFolder,
  setDockIconVisible: () => setDockIconVisible,
  screenCapture: () => screenCapture,
  resolveInstalledRootNameForPaths: () => resolveInstalledRootNameForPaths,
  requestQuitApproval: () => requestQuitApproval,
  quitAfterApproval: () => quitAfterApproval,
  quit: () => quit,
  paths: () => paths,
  openPath: () => openPath,
  openFileDialog: () => openFileDialog,
  openExternal: () => openExternal,
  moveToTrash: () => moveToTrash,
  isDockIconVisible: () => isDockIconVisible,
  clipboardWriteText: () => clipboardWriteText,
  clipboardWriteImage: () => clipboardWriteImage,
  clipboardReadText: () => clipboardReadText,
  clipboardReadImage: () => clipboardReadImage,
  clipboardClear: () => clipboardClear,
  clipboardAvailableFormats: () => clipboardAvailableFormats,
  cancelQuitApproval: () => cancelQuitApproval
});
import { homedir, tmpdir } from "os";
import { isAbsolute, join, posix, resolve, win32 } from "path";
import { lstatSync, readFileSync as readFileSync2 } from "fs";
function getLinuxXdgUserDirs() {
  try {
    const content = readFileSync2(join(home, ".config", "user-dirs.dirs"), "utf-8");
    const dirs = {};
    for (const line of content.split(`
`)) {
      const trimmed = line.trim();
      if (trimmed.startsWith("#") || !trimmed.includes("="))
        continue;
      const eqIdx = trimmed.indexOf("=");
      const key = trimmed.slice(0, eqIdx);
      let value = trimmed.slice(eqIdx + 1);
      if (value.startsWith('"') && value.endsWith('"')) {
        value = value.slice(1, -1);
      }
      value = value.replace(/\$HOME/g, home);
      dirs[key] = value;
    }
    return dirs;
  } catch {
    return {};
  }
}
function xdgUserDir(key, fallbackName) {
  if (OS !== "linux")
    return "";
  if (!_xdgUserDirs)
    _xdgUserDirs = getLinuxXdgUserDirs();
  return _xdgUserDirs[key] || join(home, fallbackName);
}
function getVersionInfo() {
  if (_versionInfo)
    return _versionInfo;
  try {
    const resourcesDir = "Resources";
    const raw = readFileSync2(join("..", resourcesDir, "version.json"), "utf-8");
    const parsed = JSON.parse(raw);
    _versionInfo = {
      identifier: parsed.identifier,
      channel: parsed.channel,
      version: parsed.version,
      hash: parsed.hash,
      name: parsed.name,
      displayName: parsed.displayName
    };
    return _versionInfo;
  } catch (error) {
    console.error("Failed to read version.json", error);
    _versionInfo = { identifier: "", channel: "" };
    return _versionInfo;
  }
}
function safeManagedRootName(value, platform2) {
  if (typeof value !== "string" || value.length === 0 || value.length > 256 || value === "." || value === "..") {
    return false;
  }
  return platform2 === "win" ? !/[\u0000-\u001f"%*/:<>?\\|]/.test(value) && !/[ .]$/.test(value) : !/[\u0000-\u001f\u007f/\\]/.test(value);
}
function isRegularManagedFile(path) {
  const stat = lstatSync(path, { throwIfNoEntry: false });
  return Boolean(stat?.isFile() && !stat.isSymbolicLink());
}
function resolveInstalledRootNameForPaths(info, platform2, executablePath, appDataRoot, regularFileProbe = isRegularManagedFile) {
  if (!safeManagedRootName(info.identifier, platform2) || !safeManagedRootName(info.channel, platform2) || !isBuildEnvironment(info.channel)) {
    return "";
  }
  const pathApi = platform2 === "win" ? win32 : posix;
  const identifierRoot = pathApi.resolve(pathApi.join(appDataRoot, info.identifier));
  if (platform2 !== "macos") {
    const derivedRoot = pathApi.resolve(pathApi.dirname(executablePath), "..", "..");
    const derivedParent = pathApi.resolve(pathApi.dirname(derivedRoot));
    const parentMatches = platform2 === "win" ? derivedParent.toLowerCase() === identifierRoot.toLowerCase() : derivedParent === identifierRoot;
    const derivedName = pathApi.basename(derivedRoot);
    if (parentMatches && safeManagedRootName(derivedName, platform2)) {
      return derivedName;
    }
    return info.channel;
  }
  const candidateNames = [info.channel];
  if (safeManagedRootName(info.name, "macos"))
    candidateNames.push(info.name);
  if (safeManagedRootName(info.displayName, "macos")) {
    candidateNames.push(info.channel === "stable" ? info.displayName : `${info.displayName}-${info.channel}`);
  }
  const candidates = [...new Set(candidateNames)].filter((name) => safeManagedRootName(name, "macos"));
  if (typeof info.hash === "string" && /^[a-z0-9]{1,13}$/.test(info.hash)) {
    const retainedRoot = candidates.find((name) => regularFileProbe(pathApi.join(identifierRoot, name, "self-extraction", `${info.hash}.tar`)));
    if (retainedRoot)
      return retainedRoot;
  }
  const manifestRoot = candidates.find((name) => regularFileProbe(pathApi.join(identifierRoot, name, ".electrobun-uninstall.json")));
  return manifestRoot ?? info.channel;
}
function getInstalledRootName() {
  const info = getVersionInfo();
  const launcherRootName = process.env["ELECTROBUN_INSTALL_ROOT_NAME"];
  if (safeManagedRootName(launcherRootName, OS))
    return launcherRootName;
  return resolveInstalledRootNameForPaths(info, OS, process.execPath, getAppDataDir());
}
function getAppDataDir() {
  switch (OS) {
    case "macos":
      return join(home, "Library", "Application Support");
    case "win":
      return process.env["LOCALAPPDATA"] || join(home, "AppData", "Local");
    case "linux":
      return getLinuxXdgRoot("XDG_DATA_HOME", join(home, ".local", "share"));
  }
}
function getCacheDir() {
  switch (OS) {
    case "macos":
      return join(home, "Library", "Caches");
    case "win":
      return process.env["LOCALAPPDATA"] || join(home, "AppData", "Local");
    case "linux":
      return getLinuxXdgRoot("XDG_CACHE_HOME", join(home, ".cache"));
  }
}
function getLogsDir() {
  switch (OS) {
    case "macos":
      return join(home, "Library", "Logs");
    case "win":
      return process.env["LOCALAPPDATA"] || join(home, "AppData", "Local");
    case "linux":
      return getLinuxXdgRoot("XDG_STATE_HOME", join(home, ".local", "state"));
  }
}
function getLinuxXdgRoot(variable, fallback) {
  const value = process.env[variable];
  if (!value || !isAbsolute(value))
    return fallback;
  const normalized = resolve(value);
  return normalized === "/" ? fallback : normalized;
}
function getConfigDir() {
  switch (OS) {
    case "macos":
      return join(home, "Library", "Application Support");
    case "win":
      return process.env["APPDATA"] || join(home, "AppData", "Roaming");
    case "linux":
      return process.env["XDG_CONFIG_HOME"] || join(home, ".config");
  }
}
function getUserDir(macName, winName, xdgKey, fallbackName) {
  switch (OS) {
    case "macos":
      return join(home, macName);
    case "win": {
      const userProfile = process.env["USERPROFILE"] || home;
      return join(userProfile, winName);
    }
    case "linux":
      return xdgUserDir(xdgKey, fallbackName);
  }
}
var moveToTrash = (path) => {
  return ffi.request.moveToTrash({ path });
}, showItemInFolder = (path) => {
  return ffi.request.showItemInFolder({ path });
}, openExternal = (url) => {
  return ffi.request.openExternal({ url });
}, openPath = (path) => {
  return ffi.request.openPath({ path });
}, setDockIconVisible = (visible) => {
  ffi.request.setDockIconVisible({ visible });
}, isDockIconVisible = () => {
  return ffi.request.isDockIconVisible();
}, showNotification = (options) => {
  const { title, body, subtitle, silent } = options;
  ffi.request.showNotification({ title, body, subtitle, silent });
}, isQuitting = false, quitApprovalBrand, activeQuitApproval = null, requestQuitApproval = () => {
  if (isQuitting || activeQuitApproval)
    return null;
  const approval = Object.freeze({
    [quitApprovalBrand]: true
  });
  activeQuitApproval = approval;
  let beforeQuitEvent;
  try {
    beforeQuitEvent = electrobunEventEmitter.events.app.beforeQuit({});
    electrobunEventEmitter.emitEvent(beforeQuitEvent);
  } catch (error) {
    activeQuitApproval = null;
    throw error;
  }
  if (beforeQuitEvent.responseWasSet && beforeQuitEvent.response?.allow === false) {
    activeQuitApproval = null;
    return null;
  }
  return approval;
}, cancelQuitApproval = (approval) => {
  if (activeQuitApproval === approval)
    activeQuitApproval = null;
}, quitAfterApproval = (approval, code = 0) => {
  if (activeQuitApproval !== approval) {
    throw new Error("Invalid or expired quit approval");
  }
  activeQuitApproval = null;
  isQuitting = true;
  try {
    if (native) {
      ffi.request.quitGracefully({ code, timeoutMs: 5000 });
    } else {
      process.exit(code);
    }
  } catch (error) {
    isQuitting = false;
    throw error;
  }
}, quit = (code = 0) => {
  const approval = requestQuitApproval();
  if (!approval)
    return false;
  quitAfterApproval(approval, code);
  return true;
}, _originalProcessExit, openFileDialog = async (opts = {}) => {
  const optsWithDefault = {
    ...{
      startingFolder: "~/",
      allowedFileTypes: "*",
      canChooseFiles: true,
      canChooseDirectory: true,
      allowsMultipleSelection: true
    },
    ...opts
  };
  const result = await ffi.request.openFileDialog({
    startingFolder: optsWithDefault.startingFolder,
    allowedFileTypes: optsWithDefault.allowedFileTypes,
    canChooseFiles: optsWithDefault.canChooseFiles,
    canChooseDirectory: optsWithDefault.canChooseDirectory,
    allowsMultipleSelection: optsWithDefault.allowsMultipleSelection
  });
  return decodeDialogPaths(result);
}, showMessageBox = async (opts = {}) => {
  const {
    type = "info",
    title = "",
    message = "",
    detail = "",
    buttons = ["OK"],
    defaultId = 0,
    cancelId = -1
  } = opts;
  const response = ffi.request.showMessageBox({
    type,
    title,
    message,
    detail,
    buttons,
    defaultId,
    cancelId
  });
  return { response };
}, clipboardReadText = () => {
  return ffi.request.clipboardReadText();
}, clipboardWriteText = (text) => {
  ffi.request.clipboardWriteText({ text });
}, coreGraphics, screenCapture, clipboardReadImage = () => {
  return ffi.request.clipboardReadImage();
}, clipboardWriteImage = (pngData) => {
  ffi.request.clipboardWriteImage({ pngData });
}, clipboardClear = () => {
  ffi.request.clipboardClear();
}, clipboardAvailableFormats = () => {
  return ffi.request.clipboardAvailableFormats();
}, home, _xdgUserDirs, _versionInfo, paths;
var init_Utils = __esm(() => {
  init_native();
  init_eventEmitter();
  init_platform();
  quitApprovalBrand = Symbol("ElectrobunQuitApproval");
  _originalProcessExit = process.exit;
  process.exit = (code) => {
    if (native) {
      if (isQuitting) {
        ffi.request.quitGracefully({ code: code ?? 0, timeoutMs: 0 });
        return;
      }
      quit(code ?? 0);
    } else {
      _originalProcessExit(code ?? 0);
    }
  };
  coreGraphics = (() => {
    if (OS !== "macos")
      return null;
    try {
      const { dlopen, FFIType } = __require("bun:ffi");
      return dlopen("/System/Library/Frameworks/CoreGraphics.framework/Versions/A/CoreGraphics", {
        CGPreflightScreenCaptureAccess: { args: [], returns: FFIType.bool },
        CGRequestScreenCaptureAccess: { args: [], returns: FFIType.bool }
      });
    } catch {
      return null;
    }
  })();
  screenCapture = {
    hasAccess() {
      if (OS !== "macos")
        return true;
      return coreGraphics ? Boolean(coreGraphics.symbols.CGPreflightScreenCaptureAccess()) : false;
    },
    requestAccess() {
      if (OS !== "macos")
        return true;
      return coreGraphics ? Boolean(coreGraphics.symbols.CGRequestScreenCaptureAccess()) : false;
    },
    openSettings() {
      if (OS !== "macos")
        return;
      Bun.spawn([
        "open",
        "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"
      ]);
    }
  };
  home = homedir();
  paths = {
    get home() {
      return home;
    },
    get appData() {
      return getAppDataDir();
    },
    get config() {
      return getConfigDir();
    },
    get cache() {
      return getCacheDir();
    },
    get temp() {
      return tmpdir();
    },
    get logs() {
      return getLogsDir();
    },
    get documents() {
      return getUserDir("Documents", "Documents", "XDG_DOCUMENTS_DIR", "Documents");
    },
    get downloads() {
      return getUserDir("Downloads", "Downloads", "XDG_DOWNLOAD_DIR", "Downloads");
    },
    get desktop() {
      return getUserDir("Desktop", "Desktop", "XDG_DESKTOP_DIR", "Desktop");
    },
    get pictures() {
      return getUserDir("Pictures", "Pictures", "XDG_PICTURES_DIR", "Pictures");
    },
    get music() {
      return getUserDir("Music", "Music", "XDG_MUSIC_DIR", "Music");
    },
    get videos() {
      return getUserDir("Movies", "Videos", "XDG_VIDEOS_DIR", "Videos");
    },
    get userData() {
      const { identifier } = getVersionInfo();
      return join(getAppDataDir(), identifier, getInstalledRootName());
    },
    get userCache() {
      const { identifier } = getVersionInfo();
      return join(getCacheDir(), identifier, getInstalledRootName());
    },
    get userLogs() {
      const { identifier } = getVersionInfo();
      return join(getLogsDir(), identifier, getInstalledRootName());
    }
  };
});

// .hutch/devkit/api/sdks/main/proc/native.ts
import { dirname, join as join2 } from "path";
import { closeSync } from "fs";
import { Socket } from "net";
import {
  dlopen,
  suffix,
  JSCallback,
  CString as CString2,
  ptr,
  FFIType,
  toArrayBuffer
} from "bun:ffi";
function storeMenuData(data) {
  const id = `menuData_${++menuDataCounter}`;
  menuDataRegistry.set(id, data);
  return id;
}
function getMenuData(id) {
  return menuDataRegistry.get(id);
}
function clearMenuData(id) {
  menuDataRegistry.delete(id);
}
function serializeMenuAction(action, data) {
  const dataId = storeMenuData(data);
  return `${ELECTROBUN_DELIMITER}${dataId}|${action}`;
}
function deserializeMenuAction(encodedAction) {
  let actualAction = encodedAction;
  let data = undefined;
  if (encodedAction.startsWith(ELECTROBUN_DELIMITER)) {
    const parts = encodedAction.split("|");
    if (parts.length >= 4) {
      const dataId = parts[2];
      actualAction = parts.slice(3).join("|");
      data = getMenuData(dataId);
      clearMenuData(dataId);
    }
  }
  return { action: actualAction, data };
}
function getElectrobunLibraryPathCandidates(fileName) {
  const candidates = new Set;
  candidates.add(join2(process.cwd(), fileName));
  if (process.argv0) {
    candidates.add(join2(dirname(process.argv0), fileName));
  }
  return Array.from(candidates);
}
function tryDlopenCandidates(fileName, symbols) {
  let lastError = null;
  for (const candidatePath of getElectrobunLibraryPathCandidates(fileName)) {
    try {
      return dlopen(candidatePath, symbols);
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError ?? new Error(`Failed to load ${fileName}`);
}
function normalizeFFIPointer(value) {
  if (value === null || value === undefined || value === 0 || value === 0n) {
    return null;
  }
  if (typeof value !== "bigint")
    return value;
  const numericPointer = Number(value);
  if (!Number.isSafeInteger(numericPointer)) {
    throw new RangeError("FFI pointer exceeds JavaScript's safe integer range");
  }
  return numericPointer;
}
function getWindowPtr(winId) {
  return normalizeFFIPointer(core?.symbols.getWindowPointer(winId));
}
function getCoreLastError() {
  const error = core?.symbols.electrobun_core_last_error();
  if (!error) {
    return null;
  }
  const message = error.toString();
  return message.length > 0 ? message : null;
}
function ensureWebviewRuntimeConfigured() {
  if (webviewRuntimeConfigured) {
    return;
  }
  const configured = core?.symbols.configureWebviewRuntime(0, toCString(preloadScript), toCString(preloadScriptSandboxed));
  if (!configured) {
    throw getCoreLastError() || "Failed to configure webview runtime";
  }
  webviewRuntimeConfigured = true;
}

class PostMessageBridge {
  requestId = 0;
  pendingRequests = new Map;
  eventHandlers = new Map;
  constructor() {
    if (typeof self !== "undefined" && typeof self.addEventListener === "function") {
      self.addEventListener("message", (event) => {
        this.handleMessage(event.data);
      });
    }
  }
  sendAction(action, payload) {
    self.postMessage({ type: "action", action, payload });
  }
  requestHost(method, params) {
    const id = ++this.requestId;
    self.postMessage({ type: "host-request", requestId: id, method, params });
    return new Promise((resolve2, reject) => {
      this.pendingRequests.set(id, {
        resolve: (v) => resolve2(v),
        reject
      });
    });
  }
  on(name, handler) {
    const handlers = this.eventHandlers.get(name) ?? new Set;
    handlers.add(handler);
    this.eventHandlers.set(name, handlers);
    return () => {
      handlers.delete(handler);
      if (handlers.size === 0)
        this.eventHandlers.delete(name);
    };
  }
  emit(name, payload) {
    this.eventHandlers.get(name)?.forEach((h) => {
      try {
        h(payload);
      } catch (e) {
        console.error(`[bridge] event handler failed: ${name}`, e);
      }
    });
  }
  handleMessage(message) {
    if (!message || typeof message !== "object" || !("type" in message))
      return;
    if (message.type === "host-response") {
      const pending = this.pendingRequests.get(message.requestId);
      if (!pending)
        return;
      this.pendingRequests.delete(message.requestId);
      if (message.success) {
        pending.resolve(message.payload);
      } else {
        pending.reject(new Error(message.error || "Host request failed"));
      }
    } else if (message.type === "event") {
      this.emit(message.name, message.payload);
    } else if (message.type === "init") {
      this.emit("init", message);
    }
  }
}
function createFfiRequestProxy(ffiRequest) {
  if (hasFFI)
    return ffiRequest;
  return new Proxy(ffiRequest, {
    get(target, method) {
      if (typeof method !== "string")
        return target[method];
      return (params) => {
        if (!bridge) {
          const loadFailures = [
            ["ElectrobunCore", coreLoadError],
            ["NativeWrapper", nativeWrapperLoadError]
          ].filter((entry) => entry[1] !== null).map(([library, error]) => `${library}: ${error instanceof Error ? error.message : String(error)}`);
          const loadFailureDetail = loadFailures.length > 0 ? ` (${loadFailures.join("; ")})` : "";
          throw new Error(`Electrobun FFI is unavailable and no host bridge exists for request ${method}${loadFailureDetail}`);
        }
        return bridge.requestHost(method, params);
      };
    }
  });
}
function getDarwinNativeWrapperSymbols() {
  return native_.symbols;
}
function getWindowsNativeWrapperSymbols() {
  return native_.symbols;
}

class SessionCookies {
  partitionId;
  constructor(partitionId) {
    this.partitionId = partitionId;
  }
  get(filter) {
    const filterJson = JSON.stringify(filter || {});
    const result = native_.symbols.sessionGetCookies(toCString(this.partitionId), toCString(filterJson));
    if (!result)
      return [];
    try {
      return JSON.parse(result.toString());
    } catch {
      return [];
    }
  }
  set(cookie) {
    const cookieJson = JSON.stringify(cookie);
    return native_.symbols.sessionSetCookie(toCString(this.partitionId), toCString(cookieJson));
  }
  remove(url, name) {
    return native_.symbols.sessionRemoveCookie(toCString(this.partitionId), toCString(url), toCString(name));
  }
  clear() {
    native_.symbols.sessionClearCookies(toCString(this.partitionId));
  }
}

class SessionInstance {
  partition;
  cookies;
  constructor(partition) {
    this.partition = partition;
    this.cookies = new SessionCookies(partition);
  }
  clearStorageData(types = "all") {
    const typesArray = types === "all" ? ["all"] : types;
    native_.symbols.sessionClearStorageData(toCString(this.partition), toCString(JSON.stringify(typesArray)));
  }
}
function toCString(jsString, addNullTerminator = true) {
  let appendWith = "";
  if (addNullTerminator && !jsString.endsWith("\x00")) {
    appendWith = "\x00";
  }
  const buff = Buffer.from(jsString + appendWith, "utf8");
  return ptr(buff);
}
var menuDataRegistry, menuDataCounter = 0, ELECTROBUN_DELIMITER = "|EB|", webviewRuntimeConfigured = false, coreLoadError = null, core, nativeWrapperLoadError = null, native, hasFFI, isCarrotWorker, bridge, core_, native_, HOST_MESSAGE_BATCH_SIZE = 256, HOST_MESSAGE_BATCHES_PER_TURN = 4, HOST_MESSAGE_BATCH_ERROR_LENGTH = 4294967295, queuedHostMessageBatchLengthBuf, readOwnedRuntimeCallbackPayload = (messagePointer) => {
  try {
    return new CString2(messagePointer).toString();
  } finally {
    core_.symbols.releaseRuntimeCallbackPayload(messagePointer);
  }
}, scheduledHostMessageDrain, scheduleHostMessageDrain = (delay) => {
  if (scheduledHostMessageDrain !== undefined) {
    return;
  }
  scheduledHostMessageDrain = setTimeout(() => {
    scheduledHostMessageDrain = undefined;
    drainQueuedHostMessages();
  }, delay);
}, drainQueuedHostMessages = () => {
  if (!core) {
    return;
  }
  for (let batchIndex = 0;batchIndex < HOST_MESSAGE_BATCHES_PER_TURN; batchIndex++) {
    const messagePtr = core_.symbols.popQueuedHostMessageBatch(HOST_MESSAGE_BATCH_SIZE, ptr(queuedHostMessageBatchLengthBuf));
    if (!messagePtr) {
      if (queuedHostMessageBatchLengthBuf[0] === HOST_MESSAGE_BATCH_ERROR_LENGTH) {
        console.error("failed to pop queued host message batch:", getCoreLastError() ?? "unknown core error");
        scheduleHostMessageDrain(16);
      }
      return;
    }
    try {
      const entries = JSON.parse(new CString2(messagePtr, 0, queuedHostMessageBatchLengthBuf[0]).toString());
      for (const { webviewId, message } of entries) {
        try {
          const webview = BrowserView.ensureWrapped(webviewId);
          if (!webview) {
            continue;
          }
          webview.rpcHandler?.(JSON.parse(message));
        } catch (err) {
          console.error("error draining queued host message:", {
            webviewId,
            messagePreview: message.slice(0, 500),
            error: err instanceof Error ? { name: err.name, message: err.message, stack: err.stack } : err
          });
        }
      }
    } catch (err) {
      console.error("error decoding queued host message batch:", {
        error: err instanceof Error ? { name: err.name, message: err.message, stack: err.stack } : err
      });
    } finally {
      core_.symbols.freeCoreString(messagePtr);
    }
  }
  scheduleHostMessageDrain(0);
}, hostMessagePollingStarted = false, startHostMessagePolling = (error) => {
  if (hostMessagePollingStarted) {
    return;
  }
  hostMessagePollingStarted = true;
  const code = error && typeof error === "object" && "code" in error ? String(error.code) : "";
  if (error && code !== "EAGAIN") {
    console.error("host message wakeup stream failed, falling back to polling:", error);
  }
  setInterval(drainQueuedHostMessages, 16);
  drainQueuedHostMessages();
}, _ffiImpl, ffi, WGPUBridge, windowCloseCallback, windowShouldCloseCallback, windowMoveCallback, windowResizeCallback, windowFocusCallback, windowBlurCallback, wgpuPointerCallback, wgpuKeyCallback, windowTextCallback, windowKeyCallback, getMimeType, getHTMLForWebviewSync, globalShortcutHandlers, GlobalShortcut, Screen, sessionCache, Session, webviewDecideNavigation, webviewEventHandler = (id, eventName, detail) => {
  BrowserView.ensureWrapped(id);
  core_.symbols.dispatchHostWebviewEvent(id, toCString(eventName), toCString(detail));
  const eventMap = {
    "will-navigate": "willNavigate",
    "did-navigate": "didNavigate",
    "did-navigate-in-page": "didNavigateInPage",
    "did-commit-navigation": "didCommitNavigation",
    "dom-ready": "domReady",
    "new-window-open": "newWindowOpen",
    "host-message": "hostMessage",
    "download-started": "downloadStarted",
    "download-progress": "downloadProgress",
    "download-completed": "downloadCompleted",
    "download-failed": "downloadFailed",
    "load-started": "loadStarted",
    "load-committed": "loadCommitted",
    "load-finished": "loadFinished"
  };
  const mappedName = eventMap[eventName];
  const handler = mappedName ? eventEmitter_default.events.webview[mappedName] : undefined;
  if (!handler) {
    return { success: false };
  }
  let parsedDetail = detail;
  if (eventName === "new-window-open" || eventName === "host-message" || eventName === "download-started" || eventName === "download-progress" || eventName === "download-completed" || eventName === "download-failed") {
    try {
      parsedDetail = JSON.parse(detail);
    } catch (e) {
      console.error("[webviewEventHandler] Failed to parse JSON:", e);
      parsedDetail = detail;
    }
  }
  const event = handler({
    detail: parsedDetail
  });
  eventEmitter_default.emitEvent(event);
  eventEmitter_default.emitEvent(event, id);
}, webviewEventJSCallback, hostBridgePostmessageHandler, eventBridgeHandler, internalBridgeHandler, trayItemHandler, applicationMenuHandler, contextMenuHandler, internalRpcHandlers;
var init_native = __esm(() => {
  init_eventEmitter();
  init_BrowserView();
  init_WGPUView();
  init_ffiCString();
  init_nativeTextBitmap();
  menuDataRegistry = new Map;
  core = (() => {
    try {
      const coreFileName = process.platform === "win32" ? "ElectrobunCore.dll" : `libElectrobunCore.${suffix}`;
      return tryDlopenCandidates(coreFileName, {
        electrobun_core_last_error: {
          args: [],
          returns: FFIType.cstring
        },
        getWindowStyle: {
          args: [
            FFIType.bool,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool
          ],
          returns: FFIType.u32
        },
        createWindow: {
          args: [
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.u32,
            FFIType.cstring,
            FFIType.bool,
            FFIType.cstring,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool,
            FFIType.f64,
            FFIType.f64,
            FFIType.function,
            FFIType.function,
            FFIType.function,
            FFIType.function,
            FFIType.function,
            FFIType.function,
            FFIType.function
          ],
          returns: FFIType.u32
        },
        getWindowPointer: {
          args: [FFIType.u32],
          returns: FFIType.ptr
        },
        setWindowTitle: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.void
        },
        minimizeWindow: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        restoreWindow: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        isWindowMinimized: {
          args: [FFIType.u32],
          returns: FFIType.bool
        },
        maximizeWindow: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        unmaximizeWindow: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        isWindowMaximized: {
          args: [FFIType.u32],
          returns: FFIType.bool
        },
        showWindow: {
          args: [FFIType.u32, FFIType.bool],
          returns: FFIType.void
        },
        activateWindow: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        hideWindow: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        isWindowVisible: {
          args: [FFIType.u32],
          returns: FFIType.bool
        },
        closeWindow: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        requestWindowClose: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        setWindowFullScreen: {
          args: [FFIType.u32, FFIType.bool],
          returns: FFIType.void
        },
        isWindowFullScreen: {
          args: [FFIType.u32],
          returns: FFIType.bool
        },
        setWindowAlwaysOnTop: {
          args: [FFIType.u32, FFIType.bool],
          returns: FFIType.void
        },
        isWindowAlwaysOnTop: {
          args: [FFIType.u32],
          returns: FFIType.bool
        },
        setWindowVisibleOnAllWorkspaces: {
          args: [FFIType.u32, FFIType.bool],
          returns: FFIType.void
        },
        isWindowVisibleOnAllWorkspaces: {
          args: [FFIType.u32],
          returns: FFIType.bool
        },
        setWindowPosition: {
          args: [FFIType.u32, FFIType.f64, FFIType.f64],
          returns: FFIType.void
        },
        centerWindow: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        setWindowButtonPosition: {
          args: [FFIType.u32, FFIType.f64, FFIType.f64],
          returns: FFIType.void
        },
        getWindowButtonPosition: {
          args: [FFIType.u32, FFIType.ptr, FFIType.ptr],
          returns: FFIType.void
        },
        setWindowSize: {
          args: [FFIType.u32, FFIType.f64, FFIType.f64],
          returns: FFIType.void
        },
        setWindowFrame: {
          args: [FFIType.u32, FFIType.f64, FFIType.f64, FFIType.f64, FFIType.f64],
          returns: FFIType.void
        },
        getWindowFrame: {
          args: [FFIType.u32, FFIType.ptr, FFIType.ptr, FFIType.ptr, FFIType.ptr],
          returns: FFIType.void
        },
        getWindowContentOrigin: {
          args: [FFIType.u32, FFIType.ptr, FFIType.ptr],
          returns: FFIType.void
        },
        configureWebviewRuntime: {
          args: [
            FFIType.u32,
            FFIType.cstring,
            FFIType.cstring
          ],
          returns: FFIType.bool
        },
        createWebview: {
          args: [
            FFIType.u32,
            FFIType.u32,
            FFIType.cstring,
            FFIType.cstring,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.bool,
            FFIType.cstring,
            FFIType.function,
            FFIType.function,
            FFIType.function,
            FFIType.function,
            FFIType.function,
            FFIType.cstring,
            FFIType.cstring,
            FFIType.cstring,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool
          ],
          returns: FFIType.u32
        },
        setNextWebviewAllowedProtocols: {
          args: [FFIType.bool, FFIType.bool],
          returns: FFIType.void
        },
        getWebviewPointer: {
          args: [FFIType.u32],
          returns: FFIType.ptr
        },
        resizeWebview: {
          args: [
            FFIType.u32,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.cstring
          ],
          returns: FFIType.void
        },
        loadURLInWebView: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.void
        },
        loadHTMLInWebView: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.void
        },
        updatePreloadScriptToWebView: {
          args: [FFIType.u32, FFIType.cstring, FFIType.cstring, FFIType.bool],
          returns: FFIType.void
        },
        webviewCanGoBack: {
          args: [FFIType.u32],
          returns: FFIType.bool
        },
        webviewCanGoForward: {
          args: [FFIType.u32],
          returns: FFIType.bool
        },
        webviewGoBack: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        webviewGoForward: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        webviewReload: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        webviewRemove: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        setWebviewHTMLContent: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.void
        },
        webviewSetTransparent: {
          args: [FFIType.u32, FFIType.bool],
          returns: FFIType.void
        },
        webviewSetPassthrough: {
          args: [FFIType.u32, FFIType.bool],
          returns: FFIType.void
        },
        webviewSetHidden: {
          args: [FFIType.u32, FFIType.bool],
          returns: FFIType.void
        },
        webviewSetSpellCheck: {
          args: [FFIType.u32, FFIType.bool],
          returns: FFIType.bool
        },
        setWebviewNavigationRules: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.void
        },
        webviewFindInPage: {
          args: [FFIType.u32, FFIType.cstring, FFIType.bool, FFIType.bool],
          returns: FFIType.void
        },
        webviewStopFind: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        evaluateJavaScriptWithNoCompletion: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.void
        },
        sendHostMessageToWebviewViaTransport: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.bool
        },
        sendPreEncryptedHostMessageToWebviewViaTransport: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.bool
        },
        popNextQueuedHostMessage: {
          args: [FFIType.ptr],
          returns: FFIType.ptr
        },
        popQueuedHostMessageBatch: {
          args: [FFIType.u32, FFIType.ptr],
          returns: FFIType.ptr
        },
        getHostMessageWakeupReadFD: {
          args: [],
          returns: FFIType.int
        },
        duplicateHostMessageWakeupReadFD: {
          args: [],
          returns: FFIType.int
        },
        freeCoreString: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        setRuntimeCallbacksAsync: {
          args: [FFIType.bool],
          returns: FFIType.void
        },
        releaseRuntimeCallbackPayload: {
          args: [FFIType.ptr],
          returns: FFIType.bool
        },
        clearWebviewHostTransport: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        dispatchHostWebviewEvent: {
          args: [FFIType.u32, FFIType.cstring, FFIType.cstring],
          returns: FFIType.bool
        },
        sendInternalMessageToWebview: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.bool
        },
        webviewOpenDevTools: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        webviewCloseDevTools: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        webviewToggleDevTools: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        webviewSetPageZoom: {
          args: [FFIType.u32, FFIType.f64],
          returns: FFIType.void
        },
        webviewGetPageZoom: {
          args: [FFIType.u32],
          returns: FFIType.f64
        },
        createWGPUView: {
          args: [
            FFIType.u32,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool
          ],
          returns: FFIType.u32
        },
        getWGPUViewPointer: {
          args: [FFIType.u32],
          returns: FFIType.ptr
        },
        setWGPUViewFrame: {
          args: [FFIType.u32, FFIType.f64, FFIType.f64, FFIType.f64, FFIType.f64],
          returns: FFIType.void
        },
        resizeWGPUView: {
          args: [FFIType.u32, FFIType.f64, FFIType.f64, FFIType.f64, FFIType.f64, FFIType.cstring],
          returns: FFIType.void
        },
        setWGPUViewTransparent: {
          args: [FFIType.u32, FFIType.bool],
          returns: FFIType.void
        },
        setWGPUViewPassthrough: {
          args: [FFIType.u32, FFIType.bool],
          returns: FFIType.void
        },
        setWGPUViewHidden: {
          args: [FFIType.u32, FFIType.bool],
          returns: FFIType.void
        },
        removeWGPUView: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        getWGPUViewNativeHandle: {
          args: [FFIType.u32],
          returns: FFIType.ptr
        },
        runWGPUViewTest: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        wgpuReleaseSurfaceForView: {
          args: [FFIType.ptr],
          returns: FFIType.bool
        },
        createTray: {
          args: [
            FFIType.cstring,
            FFIType.cstring,
            FFIType.bool,
            FFIType.u32,
            FFIType.u32,
            FFIType.function
          ],
          returns: FFIType.u32
        },
        showTray: {
          args: [FFIType.u32],
          returns: FFIType.bool
        },
        hideTray: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        setTrayTitle: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.void
        },
        setTrayImage: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.void
        },
        setTrayMenu: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.void
        },
        removeTray: {
          args: [FFIType.u32],
          returns: FFIType.void
        },
        getTrayBounds: {
          args: [FFIType.u32],
          returns: FFIType.cstring
        },
        setApplicationMenu: {
          args: [FFIType.cstring, FFIType.function],
          returns: FFIType.void
        },
        showContextMenu: {
          args: [FFIType.cstring, FFIType.function],
          returns: FFIType.void
        },
        moveToTrash: {
          args: [FFIType.cstring],
          returns: FFIType.bool
        },
        showItemInFolder: {
          args: [FFIType.cstring],
          returns: FFIType.void
        },
        openExternal: {
          args: [FFIType.cstring],
          returns: FFIType.bool
        },
        openPath: {
          args: [FFIType.cstring],
          returns: FFIType.bool
        },
        showNotification: {
          args: [
            FFIType.cstring,
            FFIType.cstring,
            FFIType.cstring,
            FFIType.bool
          ],
          returns: FFIType.void
        },
        getAllDisplays: {
          args: [],
          returns: FFIType.cstring
        },
        getPrimaryDisplay: {
          args: [],
          returns: FFIType.cstring
        },
        getCursorScreenPoint: {
          args: [],
          returns: FFIType.cstring
        },
        captureScreenRegion: {
          args: [
            FFIType.f64,
            FFIType.f64,
            FFIType.u32,
            FFIType.u32,
            FFIType.ptr,
            FFIType.u64
          ],
          returns: FFIType.bool
        },
        getMouseButtons: {
          args: [],
          returns: FFIType.u64
        },
        openFileDialog: {
          args: [
            FFIType.cstring,
            FFIType.cstring,
            FFIType.int,
            FFIType.int,
            FFIType.int
          ],
          returns: FFIType.cstring
        },
        showMessageBox: {
          args: [
            FFIType.cstring,
            FFIType.cstring,
            FFIType.cstring,
            FFIType.cstring,
            FFIType.cstring,
            FFIType.int,
            FFIType.int
          ],
          returns: FFIType.int
        },
        clipboardReadText: {
          args: [],
          returns: FFIType.cstring
        },
        clipboardWriteText: {
          args: [FFIType.cstring],
          returns: FFIType.void
        },
        clipboardReadImage: {
          args: [FFIType.ptr],
          returns: FFIType.ptr
        },
        clipboardWriteImage: {
          args: [FFIType.ptr, FFIType.u64],
          returns: FFIType.void
        },
        clipboardClear: {
          args: [],
          returns: FFIType.void
        },
        clipboardAvailableFormats: {
          args: [],
          returns: FFIType.cstring
        },
        setDockIconVisible: {
          args: [FFIType.bool],
          returns: FFIType.void
        },
        isDockIconVisible: {
          args: [],
          returns: FFIType.bool
        },
        setExitOnLastWindowClosed: {
          args: [FFIType.bool],
          returns: FFIType.void
        },
        setQuitRequestedHandler: {
          args: [FFIType.function],
          returns: FFIType.void
        },
        quitGracefully: {
          args: [FFIType.i32, FFIType.i32],
          returns: FFIType.void
        }
      });
    } catch (err) {
      coreLoadError = err;
      return null;
    }
  })();
  native = (() => {
    try {
      const nativeWrapperFileName = `libNativeWrapper.${suffix}`;
      return tryDlopenCandidates(nativeWrapperFileName, {
        initWebview: {
          args: [
            FFIType.u32,
            FFIType.ptr,
            FFIType.cstring,
            FFIType.cstring,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.bool,
            FFIType.cstring,
            FFIType.function,
            FFIType.function,
            FFIType.function,
            FFIType.function,
            FFIType.function,
            FFIType.cstring,
            FFIType.cstring,
            FFIType.cstring,
            FFIType.bool,
            FFIType.bool
          ],
          returns: FFIType.ptr
        },
        initWGPUView: {
          args: [
            FFIType.u32,
            FFIType.ptr,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.bool,
            FFIType.bool,
            FFIType.bool
          ],
          returns: FFIType.ptr
        },
        setNextWebviewFlags: {
          args: [
            FFIType.bool,
            FFIType.bool
          ],
          returns: FFIType.void
        },
        webviewCanGoBack: {
          args: [FFIType.ptr],
          returns: FFIType.bool
        },
        webviewCanGoForward: {
          args: [FFIType.ptr],
          returns: FFIType.bool
        },
        resizeWebview: {
          args: [
            FFIType.ptr,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.cstring
          ],
          returns: FFIType.void
        },
        ...process.platform === "darwin" ? {
          wgpuViewSetAlphaBlending: {
            args: [FFIType.ptr, FFIType.bool],
            returns: FFIType.void
          },
          setWGPUPointerHandler: {
            args: [FFIType.ptr],
            returns: FFIType.void
          },
          setWGPUKeyHandler: {
            args: [FFIType.ptr],
            returns: FFIType.void
          },
          uiMeasureText: {
            args: [
              FFIType.cstring,
              FFIType.cstring,
              FFIType.f64,
              FFIType.ptr,
              FFIType.ptr,
              FFIType.ptr
            ],
            returns: FFIType.void
          },
          uiRasterizeText: {
            args: [
              FFIType.cstring,
              FFIType.cstring,
              FFIType.f64,
              FFIType.f64,
              FFIType.ptr,
              FFIType.ptr
            ],
            returns: FFIType.ptr
          },
          uiFreeTextBitmap: {
            args: [FFIType.ptr],
            returns: FFIType.void
          }
        } : {},
        ...process.platform === "win32" ? {
          getWindowContentSize: {
            args: [FFIType.ptr, FFIType.ptr, FFIType.ptr],
            returns: FFIType.void
          },
          setWindowTextHandler: {
            args: [FFIType.ptr],
            returns: FFIType.void
          }
        } : {},
        loadURLInWebView: {
          args: [FFIType.ptr, FFIType.cstring],
          returns: FFIType.void
        },
        loadHTMLInWebView: {
          args: [FFIType.ptr, FFIType.cstring],
          returns: FFIType.void
        },
        updatePreloadScriptToWebView: {
          args: [
            FFIType.ptr,
            FFIType.cstring,
            FFIType.cstring,
            FFIType.bool
          ],
          returns: FFIType.void
        },
        webviewGoBack: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        webviewGoForward: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        webviewReload: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        webviewRemove: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        setWebviewHTMLContent: {
          args: [FFIType.u32, FFIType.cstring],
          returns: FFIType.void
        },
        startWindowMove: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        stopWindowMove: {
          args: [],
          returns: FFIType.void
        },
        webviewSetTransparent: {
          args: [FFIType.ptr, FFIType.bool],
          returns: FFIType.void
        },
        webviewSetPassthrough: {
          args: [FFIType.ptr, FFIType.bool],
          returns: FFIType.void
        },
        webviewSetHidden: {
          args: [FFIType.ptr, FFIType.bool],
          returns: FFIType.void
        },
        setWebviewNavigationRules: {
          args: [FFIType.ptr, FFIType.cstring],
          returns: FFIType.void
        },
        webviewFindInPage: {
          args: [FFIType.ptr, FFIType.cstring, FFIType.bool, FFIType.bool],
          returns: FFIType.void
        },
        webviewStopFind: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        evaluateJavaScriptWithNoCompletion: {
          args: [FFIType.ptr, FFIType.cstring],
          returns: FFIType.void
        },
        webviewOpenDevTools: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        webviewCloseDevTools: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        webviewToggleDevTools: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        webviewSetPageZoom: {
          args: [FFIType.ptr, FFIType.f64],
          returns: FFIType.void
        },
        webviewGetPageZoom: {
          args: [FFIType.ptr],
          returns: FFIType.f64
        },
        wgpuViewSetFrame: {
          args: [
            FFIType.ptr,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64,
            FFIType.f64
          ],
          returns: FFIType.void
        },
        wgpuViewSetTransparent: {
          args: [FFIType.ptr, FFIType.bool],
          returns: FFIType.void
        },
        wgpuViewSetPassthrough: {
          args: [FFIType.ptr, FFIType.bool],
          returns: FFIType.void
        },
        wgpuViewSetHidden: {
          args: [FFIType.ptr, FFIType.bool],
          returns: FFIType.void
        },
        wgpuViewRemove: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        wgpuViewGetNativeHandle: {
          args: [FFIType.ptr],
          returns: FFIType.ptr
        },
        wgpuInstanceCreateSurfaceMainThread: {
          args: [FFIType.ptr, FFIType.ptr],
          returns: FFIType.ptr
        },
        wgpuSurfaceConfigureMainThread: {
          args: [FFIType.ptr, FFIType.ptr],
          returns: FFIType.void
        },
        wgpuSurfaceCapabilitiesFreeMembersShim: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        wgpuSurfaceGetCurrentTextureMainThread: {
          args: [FFIType.ptr, FFIType.ptr],
          returns: FFIType.void
        },
        wgpuSurfacePresentMainThread: {
          args: [FFIType.ptr],
          returns: FFIType.i32
        },
        wgpuQueueOnSubmittedWorkDoneShim: {
          args: [FFIType.ptr, FFIType.ptr],
          returns: FFIType.u64
        },
        wgpuBufferMapAsyncShim: {
          args: [FFIType.ptr, FFIType.u64, FFIType.u64, FFIType.u64, FFIType.ptr],
          returns: FFIType.u64
        },
        wgpuInstanceWaitAnyShim: {
          args: [FFIType.ptr, FFIType.u64, FFIType.u64],
          returns: FFIType.i32
        },
        wgpuBufferReadSyncShim: {
          args: [FFIType.ptr, FFIType.ptr, FFIType.u64, FFIType.u64, FFIType.u64, FFIType.ptr],
          returns: FFIType.ptr
        },
        wgpuBufferReadSyncIntoShim: {
          args: [FFIType.ptr, FFIType.ptr, FFIType.u64, FFIType.u64, FFIType.u64, FFIType.ptr],
          returns: FFIType.i32
        },
        wgpuBufferReadbackBeginShim: {
          args: [FFIType.ptr, FFIType.u64, FFIType.u64, FFIType.ptr],
          returns: FFIType.ptr
        },
        wgpuBufferReadbackStatusShim: {
          args: [FFIType.ptr],
          returns: FFIType.i32
        },
        wgpuBufferReadbackFreeShim: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        wgpuRunGPUTest: {
          args: [FFIType.ptr],
          returns: FFIType.void
        },
        wgpuCreateAdapterDeviceMainThread: {
          args: [FFIType.ptr, FFIType.ptr, FFIType.ptr],
          returns: FFIType.void
        },
        wgpuCreateSurfaceForView: {
          args: [FFIType.ptr, FFIType.ptr],
          returns: FFIType.ptr
        },
        setGlobalShortcutCallback: {
          args: [FFIType.function],
          returns: FFIType.void
        },
        registerGlobalShortcut: {
          args: [FFIType.cstring],
          returns: FFIType.bool
        },
        unregisterGlobalShortcut: {
          args: [FFIType.cstring],
          returns: FFIType.bool
        },
        unregisterAllGlobalShortcuts: {
          args: [],
          returns: FFIType.void
        },
        isGlobalShortcutRegistered: {
          args: [FFIType.cstring],
          returns: FFIType.bool
        },
        sessionGetCookies: {
          args: [FFIType.cstring, FFIType.cstring],
          returns: FFIType.cstring
        },
        sessionSetCookie: {
          args: [FFIType.cstring, FFIType.cstring],
          returns: FFIType.bool
        },
        sessionRemoveCookie: {
          args: [FFIType.cstring, FFIType.cstring, FFIType.cstring],
          returns: FFIType.bool
        },
        sessionClearCookies: {
          args: [FFIType.cstring],
          returns: FFIType.void
        },
        sessionClearStorageData: {
          args: [FFIType.cstring, FFIType.cstring],
          returns: FFIType.void
        },
        setURLOpenHandler: {
          args: [FFIType.function],
          returns: FFIType.void
        },
        setAppReopenHandler: {
          args: [FFIType.function],
          returns: FFIType.void
        },
        setJSUtils: {
          args: [
            FFIType.function,
            FFIType.function
          ],
          returns: FFIType.void
        },
        setWindowIcon: {
          args: [
            FFIType.ptr,
            FFIType.cstring
          ],
          returns: FFIType.void
        },
        killApp: {
          args: [],
          returns: FFIType.void
        },
        stopEventLoop: {
          args: [],
          returns: FFIType.void
        },
        waitForShutdownComplete: {
          args: [FFIType.i32],
          returns: FFIType.void
        },
        forceExit: {
          args: [FFIType.i32],
          returns: FFIType.void
        },
        setQuitRequestedHandler: {
          args: [FFIType.function],
          returns: FFIType.void
        },
        testFFI2: {
          args: [FFIType.function],
          returns: FFIType.void
        }
      });
    } catch (err) {
      nativeWrapperLoadError = err;
      return null;
    }
  })();
  hasFFI = native !== null && core !== null;
  isCarrotWorker = !!globalThis.__bunnyCarrotBootstrap;
  bridge = isCarrotWorker ? new PostMessageBridge : null;
  core_ = core;
  native_ = native;
  core?.symbols.setRuntimeCallbacksAsync(true);
  queuedHostMessageBatchLengthBuf = new Uint32Array(1);
  if (core) {
    const wakeupReadFd = core_.symbols.getHostMessageWakeupReadFD();
    const isRealBunRuntime = typeof process.versions?.["cottontail"] !== "string" && typeof process.versions?.bun === "string";
    if (isRealBunRuntime) {
      startHostMessagePolling();
    } else if (typeof wakeupReadFd === "number" && wakeupReadFd >= 0) {
      const ownedFd = core_.symbols.duplicateHostMessageWakeupReadFD();
      let wakeupStream;
      try {
        if (ownedFd < 0)
          throw new Error("could not duplicate host message readiness descriptor");
        wakeupStream = new Socket({ fd: ownedFd, readable: true, writable: false });
        wakeupStream.on("data", () => {
          drainQueuedHostMessages();
        });
        wakeupStream.on("error", (error) => {
          wakeupStream?.destroy();
          startHostMessagePolling(error);
        });
        wakeupStream.on("end", () => startHostMessagePolling());
        wakeupStream.on("close", () => startHostMessagePolling());
      } catch (error) {
        if (wakeupStream)
          wakeupStream.destroy();
        else if (ownedFd >= 0) {
          try {
            closeSync(ownedFd);
          } catch {}
        }
        startHostMessagePolling(error);
      }
    } else {
      startHostMessagePolling();
    }
    drainQueuedHostMessages();
  }
  _ffiImpl = {
    request: {
      createWindow: (params) => {
        const {
          url: _url,
          title,
          frame: { x, y, width, height },
          styleMask: {
            Borderless,
            Titled,
            Closable,
            Miniaturizable,
            Resizable,
            UnifiedTitleAndToolbar,
            FullScreen,
            FullSizeContentView,
            UtilityWindow,
            DocModalWindow,
            NonactivatingPanel,
            HUDWindow
          },
          titleBarStyle,
          transparent,
          hidden = false,
          activate = true,
          centered = false,
          trafficLightOffset = { x: 0, y: 0 }
        } = params;
        const styleMask = core_.symbols.getWindowStyle(Borderless, Titled, Closable, Miniaturizable, Resizable, UnifiedTitleAndToolbar, FullScreen, FullSizeContentView, UtilityWindow, DocModalWindow, NonactivatingPanel, HUDWindow);
        const windowId = core_.symbols.createWindow(x, y, width, height, styleMask, toCString(titleBarStyle), transparent, toCString(title), hidden, activate, centered, trafficLightOffset.x, trafficLightOffset.y, windowCloseCallback, windowMoveCallback, windowResizeCallback, windowFocusCallback, windowBlurCallback, windowKeyCallback, windowShouldCloseCallback);
        if (!windowId) {
          throw getCoreLastError() || "Failed to create window";
        }
        return windowId;
      },
      getWindowPointer: (params) => {
        return getWindowPtr(params.winId);
      },
      setTitle: (params) => {
        const { winId, title } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't set window title. Window no longer exists`;
        }
        core_.symbols.setWindowTitle(winId, toCString(title));
      },
      closeWindow: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          return;
        }
        core_.symbols.closeWindow(winId);
      },
      requestWindowClose: (params) => {
        if (!getWindowPtr(params.winId))
          return;
        core_.symbols.requestWindowClose(params.winId);
      },
      showWindow: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't show window. Window no longer exists`;
        }
        core_.symbols.showWindow(winId, params.activate ?? true);
      },
      activateWindow: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't activate window. Window no longer exists`;
        }
        core_.symbols.activateWindow(winId);
      },
      hideWindow: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't hide window. Window no longer exists`;
        }
        core_.symbols.hideWindow(winId);
      },
      isWindowVisible: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          return false;
        }
        return core_.symbols.isWindowVisible(winId);
      },
      minimizeWindow: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't minimize window. Window no longer exists`;
        }
        core_.symbols.minimizeWindow(winId);
      },
      restoreWindow: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't restore window. Window no longer exists`;
        }
        core_.symbols.restoreWindow(winId);
      },
      isWindowMinimized: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          return false;
        }
        return core_.symbols.isWindowMinimized(winId);
      },
      maximizeWindow: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't maximize window. Window no longer exists`;
        }
        core_.symbols.maximizeWindow(winId);
      },
      unmaximizeWindow: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't unmaximize window. Window no longer exists`;
        }
        core_.symbols.unmaximizeWindow(winId);
      },
      isWindowMaximized: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          return false;
        }
        return core_.symbols.isWindowMaximized(winId);
      },
      setWindowFullScreen: (params) => {
        const { winId, fullScreen } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't set fullscreen. Window no longer exists`;
        }
        core_.symbols.setWindowFullScreen(winId, fullScreen);
      },
      isWindowFullScreen: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          return false;
        }
        return core_.symbols.isWindowFullScreen(winId);
      },
      setWindowAlwaysOnTop: (params) => {
        const { winId, alwaysOnTop } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't set always on top. Window no longer exists`;
        }
        core_.symbols.setWindowAlwaysOnTop(winId, alwaysOnTop);
      },
      isWindowAlwaysOnTop: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          return false;
        }
        return core_.symbols.isWindowAlwaysOnTop(winId);
      },
      setWindowVisibleOnAllWorkspaces: (params) => {
        const { winId, visibleOnAllWorkspaces } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't set visible on all workspaces. Window no longer exists`;
        }
        core_.symbols.setWindowVisibleOnAllWorkspaces(winId, visibleOnAllWorkspaces);
      },
      isWindowVisibleOnAllWorkspaces: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          return false;
        }
        return core_.symbols.isWindowVisibleOnAllWorkspaces(winId);
      },
      setWindowPosition: (params) => {
        const { winId, x, y } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't set window position. Window no longer exists`;
        }
        core_.symbols.setWindowPosition(winId, x, y);
      },
      centerWindow: (params) => {
        const { winId } = params;
        if (!getWindowPtr(winId)) {
          throw `Can't center window. Window no longer exists`;
        }
        core_.symbols.centerWindow(winId);
      },
      setWindowButtonPosition: (params) => {
        const { winId, x, y } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't set window button position. Window no longer exists`;
        }
        core_.symbols.setWindowButtonPosition(winId, x, y);
      },
      getWindowButtonPosition: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          return { x: 0, y: 0 };
        }
        const xBuf = new Float64Array(1);
        const yBuf = new Float64Array(1);
        core_.symbols.getWindowButtonPosition(winId, ptr(xBuf), ptr(yBuf));
        return { x: xBuf[0], y: yBuf[0] };
      },
      setWindowSize: (params) => {
        const { winId, width, height } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't set window size. Window no longer exists`;
        }
        core_.symbols.setWindowSize(winId, width, height);
      },
      setWindowFrame: (params) => {
        const { winId, x, y, width, height } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          throw `Can't set window frame. Window no longer exists`;
        }
        core_.symbols.setWindowFrame(winId, x, y, width, height);
      },
      getWindowFrame: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          return { x: 0, y: 0, width: 0, height: 0 };
        }
        const xBuf = new Float64Array(1);
        const yBuf = new Float64Array(1);
        const widthBuf = new Float64Array(1);
        const heightBuf = new Float64Array(1);
        core_.symbols.getWindowFrame(winId, ptr(xBuf), ptr(yBuf), ptr(widthBuf), ptr(heightBuf));
        return {
          x: xBuf[0],
          y: yBuf[0],
          width: widthBuf[0],
          height: heightBuf[0]
        };
      },
      getWindowContentOrigin: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr) {
          return { x: 0, y: 0 };
        }
        const xBuf = new Float64Array(1);
        const yBuf = new Float64Array(1);
        core_.symbols.getWindowContentOrigin(winId, ptr(xBuf), ptr(yBuf));
        return { x: xBuf[0], y: yBuf[0] };
      },
      getWindowContentSize: (params) => {
        const { winId } = params;
        const windowPtr = getWindowPtr(winId);
        if (!windowPtr)
          return { width: 0, height: 0 };
        const getContentSize = getWindowsNativeWrapperSymbols().getWindowContentSize;
        if (process.platform !== "win32" || typeof getContentSize !== "function") {
          const xBuf = new Float64Array(1);
          const yBuf = new Float64Array(1);
          const widthBuf2 = new Float64Array(1);
          const heightBuf2 = new Float64Array(1);
          core_.symbols.getWindowFrame(winId, ptr(xBuf), ptr(yBuf), ptr(widthBuf2), ptr(heightBuf2));
          return { width: widthBuf2[0], height: heightBuf2[0] };
        }
        const widthBuf = new Float64Array(1);
        const heightBuf = new Float64Array(1);
        getContentSize(windowPtr, ptr(widthBuf), ptr(heightBuf));
        return { width: widthBuf[0], height: heightBuf[0] };
      },
      createWebview: (params) => {
        const {
          windowId,
          hostWebviewId,
          renderer,
          secretKey,
          url,
          partition,
          preload,
          viewsRoot,
          allowedProtocols,
          frame: { x, y, width, height },
          autoResize,
          sandbox,
          startTransparent,
          startPassthrough,
          spellCheck
        } = params;
        ensureWebviewRuntimeConfigured();
        core_.symbols.setNextWebviewAllowedProtocols(allowedProtocols.views, allowedProtocols.appData);
        const webviewId = core_.symbols.createWebview(windowId, hostWebviewId || 0, toCString(renderer), toCString(url || ""), x, y, width, height, autoResize, toCString(partition || "persist:default"), webviewDecideNavigation, webviewEventJSCallback, eventBridgeHandler, hostBridgePostmessageHandler, internalBridgeHandler, toCString(secretKey), toCString(preload || ""), toCString(viewsRoot || ""), sandbox, startTransparent, startPassthrough, spellCheck);
        if (!webviewId) {
          throw getCoreLastError() || "Failed to create webview";
        }
        return webviewId;
      },
      getWebviewPointer: (params) => {
        return normalizeFFIPointer(core_.symbols.getWebviewPointer(params.id));
      },
      resizeWebview: (params) => {
        const { id, frame: { x, y, width, height }, masks = "[]" } = params;
        core_.symbols.resizeWebview(id, x, y, width, height, toCString(masks));
      },
      loadURLInWebView: (params) => {
        core_.symbols.loadURLInWebView(params.id, toCString(params.url));
      },
      loadHTMLInWebView: (params) => {
        core_.symbols.loadHTMLInWebView(params.id, toCString(params.html));
      },
      updatePreloadScriptToWebView: (params) => {
        core_.symbols.updatePreloadScriptToWebView(params.id, toCString(params.scriptIdentifier), toCString(params.script), params.allFrames);
      },
      webviewCanGoBack: (params) => {
        return core_.symbols.webviewCanGoBack(params.id);
      },
      webviewCanGoForward: (params) => {
        return core_.symbols.webviewCanGoForward(params.id);
      },
      webviewGoBack: (params) => {
        core_.symbols.webviewGoBack(params.id);
      },
      webviewGoForward: (params) => {
        core_.symbols.webviewGoForward(params.id);
      },
      webviewReload: (params) => {
        core_.symbols.webviewReload(params.id);
      },
      webviewRemove: (params) => {
        core_.symbols.webviewRemove(params.id);
      },
      setWebviewHTMLContent: (params) => {
        core_.symbols.setWebviewHTMLContent(params.id, toCString(params.html));
      },
      webviewSetTransparent: (params) => {
        core_.symbols.webviewSetTransparent(params.id, params.transparent);
      },
      webviewSetPassthrough: (params) => {
        core_.symbols.webviewSetPassthrough(params.id, params.passthrough);
      },
      webviewSetHidden: (params) => {
        core_.symbols.webviewSetHidden(params.id, params.hidden);
      },
      webviewSetSpellCheck: (params) => {
        return core_.symbols.webviewSetSpellCheck(params.id, params.enabled);
      },
      setWebviewNavigationRules: (params) => {
        core_.symbols.setWebviewNavigationRules(params.id, toCString(params.rulesJson));
      },
      webviewFindInPage: (params) => {
        core_.symbols.webviewFindInPage(params.id, toCString(params.searchText), params.forward, params.matchCase);
      },
      webviewStopFind: (params) => {
        core_.symbols.webviewStopFind(params.id);
      },
      createWGPUView: (params) => {
        const {
          windowId,
          frame: { x, y, width, height },
          autoResize,
          startTransparent,
          startPassthrough
        } = params;
        const viewId = core_.symbols.createWGPUView(windowId, x, y, width, height, autoResize, startTransparent, startPassthrough);
        if (!viewId) {
          throw "Failed to create WGPUView";
        }
        return viewId;
      },
      getWGPUViewPointer: (params) => {
        return normalizeFFIPointer(core_.symbols.getWGPUViewPointer(params.id));
      },
      wgpuViewSetFrame: (params) => {
        core_.symbols.setWGPUViewFrame(params.id, params.x, params.y, params.width, params.height);
      },
      resizeWGPUView: (params) => {
        const { id, frame: { x, y, width, height }, masks = "[]" } = params;
        core_.symbols.resizeWGPUView(id, x, y, width, height, toCString(masks));
      },
      wgpuViewSetTransparent: (params) => {
        core_.symbols.setWGPUViewTransparent(params.id, params.transparent);
      },
      wgpuViewSetAlphaBlending: (params) => {
        const setAlphaBlending = getDarwinNativeWrapperSymbols().wgpuViewSetAlphaBlending;
        if (typeof setAlphaBlending !== "function")
          return;
        const viewPointer = normalizeFFIPointer(core_.symbols.getWGPUViewPointer(params.id));
        if (!viewPointer)
          return;
        setAlphaBlending(viewPointer, params.enabled);
      },
      wgpuViewSetPassthrough: (params) => {
        core_.symbols.setWGPUViewPassthrough(params.id, params.passthrough);
      },
      wgpuViewSetHidden: (params) => {
        core_.symbols.setWGPUViewHidden(params.id, params.hidden);
      },
      wgpuViewRemove: (params) => {
        core_.symbols.removeWGPUView(params.id);
      },
      wgpuViewGetNativeHandle: (params) => {
        return normalizeFFIPointer(core_.symbols.getWGPUViewNativeHandle(params.id));
      },
      runWGPUViewTest: (params) => {
        core_.symbols.runWGPUViewTest(params.id);
      },
      evaluateJavascriptWithNoCompletion: (params) => {
        core_.symbols.evaluateJavaScriptWithNoCompletion(params.id, toCString(params.js));
      },
      sendHostMessageToWebviewViaTransport: (params) => {
        return core_.symbols.sendHostMessageToWebviewViaTransport(params.id, toCString(params.messageJson));
      },
      sendPreEncryptedHostMessageToWebviewViaTransport: (params) => {
        return core_.symbols.sendPreEncryptedHostMessageToWebviewViaTransport(params.id, toCString(params.encryptedPacketJson));
      },
      clearWebviewHostTransport: (params) => {
        core_.symbols.clearWebviewHostTransport(params.id);
      },
      webviewOpenDevTools: (params) => {
        core_.symbols.webviewOpenDevTools(params.id);
      },
      webviewCloseDevTools: (params) => {
        core_.symbols.webviewCloseDevTools(params.id);
      },
      webviewToggleDevTools: (params) => {
        core_.symbols.webviewToggleDevTools(params.id);
      },
      webviewSetPageZoom: (params) => {
        core_.symbols.webviewSetPageZoom(params.id, params.zoomLevel);
      },
      webviewGetPageZoom: (params) => {
        return core_.symbols.webviewGetPageZoom(params.id);
      },
      setExitOnLastWindowClosed: (params) => {
        core_.symbols.setExitOnLastWindowClosed(params.enabled);
      },
      quitGracefully: (params) => {
        core_.symbols.quitGracefully(params.code, params.timeoutMs);
      },
      createTray: (params) => {
        const { title, image, template, width, height } = params;
        const trayId = core_.symbols.createTray(toCString(title), toCString(image), template, width, height, trayItemHandler);
        if (!trayId) {
          throw "Failed to create tray";
        }
        return trayId;
      },
      showTray: (params) => {
        return core_.symbols.showTray(params.id);
      },
      hideTray: (params) => {
        core_.symbols.hideTray(params.id);
      },
      setTrayTitle: (params) => {
        const { id, title } = params;
        core_.symbols.setTrayTitle(id, toCString(title));
      },
      setTrayImage: (params) => {
        const { id, image } = params;
        core_.symbols.setTrayImage(id, toCString(image));
      },
      setTrayMenu: (params) => {
        const { id, menuConfig } = params;
        core_.symbols.setTrayMenu(id, toCString(menuConfig));
      },
      removeTray: (params) => {
        core_.symbols.removeTray(params.id);
      },
      getTrayBounds: (params) => {
        const jsonStr = core_.symbols.getTrayBounds(params.id);
        if (!jsonStr) {
          return { x: 0, y: 0, width: 0, height: 0 };
        }
        try {
          return JSON.parse(jsonStr.toString());
        } catch {
          return { x: 0, y: 0, width: 0, height: 0 };
        }
      },
      setApplicationMenu: (params) => {
        const { menuConfig } = params;
        core_.symbols.setApplicationMenu(toCString(menuConfig), applicationMenuHandler);
      },
      showContextMenu: (params) => {
        const { menuConfig } = params;
        core_.symbols.showContextMenu(toCString(menuConfig), contextMenuHandler);
      },
      moveToTrash: (params) => {
        const { path } = params;
        return core_.symbols.moveToTrash(toCString(path));
      },
      showItemInFolder: (params) => {
        const { path } = params;
        core_.symbols.showItemInFolder(toCString(path));
      },
      openExternal: (params) => {
        const { url } = params;
        return core_.symbols.openExternal(toCString(url));
      },
      openPath: (params) => {
        const { path } = params;
        return core_.symbols.openPath(toCString(path));
      },
      showNotification: (params) => {
        const { title, body = "", subtitle = "", silent = false } = params;
        core_.symbols.showNotification(toCString(title), toCString(body), toCString(subtitle), silent);
      },
      setDockIconVisible: (params) => {
        core_.symbols.setDockIconVisible(params.visible);
      },
      isDockIconVisible: () => {
        return core_.symbols.isDockIconVisible();
      },
      openFileDialog: (params) => {
        const {
          startingFolder,
          allowedFileTypes,
          canChooseFiles,
          canChooseDirectory,
          allowsMultipleSelection
        } = params;
        const payload = core_.symbols.openFileDialog(toCString(startingFolder), toCString(allowedFileTypes), canChooseFiles ? 1 : 0, canChooseDirectory ? 1 : 0, allowsMultipleSelection ? 1 : 0);
        return payload?.toString() ?? "[]";
      },
      showMessageBox: (params) => {
        const {
          type = "info",
          title = "",
          message = "",
          detail = "",
          buttons = ["OK"],
          defaultId = 0,
          cancelId = -1
        } = params;
        const buttonsStr = buttons.join(",");
        return core_.symbols.showMessageBox(toCString(type), toCString(title), toCString(message), toCString(detail), toCString(buttonsStr), defaultId, cancelId);
      },
      clipboardReadText: () => {
        const result = core_.symbols.clipboardReadText();
        if (!result)
          return null;
        return result.toString();
      },
      clipboardWriteText: (params) => {
        core_.symbols.clipboardWriteText(toCString(params.text));
      },
      clipboardReadImage: () => {
        const sizeBuffer = new BigUint64Array(1);
        const dataPtr = core_.symbols.clipboardReadImage(ptr(sizeBuffer));
        if (!dataPtr)
          return null;
        const size = Number(sizeBuffer[0]);
        if (size === 0)
          return null;
        const result = new Uint8Array(size);
        const sourceView = new Uint8Array(toArrayBuffer(dataPtr, 0, size));
        result.set(sourceView);
        return result;
      },
      clipboardWriteImage: (params) => {
        const { pngData } = params;
        core_.symbols.clipboardWriteImage(ptr(pngData), BigInt(pngData.length));
      },
      clipboardClear: () => {
        core_.symbols.clipboardClear();
      },
      clipboardAvailableFormats: () => {
        const result = core_.symbols.clipboardAvailableFormats();
        if (!result)
          return [];
        const formatsStr = result.toString();
        if (!formatsStr)
          return [];
        return formatsStr.split(",").filter((f) => f.length > 0);
      }
    },
    internal: {
      storeMenuData,
      getMenuData,
      clearMenuData,
      serializeMenuAction,
      deserializeMenuAction
    }
  };
  ffi = {
    request: createFfiRequestProxy(_ffiImpl.request),
    internal: _ffiImpl.internal
  };
  WGPUBridge = {
    available: !!native?.symbols?.wgpuInstanceCreateSurfaceMainThread,
    instanceCreateSurface: (instancePtr, descriptorPtr) => native_.symbols.wgpuInstanceCreateSurfaceMainThread(instancePtr, descriptorPtr),
    surfaceConfigure: (surfacePtr, configPtr) => native_.symbols.wgpuSurfaceConfigureMainThread(surfacePtr, configPtr),
    surfaceCapabilitiesFreeMembers: (capabilitiesPtr) => native_.symbols.wgpuSurfaceCapabilitiesFreeMembersShim(capabilitiesPtr),
    surfaceGetCurrentTexture: (surfacePtr, surfaceTexturePtr) => native_.symbols.wgpuSurfaceGetCurrentTextureMainThread(surfacePtr, surfaceTexturePtr),
    surfacePresent: (surfacePtr) => native_.symbols.wgpuSurfacePresentMainThread(surfacePtr),
    queueOnSubmittedWorkDone: (queuePtr, callbackInfoPtr) => native_.symbols.wgpuQueueOnSubmittedWorkDoneShim(queuePtr, callbackInfoPtr),
    bufferMapAsync: (bufferPtr, mode, offset, size, callbackInfoPtr) => native_.symbols.wgpuBufferMapAsyncShim(bufferPtr, mode, offset, size, callbackInfoPtr),
    instanceWaitAny: (instancePtr, futureId, timeoutNs) => native_.symbols.wgpuInstanceWaitAnyShim(instancePtr, futureId, timeoutNs),
    bufferReadSync: (instancePtr, bufferPtr, offset, size, timeoutNs, outSizePtr) => native_.symbols.wgpuBufferReadSyncShim(instancePtr, bufferPtr, offset, size, timeoutNs, outSizePtr),
    bufferReadSyncInto: (instancePtr, bufferPtr, offset, size, timeoutNs, dstPtr) => native_.symbols.wgpuBufferReadSyncIntoShim(instancePtr, bufferPtr, offset, size, timeoutNs, dstPtr),
    bufferReadbackBegin: (bufferPtr, offset, size, dstPtr) => native_.symbols.wgpuBufferReadbackBeginShim(bufferPtr, offset, size, dstPtr),
    bufferReadbackStatus: (jobPtr) => native_.symbols.wgpuBufferReadbackStatusShim(jobPtr),
    bufferReadbackFree: (jobPtr) => native_.symbols.wgpuBufferReadbackFreeShim(jobPtr),
    runTest: (viewId) => {
      const view = WGPUView.getById(viewId);
      if (!view?.ptr) {
        console.error(`wgpuRunGPUTest: WGPUView not found for id ${viewId}`);
        return;
      }
      if (!native?.symbols?.wgpuRunGPUTest) {
        console.error("wgpuRunGPUTest not available");
        return;
      }
      native_.symbols.wgpuRunGPUTest(view.ptr);
    },
    createAdapterDeviceMainThread: (instancePtr, surfacePtr, outAdapterDevicePtr) => native_.symbols.wgpuCreateAdapterDeviceMainThread(instancePtr, surfacePtr, outAdapterDevicePtr),
    createSurfaceForView: (instancePtr, viewPtr) => {
      if (!native?.symbols?.wgpuCreateSurfaceForView)
        return null;
      return native_.symbols.wgpuCreateSurfaceForView(instancePtr, viewPtr);
    },
    releaseSurfaceForView: (surfacePtr) => !!core_.symbols.wgpuReleaseSurfaceForView(surfacePtr)
  };
  process.on("uncaughtException", (err) => {
    console.error("Uncaught exception in worker:", err);
    if (native) {
      native_.symbols.stopEventLoop();
      native_.symbols.waitForShutdownComplete(5000);
      native_.symbols.forceExit(1);
    } else {
      process.exit(1);
    }
  });
  process.on("unhandledRejection", (reason, _promise) => {
    console.error("Unhandled rejection in worker:", reason);
  });
  process.on("SIGINT", () => {
    console.log("[electrobun] Received SIGINT, running quit sequence...");
    const { quit: quit2 } = (init_Utils(), __toCommonJS(exports_Utils));
    quit2();
  });
  process.on("SIGTERM", () => {
    console.log("[electrobun] Received SIGTERM, running quit sequence...");
    const { quit: quit2 } = (init_Utils(), __toCommonJS(exports_Utils));
    quit2();
  });
  windowCloseCallback = new JSCallback((id) => {
    const handler = eventEmitter_default.events.window.close;
    const event = handler({
      id
    });
    eventEmitter_default.emitEvent(event, id);
    eventEmitter_default.emitEvent(event);
  }, {
    args: ["u32"],
    returns: "void",
    threadsafe: true
  });
  windowShouldCloseCallback = new JSCallback((id) => {
    const handler = eventEmitter_default.events.window.willClose;
    const event = handler({ id });
    eventEmitter_default.emitEvent(event, id);
    eventEmitter_default.emitEvent(event);
    if (!event.responseWasSet || event.response?.allow !== false) {
      core_.symbols.closeWindow(id);
    }
  }, {
    args: ["u32"],
    returns: "void",
    threadsafe: true
  });
  windowMoveCallback = new JSCallback((id, x, y) => {
    const handler = eventEmitter_default.events.window.move;
    const event = handler({
      id,
      x,
      y
    });
    eventEmitter_default.emitEvent(event);
    eventEmitter_default.emitEvent(event, id);
  }, {
    args: ["u32", "f64", "f64"],
    returns: "void",
    threadsafe: true
  });
  windowResizeCallback = new JSCallback((id, x, y, width, height) => {
    const handler = eventEmitter_default.events.window.resize;
    const event = handler({
      id,
      x,
      y,
      width,
      height
    });
    eventEmitter_default.emitEvent(event);
    eventEmitter_default.emitEvent(event, id);
  }, {
    args: ["u32", "f64", "f64", "f64", "f64"],
    returns: "void",
    threadsafe: true
  });
  windowFocusCallback = new JSCallback((id) => {
    const handler = eventEmitter_default.events.window.focus;
    const event = handler({
      id
    });
    eventEmitter_default.emitEvent(event);
    eventEmitter_default.emitEvent(event, id);
  }, {
    args: ["u32"],
    returns: "void",
    threadsafe: true
  });
  windowBlurCallback = new JSCallback((id) => {
    const handler = eventEmitter_default.events.window.blur;
    const event = handler({
      id
    });
    eventEmitter_default.emitEvent(event);
    eventEmitter_default.emitEvent(event, id);
  }, {
    args: ["u32"],
    returns: "void",
    threadsafe: true
  });
  wgpuPointerCallback = new JSCallback((viewId, type, x, y, buttonOrDx, dy, modifiers) => {
    eventEmitter_default.emit(`wgpu-pointer-${viewId}`, {
      type,
      x,
      y,
      buttonOrDx,
      dy,
      modifiers
    });
  }, {
    args: ["u32", "u32", "f64", "f64", "f64", "f64", "u32"],
    returns: "void",
    threadsafe: true
  });
  wgpuKeyCallback = new JSCallback((viewId, keyCode, modifiers, isDown, isRepeat, charsPtr) => {
    const chars = ffiCStringToString(charsPtr);
    eventEmitter_default.emit(`wgpu-key-${viewId}`, {
      keyCode,
      modifiers,
      isDown: Boolean(isDown),
      isRepeat: Boolean(isRepeat),
      chars
    });
  }, {
    args: ["u32", "u32", "u32", "u32", "u32", FFIType.cstring],
    returns: "void",
    threadsafe: true
  });
  windowTextCallback = new JSCallback((windowId, codePoint) => {
    eventEmitter_default.emit(`window-text-${windowId}`, {
      text: String.fromCodePoint(codePoint)
    });
  }, {
    args: ["u32", "u32"],
    returns: "void",
    threadsafe: true
  });
  windowKeyCallback = new JSCallback((id, keyCode, modifiers, isDown, isRepeat) => {
    const handler = isDown ? eventEmitter_default.events.window.keyDown : eventEmitter_default.events.window.keyUp;
    const event = handler({
      id,
      keyCode,
      modifiers,
      isRepeat: !!isRepeat
    });
    eventEmitter_default.emitEvent(event);
    eventEmitter_default.emitEvent(event, id);
  }, {
    args: ["u32", "u32", "u32", "u32", "u32"],
    returns: "void",
    threadsafe: true
  });
  getMimeType = new JSCallback((filePath) => {
    const _filePath = ffiCStringToString(filePath);
    const mimeType = Bun.file(_filePath).type;
    return toCString(mimeType.split(";")[0]);
  }, {
    args: [FFIType.cstring],
    returns: FFIType.cstring
  });
  getHTMLForWebviewSync = new JSCallback((webviewId) => {
    const webview = BrowserView.ensureWrapped(webviewId);
    return toCString(webview?.html || "");
  }, {
    args: [FFIType.u32],
    returns: FFIType.cstring
  });
  if (native)
    native_.symbols.setJSUtils(getMimeType, getHTMLForWebviewSync);
  globalShortcutHandlers = new Map;
  if (native) {
    const urlOpenCallback = new JSCallback((urlPtr) => {
      const url = ffiCStringToString(urlPtr);
      const handler = eventEmitter_default.events.app.openUrl;
      const event = handler({ url });
      eventEmitter_default.emitEvent(event);
    }, { args: [FFIType.cstring], returns: "void", threadsafe: true });
    if (process.platform === "darwin") {
      native_.symbols.setURLOpenHandler(urlOpenCallback);
    }
    const appReopenCallback = new JSCallback(() => {
      if (process.platform === "darwin") {
        core_.symbols.setDockIconVisible(true);
      }
      const handler = eventEmitter_default.events.app.reopen;
      const event = handler({});
      eventEmitter_default.emitEvent(event);
    }, { args: [], returns: "void", threadsafe: true });
    if (process.platform === "darwin") {
      native_.symbols.setAppReopenHandler(appReopenCallback);
    }
    const quitRequestedCallback = new JSCallback(() => {
      const { quit: quit2 } = (init_Utils(), __toCommonJS(exports_Utils));
      quit2();
    }, { args: [], returns: "void", threadsafe: true });
    core_.symbols.setQuitRequestedHandler(quitRequestedCallback);
    const globalShortcutCallback = new JSCallback((acceleratorPtr) => {
      const accelerator = ffiCStringToString(acceleratorPtr);
      const handler = globalShortcutHandlers.get(accelerator);
      if (handler)
        handler();
    }, { args: [FFIType.cstring], returns: "void", threadsafe: true });
    native_.symbols.setGlobalShortcutCallback(globalShortcutCallback);
  }
  GlobalShortcut = {
    register: (accelerator, callback) => {
      if (!native || globalShortcutHandlers.has(accelerator))
        return false;
      const result = native_.symbols.registerGlobalShortcut(toCString(accelerator));
      if (result)
        globalShortcutHandlers.set(accelerator, callback);
      return result;
    },
    unregister: (accelerator) => {
      if (!native)
        return false;
      const result = native_.symbols.unregisterGlobalShortcut(toCString(accelerator));
      if (result)
        globalShortcutHandlers.delete(accelerator);
      return result;
    },
    unregisterAll: () => {
      if (native)
        native_.symbols.unregisterAllGlobalShortcuts();
      globalShortcutHandlers.clear();
    },
    isRegistered: (accelerator) => {
      if (!native)
        return false;
      return native_.symbols.isGlobalShortcutRegistered(toCString(accelerator));
    }
  };
  Screen = {
    getPrimaryDisplay: () => {
      const jsonStr = hasFFI ? core_.symbols.getPrimaryDisplay() : null;
      if (!jsonStr) {
        return {
          id: 0,
          bounds: { x: 0, y: 0, width: 0, height: 0 },
          workArea: { x: 0, y: 0, width: 0, height: 0 },
          scaleFactor: 1,
          isPrimary: true
        };
      }
      try {
        return JSON.parse(jsonStr.toString());
      } catch {
        return {
          id: 0,
          bounds: { x: 0, y: 0, width: 0, height: 0 },
          workArea: { x: 0, y: 0, width: 0, height: 0 },
          scaleFactor: 1,
          isPrimary: true
        };
      }
    },
    getAllDisplays: () => {
      const jsonStr = hasFFI ? core_.symbols.getAllDisplays() : null;
      if (!jsonStr) {
        return [];
      }
      try {
        return JSON.parse(jsonStr.toString());
      } catch {
        return [];
      }
    },
    getCursorScreenPoint: () => {
      const jsonStr = hasFFI ? core_.symbols.getCursorScreenPoint() : null;
      if (!jsonStr) {
        return { x: 0, y: 0 };
      }
      try {
        return JSON.parse(jsonStr.toString());
      } catch {
        return { x: 0, y: 0 };
      }
    },
    captureRegion: (rectangle) => {
      const { x, y, width, height } = rectangle;
      if (!hasFFI || !Number.isFinite(x) || !Number.isFinite(y) || !Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width <= 0 || height <= 0 || width > 4294967295 || height > 4294967295) {
        return null;
      }
      const byteLength = width * height * 4;
      if (!Number.isSafeInteger(byteLength))
        return null;
      const originX = Math.floor(x);
      const originY = Math.floor(y);
      try {
        const pixels = new Uint8Array(byteLength);
        const captured = core_.symbols.captureScreenRegion(originX, originY, width, height, ptr(pixels), BigInt(byteLength));
        return captured ? pixels : null;
      } catch {
        return null;
      }
    },
    getMouseButtons: () => {
      try {
        return hasFFI ? core_.symbols.getMouseButtons() : BigInt(0);
      } catch {
        return 0n;
      }
    }
  };
  sessionCache = new Map;
  Session = {
    fromPartition: (partition) => {
      let session = sessionCache.get(partition);
      if (!session) {
        session = new SessionInstance(partition);
        sessionCache.set(partition, session);
      }
      return session;
    },
    get defaultSession() {
      return Session.fromPartition("persist:default");
    }
  };
  webviewDecideNavigation = new JSCallback((_webviewId, _url) => {
    return true;
  }, {
    args: [FFIType.u32, FFIType.cstring],
    returns: FFIType.u32,
    threadsafe: true
  });
  webviewEventJSCallback = new JSCallback((id, _eventName, _detail) => {
    let eventName = "";
    let detail = "";
    try {
      eventName = ffiCStringToString(_eventName);
      detail = ffiCStringToString(_detail);
    } catch (err) {
      console.error("[webviewEventJSCallback] Error converting strings:", err);
      console.error("[webviewEventJSCallback] Raw values:", {
        _eventName,
        _detail
      });
      return;
    }
    webviewEventHandler(id, eventName, detail);
  }, {
    args: [FFIType.u32, FFIType.cstring, FFIType.cstring],
    returns: FFIType.void,
    threadsafe: true
  });
  hostBridgePostmessageHandler = new JSCallback((id, msg) => {
    try {
      const rawMessage = ffiCStringToString(msg).trim();
      if (!rawMessage || rawMessage[0] !== "{" && rawMessage[0] !== "[") {
        return;
      }
      const msgJson = JSON.parse(rawMessage);
      const webview = BrowserView.ensureWrapped(id);
      if (!webview) {
        return;
      }
      webview.rpcHandler?.(msgJson);
    } catch (err) {
      console.error("error sending message to host: ", err);
    }
  }, {
    args: [FFIType.u32, FFIType.cstring],
    returns: FFIType.void,
    threadsafe: true
  });
  eventBridgeHandler = new JSCallback((id, msg) => {
    try {
      if (!msg)
        return;
      const rawMessage = readOwnedRuntimeCallbackPayload(msg).trim();
      const event = parseWebviewEventBridgeMessage(id, rawMessage);
      if (event) {
        webviewEventHandler(event.id, event.eventName, event.detail);
      }
    } catch (err) {
      console.error("error in eventBridgeHandler: ", err);
    }
  }, {
    args: [FFIType.u32, FFIType.ptr],
    returns: FFIType.void,
    threadsafe: true
  });
  internalBridgeHandler = new JSCallback((id, msg) => {
    try {
      if (!msg)
        return;
      const rawMessage = readOwnedRuntimeCallbackPayload(msg);
      const event = parseWebviewEventBridgeMessage(id, rawMessage.trim());
      if (event) {
        webviewEventHandler(event.id, event.eventName, event.detail);
        return;
      }
      const jsonBatch = JSON.parse(rawMessage);
      if (!Array.isArray(jsonBatch))
        return;
      jsonBatch.forEach((msgStr) => {
        const msgJson = JSON.parse(msgStr);
        if (msgJson.type === "message") {
          const handler = internalRpcHandlers.message[msgJson.id];
          handler?.(msgJson.payload);
        } else if (msgJson.type === "request") {
          const handler = internalRpcHandlers.request[msgJson.method];
          const payload = handler?.(msgJson.params);
          const resultObj = {
            type: "response",
            id: msgJson.id,
            success: true,
            payload
          };
          core_.symbols.sendInternalMessageToWebview(msgJson.hostWebviewId, toCString(JSON.stringify(resultObj)));
        }
      });
    } catch (err) {
      console.error("error in internalBridgeHandler: ", err);
    }
  }, {
    args: [FFIType.u32, FFIType.ptr],
    returns: FFIType.void,
    threadsafe: true
  });
  trayItemHandler = new JSCallback((id, action) => {
    try {
      const actionString = ffiCStringToString(action).trim();
      const { action: actualAction, data } = deserializeMenuAction(actionString);
      const event = eventEmitter_default.events.tray.trayClicked({
        id,
        action: actualAction,
        data
      });
      eventEmitter_default.emitEvent(event, id);
      eventEmitter_default.emitEvent(event);
    } catch (err) {
      console.error("error in trayItemHandler: ", err);
    }
  }, {
    args: [FFIType.u32, FFIType.cstring],
    returns: FFIType.void,
    threadsafe: true
  });
  applicationMenuHandler = new JSCallback((id, action) => {
    const actionString = ffiCStringToString(action);
    const { action: actualAction, data } = deserializeMenuAction(actionString);
    const event = eventEmitter_default.events.app.applicationMenuClicked({
      id,
      action: actualAction,
      data
    });
    eventEmitter_default.emitEvent(event);
  }, {
    args: [FFIType.u32, FFIType.cstring],
    returns: FFIType.void,
    threadsafe: true
  });
  contextMenuHandler = new JSCallback((_id, action) => {
    const actionString = ffiCStringToString(action);
    const { action: actualAction, data } = deserializeMenuAction(actionString);
    const event = eventEmitter_default.events.app.contextMenuClicked({
      action: actualAction,
      data
    });
    eventEmitter_default.emitEvent(event);
  }, {
    args: [FFIType.u32, FFIType.cstring],
    returns: FFIType.void,
    threadsafe: true
  });
  internalRpcHandlers = {
    request: {
      webviewTagInit: (params) => {
        const {
          hostWebviewId,
          windowId,
          renderer,
          html,
          preload,
          partition,
          frame,
          navigationRules,
          sandbox,
          transparent,
          passthrough,
          spellCheck
        } = params;
        const url = !params.url && !html ? "https://electrobun.dev" : params.url;
        const webviewForTag = new BrowserView({
          url,
          html,
          preload,
          partition,
          frame,
          hostWebviewId,
          autoResize: false,
          windowId,
          renderer,
          navigationRules,
          sandbox,
          startTransparent: transparent,
          startPassthrough: passthrough,
          spellCheck
        });
        emitWebviewTagBrowserViewCreated(webviewForTag);
        return webviewForTag.id;
      },
      wgpuTagInit: (params) => {
        const {
          windowId,
          frame,
          transparent,
          passthrough
        } = params;
        const viewForTag = new WGPUView({
          windowId,
          frame,
          autoResize: false,
          startTransparent: transparent,
          startPassthrough: passthrough
        });
        return viewForTag.id;
      },
      webviewTagCanGoBack: (params) => {
        return core_.symbols.webviewCanGoBack(params.id);
      },
      webviewTagCanGoForward: (params) => {
        return core_.symbols.webviewCanGoForward(params.id);
      },
      webviewTagSetSpellCheck: (params) => {
        return core_.symbols.webviewSetSpellCheck(params.id, params.enabled);
      },
      restoreWindowFocusAfterExternalDrop: (params) => {
        if (!getWindowPtr(params.windowId))
          return false;
        core_.symbols.activateWindow(params.windowId);
        return true;
      }
    },
    message: {
      webviewTagResize: (params) => {
        const { x, y, width, height } = params.frame;
        core_.symbols.resizeWebview(params.id, x, y, width, height, toCString(params.masks ?? "[]"));
      },
      wgpuTagResize: (params) => {
        const view = WGPUView.getById(params.id);
        if (!view?.ptr) {
          console.error(`wgpuTagResize: WGPUView not found or has no ptr for id ${params.id}`);
          return;
        }
        const { x, y, width, height } = params.frame;
        view.frame = { x, y, width, height };
        native_.symbols.resizeWebview(view.ptr, x, y, width, height, toCString(params.masks ?? "[]"));
      },
      uiTagMount: (params) => {
        eventEmitter_default.emit("ui-tag-mount", {
          id: params.id,
          name: params.name
        });
      },
      webviewTagUpdateSrc: (params) => {
        const webview = BrowserView.ensureWrapped(params.id);
        if (webview) {
          webview.url = params.url;
        }
        core_.symbols.loadURLInWebView(params.id, toCString(params.url));
      },
      webviewTagUpdateHtml: (params) => {
        const webview = BrowserView.ensureWrapped(params.id);
        if (!webview) {
          console.error(`webviewTagUpdateHtml: BrowserView not found for id ${params.id}`);
          return;
        }
        webview.loadHTML(params.html);
        webview.html = params.html;
      },
      webviewTagUpdatePreload: (params) => {
        const webview = BrowserView.ensureWrapped(params.id);
        if (webview) {
          webview.preload = params.preload;
        }
        core_.symbols.updatePreloadScriptToWebView(params.id, toCString("electrobun_custom_preload_script"), toCString(params.preload), true);
      },
      webviewTagGoBack: (params) => {
        core_.symbols.webviewGoBack(params.id);
      },
      webviewTagGoForward: (params) => {
        core_.symbols.webviewGoForward(params.id);
      },
      webviewTagReload: (params) => {
        core_.symbols.webviewReload(params.id);
      },
      webviewTagRemove: (params) => {
        const webview = BrowserView.ensureWrapped(params.id);
        if (!webview) {
          console.error(`webviewTagRemove: BrowserView not found for id ${params.id}`);
          return;
        }
        webview.remove();
      },
      startWindowMove: (params) => {
        const windowPtr = getWindowPtr(params.id);
        if (!windowPtr)
          return;
        native_.symbols.startWindowMove(windowPtr);
      },
      stopWindowMove: (_params) => {
        native_.symbols.stopWindowMove();
      },
      webviewTagSetTransparent: (params) => {
        core_.symbols.webviewSetTransparent(params.id, params.transparent);
      },
      wgpuTagSetTransparent: (params) => {
        const view = WGPUView.getById(params.id);
        if (!view?.ptr) {
          console.error(`wgpuTagSetTransparent: WGPUView not found or has no ptr for id ${params.id}`);
          return;
        }
        native_.symbols.wgpuViewSetTransparent(view.ptr, params.transparent);
      },
      webviewTagSetPassthrough: (params) => {
        core_.symbols.webviewSetPassthrough(params.id, params.enablePassthrough);
      },
      wgpuTagSetPassthrough: (params) => {
        const view = WGPUView.getById(params.id);
        if (!view?.ptr) {
          console.error(`wgpuTagSetPassthrough: WGPUView not found or has no ptr for id ${params.id}`);
          return;
        }
        native_.symbols.wgpuViewSetPassthrough(view.ptr, params.passthrough);
      },
      webviewTagSetHidden: (params) => {
        core_.symbols.webviewSetHidden(params.id, params.hidden);
      },
      wgpuTagSetHidden: (params) => {
        const view = WGPUView.getById(params.id);
        if (!view?.ptr) {
          console.error(`wgpuTagSetHidden: WGPUView not found or has no ptr for id ${params.id}`);
          return;
        }
        native_.symbols.wgpuViewSetHidden(view.ptr, params.hidden);
      },
      wgpuTagRemove: (params) => {
        const view = WGPUView.getById(params.id);
        if (!view?.ptr) {
          console.error(`wgpuTagRemove: WGPUView not found or has no ptr for id ${params.id}`);
          return;
        }
        view.remove();
      },
      wgpuTagRunTest: (params) => {
        const view = WGPUView.getById(params.id);
        if (!view?.ptr) {
          console.error(`wgpuTagRunTest: WGPUView not found or has no ptr for id ${params.id}`);
          return;
        }
        if (!native?.symbols?.wgpuRunGPUTest) {
          console.error("wgpuTagRunTest: wgpuRunGPUTest not available");
          return;
        }
        native_.symbols.wgpuRunGPUTest(view.ptr);
      },
      webviewTagSetNavigationRules: (params) => {
        const rulesJson = JSON.stringify(params.rules);
        const webview = BrowserView.ensureWrapped(params.id);
        if (webview) {
          webview.navigationRules = rulesJson;
        }
        core_.symbols.setWebviewNavigationRules(params.id, toCString(rulesJson));
      },
      webviewTagFindInPage: (params) => {
        core_.symbols.webviewFindInPage(params.id, toCString(params.searchText), params.forward, params.matchCase);
      },
      webviewTagStopFind: (params) => {
        core_.symbols.webviewStopFind(params.id);
      },
      webviewTagOpenDevTools: (params) => {
        core_.symbols.webviewOpenDevTools(params.id);
      },
      webviewTagCloseDevTools: (params) => {
        core_.symbols.webviewCloseDevTools(params.id);
      },
      webviewTagToggleDevTools: (params) => {
        core_.symbols.webviewToggleDevTools(params.id);
      },
      webviewTagExecuteJavascript: (params) => {
        core_.symbols.evaluateJavaScriptWithNoCompletion(params.id, toCString(params.js));
      },
      webviewEvent: (params) => {
        console.log("-----------------+webviewEvent", params);
      }
    }
  };
});

// .hutch/devkit/api/sdks/main/index.ts
init_eventEmitter();

// .hutch/devkit/api/sdks/main/core/BrowserWindow.ts
init_native();
init_eventEmitter();
init_BrowserView();
init_BuildConfig();
init_WGPUView();
var buildConfig3 = BuildConfig.getSync();
ffi.request.setExitOnLastWindowClosed({
  enabled: buildConfig3.runtime?.exitOnLastWindowClosed ?? true
});
var defaultOptions3 = {
  title: "Electrobun",
  frame: {
    width: 800,
    height: 600
  },
  url: "https://electrobun.dev",
  html: null,
  preload: null,
  viewsRoot: null,
  allowedProtocols: { views: true, appData: false },
  renderer: buildConfig3.defaultRenderer,
  titleBarStyle: "default",
  transparent: false,
  passthrough: false,
  spellCheck: false,
  hidden: false,
  navigationRules: null,
  sandbox: false
};
var BrowserWindowMap = {};
eventEmitter_default.on("close", (event) => {
  const windowId = event.data.id;
  delete BrowserWindowMap[windowId];
  for (const view of BrowserView.getAll()) {
    if (view.windowId === windowId) {
      view.remove();
    }
  }
  const wgpuViews = WGPUView.getAll().filter((v) => v.windowId === windowId);
  for (const view of wgpuViews) {
    try {
      view.remove();
    } catch (e) {
      console.error(`Error cleaning up WGPU view ${view.id}:`, e);
    }
  }
});

class BrowserWindow {
  id = 0;
  title = "Electrobun";
  state = "creating";
  url = null;
  html = null;
  preload = null;
  viewsRoot = null;
  allowedProtocols = {
    views: true,
    appData: false
  };
  renderer = "native";
  transparent = false;
  passthrough = false;
  spellCheck = false;
  hidden = false;
  trafficLightOffset = { x: 0, y: 0 };
  navigationRules = null;
  sandbox = false;
  frame = {
    x: 0,
    y: 0,
    width: 800,
    height: 600
  };
  webviewId;
  get ptr() {
    return ffi.request.getWindowPointer({ winId: this.id });
  }
  constructor(options = defaultOptions3) {
    this.title = options.title || "New Window";
    const centered = options.frame?.x === undefined || options.frame?.y === undefined;
    this.frame = options.frame ? {
      x: options.frame.x ?? 0,
      y: options.frame.y ?? 0,
      width: options.frame.width,
      height: options.frame.height
    } : { x: 0, y: 0, width: defaultOptions3.frame.width, height: defaultOptions3.frame.height };
    this.url = options.url || null;
    this.html = options.html || null;
    this.preload = options.preload || null;
    this.viewsRoot = options.viewsRoot || null;
    this.allowedProtocols = {
      views: options.allowedProtocols?.views ?? true,
      appData: options.allowedProtocols?.appData ?? false
    };
    this.renderer = options.renderer || defaultOptions3.renderer;
    this.transparent = options.transparent ?? false;
    this.passthrough = options.passthrough ?? false;
    this.spellCheck = options.spellCheck ?? false;
    this.hidden = options.hidden ?? false;
    this.trafficLightOffset = {
      x: options.trafficLightOffset?.x ?? 0,
      y: options.trafficLightOffset?.y ?? 0
    };
    this.navigationRules = options.navigationRules || null;
    this.sandbox = options.sandbox ?? false;
    this.init(options, centered);
  }
  init({
    rpc,
    styleMask,
    titleBarStyle,
    transparent,
    hidden,
    activate
  }, centered) {
    const windowId = ffi.request.createWindow({
      title: this.title,
      url: this.url || "",
      frame: {
        width: this.frame.width,
        height: this.frame.height,
        x: this.frame.x,
        y: this.frame.y
      },
      styleMask: {
        Borderless: false,
        Titled: true,
        Closable: true,
        Miniaturizable: true,
        Resizable: true,
        UnifiedTitleAndToolbar: false,
        FullScreen: false,
        FullSizeContentView: false,
        UtilityWindow: false,
        DocModalWindow: false,
        NonactivatingPanel: false,
        HUDWindow: false,
        ...styleMask || {},
        ...titleBarStyle === "hiddenInset" ? {
          Titled: true,
          FullSizeContentView: true
        } : {},
        ...titleBarStyle === "hidden" ? {
          Titled: false,
          FullSizeContentView: true
        } : {}
      },
      titleBarStyle: titleBarStyle || "default",
      transparent: transparent ?? false,
      hidden: hidden ?? false,
      activate: activate ?? true,
      centered,
      trafficLightOffset: this.trafficLightOffset
    });
    if (!windowId) {
      throw "Failed to create window";
    }
    this.id = windowId;
    if (centered) {
      this.frame = ffi.request.getWindowFrame({ winId: this.id });
    }
    BrowserWindowMap[this.id] = this;
    const webview = new BrowserView({
      url: this.url,
      html: this.html,
      preload: this.preload,
      viewsRoot: this.viewsRoot,
      allowedProtocols: this.allowedProtocols,
      renderer: this.renderer,
      frame: {
        x: 0,
        y: 0,
        width: this.frame.width,
        height: this.frame.height
      },
      rpc,
      windowId: this.id,
      navigationRules: this.navigationRules,
      sandbox: this.sandbox,
      startPassthrough: this.passthrough,
      spellCheck: this.spellCheck
    });
    this.webviewId = webview.id;
  }
  get webview() {
    return BrowserView.getById(this.webviewId);
  }
  static getById(id) {
    return BrowserWindowMap[id];
  }
  setTitle(title) {
    this.title = title;
    return ffi.request.setTitle({ winId: this.id, title });
  }
  setSpellCheck(enabled) {
    this.spellCheck = enabled;
    return this.webview?.setSpellCheck(enabled) ?? false;
  }
  close() {
    return ffi.request.closeWindow({ winId: this.id });
  }
  requestClose() {
    return ffi.request.requestWindowClose({ winId: this.id });
  }
  activate() {
    return ffi.request.activateWindow({ winId: this.id });
  }
  focus() {
    console.log("[electrobun] BrowserWindow.focus() is deprecated. Use window.activate() instead.");
    return this.activate();
  }
  show() {
    return ffi.request.showWindow({ winId: this.id, activate: true });
  }
  showInactive() {
    return ffi.request.showWindow({ winId: this.id, activate: false });
  }
  hide() {
    return ffi.request.hideWindow({ winId: this.id });
  }
  isVisible() {
    return ffi.request.isWindowVisible({ winId: this.id });
  }
  minimize() {
    return ffi.request.minimizeWindow({ winId: this.id });
  }
  unminimize() {
    return ffi.request.restoreWindow({ winId: this.id });
  }
  isMinimized() {
    return ffi.request.isWindowMinimized({ winId: this.id });
  }
  maximize() {
    return ffi.request.maximizeWindow({ winId: this.id });
  }
  unmaximize() {
    return ffi.request.unmaximizeWindow({ winId: this.id });
  }
  isMaximized() {
    return ffi.request.isWindowMaximized({ winId: this.id });
  }
  setFullScreen(fullScreen) {
    return ffi.request.setWindowFullScreen({ winId: this.id, fullScreen });
  }
  isFullScreen() {
    return ffi.request.isWindowFullScreen({ winId: this.id });
  }
  setAlwaysOnTop(alwaysOnTop) {
    return ffi.request.setWindowAlwaysOnTop({ winId: this.id, alwaysOnTop });
  }
  isAlwaysOnTop() {
    return ffi.request.isWindowAlwaysOnTop({ winId: this.id });
  }
  setVisibleOnAllWorkspaces(visibleOnAllWorkspaces) {
    return ffi.request.setWindowVisibleOnAllWorkspaces({ winId: this.id, visibleOnAllWorkspaces });
  }
  isVisibleOnAllWorkspaces() {
    return ffi.request.isWindowVisibleOnAllWorkspaces({ winId: this.id });
  }
  setPosition(x, y) {
    this.frame.x = x;
    this.frame.y = y;
    return ffi.request.setWindowPosition({ winId: this.id, x, y });
  }
  center() {
    ffi.request.centerWindow({ winId: this.id });
    this.frame = ffi.request.getWindowFrame({ winId: this.id });
  }
  setWindowButtonPosition(x, y) {
    return ffi.request.setWindowButtonPosition({ winId: this.id, x, y });
  }
  getWindowButtonPosition() {
    return ffi.request.getWindowButtonPosition({ winId: this.id });
  }
  setSize(width, height) {
    this.frame.width = width;
    this.frame.height = height;
    return ffi.request.setWindowSize({ winId: this.id, width, height });
  }
  setFrame(x, y, width, height) {
    this.frame = { x, y, width, height };
    return ffi.request.setWindowFrame({ winId: this.id, x, y, width, height });
  }
  getFrame() {
    const frame = ffi.request.getWindowFrame({ winId: this.id });
    this.frame = frame;
    return frame;
  }
  getPosition() {
    const frame = this.getFrame();
    return { x: frame.x, y: frame.y };
  }
  getSize() {
    const frame = this.getFrame();
    return { width: frame.width, height: frame.height };
  }
  setPageZoom(zoomLevel) {
    this.webview?.setPageZoom(zoomLevel);
  }
  getPageZoom() {
    return this.webview?.getPageZoom() ?? 1;
  }
  on(name, handler) {
    const specificName = `${name}-${this.id}`;
    eventEmitter_default.on(specificName, handler);
  }
}

// .hutch/devkit/api/sdks/main/index.ts
init_BrowserView();

// .hutch/devkit/api/sdks/main/core/GpuWindow.ts
init_native();
init_eventEmitter();
init_WGPUView();
init_BuildConfig();
var defaultOptions4 = {
  title: "Electrobun",
  frame: {
    width: 800,
    height: 600
  },
  titleBarStyle: "default",
  transparent: false
};
var buildConfig4 = BuildConfig.getSync();
ffi.request.setExitOnLastWindowClosed({
  enabled: buildConfig4.runtime?.exitOnLastWindowClosed ?? true
});
var GpuWindowMap = {};
eventEmitter_default.on("close", (event) => {
  const windowId = event.data.id;
  delete GpuWindowMap[windowId];
  for (const view of WGPUView.getAll()) {
    if (view.windowId === windowId) {
      view.remove();
    }
  }
});

class GpuWindow {
  id = 0;
  title = "Electrobun";
  state = "creating";
  transparent = false;
  trafficLightOffset = { x: 0, y: 0 };
  frame = {
    x: 0,
    y: 0,
    width: 800,
    height: 600
  };
  wgpuViewId;
  get ptr() {
    return ffi.request.getWindowPointer({ winId: this.id });
  }
  constructor(options = defaultOptions4) {
    this.title = options.title || "New Window";
    const centered = options.frame?.x === undefined || options.frame?.y === undefined;
    this.frame = options.frame ? {
      x: options.frame.x ?? 0,
      y: options.frame.y ?? 0,
      width: options.frame.width,
      height: options.frame.height
    } : { x: 0, y: 0, width: defaultOptions4.frame.width, height: defaultOptions4.frame.height };
    this.transparent = options.transparent ?? false;
    this.trafficLightOffset = {
      x: options.trafficLightOffset?.x ?? 0,
      y: options.trafficLightOffset?.y ?? 0
    };
    this.init(options, centered);
  }
  init({ styleMask, titleBarStyle, transparent, activate }, centered) {
    const windowId = ffi.request.createWindow({
      title: this.title,
      url: "",
      frame: {
        width: this.frame.width,
        height: this.frame.height,
        x: this.frame.x,
        y: this.frame.y
      },
      styleMask: {
        Borderless: false,
        Titled: true,
        Closable: true,
        Miniaturizable: true,
        Resizable: true,
        UnifiedTitleAndToolbar: false,
        FullScreen: false,
        FullSizeContentView: false,
        UtilityWindow: false,
        DocModalWindow: false,
        NonactivatingPanel: false,
        HUDWindow: false,
        ...styleMask || {},
        ...titleBarStyle === "hiddenInset" ? {
          Titled: true,
          FullSizeContentView: true
        } : {},
        ...titleBarStyle === "hidden" ? {
          Titled: false,
          FullSizeContentView: true
        } : {}
      },
      titleBarStyle: titleBarStyle || "default",
      transparent: transparent ?? false,
      activate: activate ?? true,
      centered,
      trafficLightOffset: this.trafficLightOffset
    });
    if (!windowId) {
      throw "Failed to create window";
    }
    this.id = windowId;
    if (centered) {
      this.frame = ffi.request.getWindowFrame({ winId: this.id });
    }
    GpuWindowMap[this.id] = this;
    const wgpuView = new WGPUView({
      frame: {
        x: 0,
        y: 0,
        width: this.frame.width,
        height: this.frame.height
      },
      windowId: this.id,
      autoResize: true,
      startTransparent: false,
      startPassthrough: false
    });
    if (this.transparent) {
      wgpuView.setAlphaBlending(true);
    }
    this.wgpuViewId = wgpuView.id;
  }
  get wgpuView() {
    return WGPUView.getById(this.wgpuViewId);
  }
  static getById(id) {
    return GpuWindowMap[id];
  }
  setTitle(title) {
    this.title = title;
    return ffi.request.setTitle({ winId: this.id, title });
  }
  close() {
    return ffi.request.closeWindow({ winId: this.id });
  }
  requestClose() {
    return ffi.request.requestWindowClose({ winId: this.id });
  }
  activate() {
    return ffi.request.activateWindow({ winId: this.id });
  }
  focus() {
    console.log("[electrobun] GpuWindow.focus() is deprecated. Use window.activate() instead.");
    return this.activate();
  }
  visible = true;
  show() {
    this.visible = true;
    return ffi.request.showWindow({ winId: this.id, activate: true });
  }
  showInactive() {
    this.visible = true;
    return ffi.request.showWindow({ winId: this.id, activate: false });
  }
  hide() {
    this.visible = false;
    return ffi.request.hideWindow({ winId: this.id });
  }
  isVisible() {
    return this.visible;
  }
  minimize() {
    return ffi.request.minimizeWindow({ winId: this.id });
  }
  unminimize() {
    return ffi.request.restoreWindow({ winId: this.id });
  }
  isMinimized() {
    return ffi.request.isWindowMinimized({ winId: this.id });
  }
  maximize() {
    return ffi.request.maximizeWindow({ winId: this.id });
  }
  unmaximize() {
    return ffi.request.unmaximizeWindow({ winId: this.id });
  }
  isMaximized() {
    return ffi.request.isWindowMaximized({ winId: this.id });
  }
  setFullScreen(fullScreen) {
    return ffi.request.setWindowFullScreen({ winId: this.id, fullScreen });
  }
  isFullScreen() {
    return ffi.request.isWindowFullScreen({ winId: this.id });
  }
  setAlwaysOnTop(alwaysOnTop) {
    return ffi.request.setWindowAlwaysOnTop({ winId: this.id, alwaysOnTop });
  }
  isAlwaysOnTop() {
    return ffi.request.isWindowAlwaysOnTop({ winId: this.id });
  }
  setPosition(x, y) {
    this.frame.x = x;
    this.frame.y = y;
    return ffi.request.setWindowPosition({ winId: this.id, x, y });
  }
  setWindowButtonPosition(x, y) {
    return ffi.request.setWindowButtonPosition({ winId: this.id, x, y });
  }
  center() {
    ffi.request.centerWindow({ winId: this.id });
    this.frame = ffi.request.getWindowFrame({ winId: this.id });
  }
  getWindowButtonPosition() {
    return ffi.request.getWindowButtonPosition({ winId: this.id });
  }
  setSize(width, height) {
    this.frame.width = width;
    this.frame.height = height;
    return ffi.request.setWindowSize({ winId: this.id, width, height });
  }
  setFrame(x, y, width, height) {
    this.frame = { x, y, width, height };
    return ffi.request.setWindowFrame({ winId: this.id, x, y, width, height });
  }
  getFrame() {
    const frame = ffi.request.getWindowFrame({ winId: this.id });
    this.frame = frame;
    return frame;
  }
  getPosition() {
    const frame = this.getFrame();
    return { x: frame.x, y: frame.y };
  }
  getSize() {
    const frame = this.getFrame();
    return { width: frame.width, height: frame.height };
  }
  on(name, handler) {
    const specificName = `${name}-${this.id}`;
    eventEmitter_default.on(specificName, handler);
    return () => this.off(name, handler);
  }
  off(name, handler) {
    const specificName = `${name}-${this.id}`;
    eventEmitter_default.off(specificName, handler);
  }
}

// .hutch/devkit/api/sdks/main/index.ts
init_WGPUView();

// .hutch/devkit/api/sdks/main/core/Tray.ts
init_native();
init_eventEmitter();

// .hutch/devkit/api/sdks/main/core/Paths.ts
var exports_Paths = {};
__export(exports_Paths, {
  VIEWS_FOLDER: () => VIEWS_FOLDER,
  RESOURCES_FOLDER: () => RESOURCES_FOLDER
});
import { resolve as resolve2 } from "path";
var RESOURCES_FOLDER = resolve2("../Resources/");
var VIEWS_FOLDER = resolve2(RESOURCES_FOLDER, "app/views");

// .hutch/devkit/api/sdks/main/core/Tray.ts
import { join as join3 } from "path";
var TrayMap = {};

class Tray {
  id = 0;
  visible = false;
  title = "";
  image = "";
  template = true;
  width = 16;
  height = 16;
  menu = null;
  constructor({
    title = "",
    image = "",
    template = true,
    width = 16,
    height = 16
  } = {}) {
    this.title = title;
    this.image = image;
    this.template = template;
    this.width = width;
    this.height = height;
    if (this.createNativeTray()) {
      TrayMap[this.id] = this;
    }
  }
  createNativeTray() {
    try {
      const trayId = ffi.request.createTray({
        title: this.title,
        image: this.resolveImagePath(this.image),
        template: this.template,
        width: this.width,
        height: this.height
      });
      if (!trayId) {
        throw new Error("Tray creation returned an invalid id");
      }
      this.id = trayId;
      this.visible = true;
      return true;
    } catch (error) {
      console.warn("Tray creation failed:", error);
      console.warn("System tray functionality may not be available on this platform");
      this.visible = false;
      return false;
    }
  }
  resolveImagePath(imgPath) {
    if (imgPath.startsWith("views://")) {
      return join3(VIEWS_FOLDER, imgPath.replace("views://", ""));
    } else {
      return imgPath;
    }
  }
  setTitle(title) {
    this.title = title;
    if (!this.id)
      return;
    ffi.request.setTrayTitle({ id: this.id, title });
  }
  setImage(imgPath) {
    this.image = imgPath;
    if (!this.id)
      return;
    ffi.request.setTrayImage({
      id: this.id,
      image: this.resolveImagePath(imgPath)
    });
  }
  setMenu(menu) {
    this.menu = menu;
    if (!this.id)
      return;
    const menuWithDefaults = menuConfigWithDefaults(menu);
    ffi.request.setTrayMenu({
      id: this.id,
      menuConfig: JSON.stringify(menuWithDefaults)
    });
  }
  on(name, handler) {
    const specificName = `${name}-${this.id}`;
    eventEmitter_default.on(specificName, handler);
  }
  setVisible(visible) {
    if (visible === this.visible) {
      return;
    }
    if (!visible) {
      if (this.id)
        ffi.request.hideTray({ id: this.id });
      this.visible = false;
      return;
    }
    if (!this.id) {
      if (this.createNativeTray()) {
        TrayMap[this.id] = this;
      }
      return;
    }
    this.visible = ffi.request.showTray({ id: this.id });
  }
  getBounds() {
    return ffi.request.getTrayBounds({ id: this.id });
  }
  remove() {
    console.log("Tray.remove() called for id:", this.id);
    const trayId = this.id;
    if (trayId) {
      ffi.request.removeTray({ id: trayId });
    }
    this.visible = false;
    delete TrayMap[trayId];
    this.id = 0;
    console.log("Tray removed from TrayMap");
  }
  static getById(id) {
    return TrayMap[id];
  }
  static getAll() {
    return Object.values(TrayMap);
  }
  static removeById(id) {
    const tray = TrayMap[id];
    if (tray) {
      tray.remove();
    }
  }
}
var menuConfigWithDefaults = (menu) => {
  return menu.map((item) => {
    if (item.type === "divider" || item.type === "separator") {
      return { type: "divider" };
    } else {
      const menuItem = item;
      const actionWithDataId = ffi.internal.serializeMenuAction(menuItem.action || "", menuItem.data);
      return {
        label: menuItem.label || "",
        type: menuItem.type || "normal",
        action: actionWithDataId,
        enabled: menuItem.enabled === false ? false : true,
        checked: Boolean(menuItem.checked),
        hidden: Boolean(menuItem.hidden),
        tooltip: menuItem.tooltip || undefined,
        ...menuItem.submenu ? { submenu: menuConfigWithDefaults(menuItem.submenu) } : {}
      };
    }
  });
};

// .hutch/devkit/api/sdks/main/core/ApplicationMenu.ts
init_native();
init_eventEmitter();
var exports_ApplicationMenu = {};
__export(exports_ApplicationMenu, {
  setApplicationMenu: () => setApplicationMenu,
  on: () => on
});

// .hutch/devkit/api/sdks/main/core/menuRoles.ts
var roleLabelMap = {
  about: "About",
  quit: "Quit",
  hide: "Hide",
  hideOthers: "Hide Others",
  showAll: "Show All",
  minimize: "Minimize",
  zoom: "Zoom",
  close: "Close",
  bringAllToFront: "Bring All To Front",
  cycleThroughWindows: "Cycle Through Windows",
  enterFullScreen: "Enter Full Screen",
  exitFullScreen: "Exit Full Screen",
  toggleFullScreen: "Toggle Full Screen",
  undo: "Undo",
  redo: "Redo",
  cut: "Cut",
  copy: "Copy",
  paste: "Paste",
  pasteAndMatchStyle: "Paste and Match Style",
  delete: "Delete",
  selectAll: "Select All",
  startSpeaking: "Start Speaking",
  stopSpeaking: "Stop Speaking",
  showHelp: "Show Help",
  moveForward: "Move Forward",
  moveBackward: "Move Backward",
  moveLeft: "Move Left",
  moveRight: "Move Right",
  moveUp: "Move Up",
  moveDown: "Move Down",
  moveWordForward: "Move Word Forward",
  moveWordBackward: "Move Word Backward",
  moveWordLeft: "Move Word Left",
  moveWordRight: "Move Word Right",
  moveToBeginningOfLine: "Move to Beginning of Line",
  moveToEndOfLine: "Move to End of Line",
  moveToLeftEndOfLine: "Move to Left End of Line",
  moveToRightEndOfLine: "Move to Right End of Line",
  moveToBeginningOfParagraph: "Move to Beginning of Paragraph",
  moveToEndOfParagraph: "Move to End of Paragraph",
  moveParagraphForward: "Move Paragraph Forward",
  moveParagraphBackward: "Move Paragraph Backward",
  moveToBeginningOfDocument: "Move to Beginning of Document",
  moveToEndOfDocument: "Move to End of Document",
  moveForwardAndModifySelection: "Move Forward and Modify Selection",
  moveBackwardAndModifySelection: "Move Backward and Modify Selection",
  moveLeftAndModifySelection: "Move Left and Modify Selection",
  moveRightAndModifySelection: "Move Right and Modify Selection",
  moveUpAndModifySelection: "Move Up and Modify Selection",
  moveDownAndModifySelection: "Move Down and Modify Selection",
  moveWordForwardAndModifySelection: "Move Word Forward and Modify Selection",
  moveWordBackwardAndModifySelection: "Move Word Backward and Modify Selection",
  moveWordLeftAndModifySelection: "Move Word Left and Modify Selection",
  moveWordRightAndModifySelection: "Move Word Right and Modify Selection",
  moveToBeginningOfLineAndModifySelection: "Move to Beginning of Line and Modify Selection",
  moveToEndOfLineAndModifySelection: "Move to End of Line and Modify Selection",
  moveToLeftEndOfLineAndModifySelection: "Move to Left End of Line and Modify Selection",
  moveToRightEndOfLineAndModifySelection: "Move to Right End of Line and Modify Selection",
  moveToBeginningOfParagraphAndModifySelection: "Move to Beginning of Paragraph and Modify Selection",
  moveToEndOfParagraphAndModifySelection: "Move to End of Paragraph and Modify Selection",
  moveParagraphForwardAndModifySelection: "Move Paragraph Forward and Modify Selection",
  moveParagraphBackwardAndModifySelection: "Move Paragraph Backward and Modify Selection",
  moveToBeginningOfDocumentAndModifySelection: "Move to Beginning of Document and Modify Selection",
  moveToEndOfDocumentAndModifySelection: "Move to End of Document and Modify Selection",
  pageUp: "Page Up",
  pageDown: "Page Down",
  pageUpAndModifySelection: "Page Up and Modify Selection",
  pageDownAndModifySelection: "Page Down and Modify Selection",
  scrollLineUp: "Scroll Line Up",
  scrollLineDown: "Scroll Line Down",
  scrollPageUp: "Scroll Page Up",
  scrollPageDown: "Scroll Page Down",
  scrollToBeginningOfDocument: "Scroll to Beginning of Document",
  scrollToEndOfDocument: "Scroll to End of Document",
  centerSelectionInVisibleArea: "Center Selection in Visible Area",
  deleteBackward: "Delete Backward",
  deleteForward: "Delete Forward",
  deleteBackwardByDecomposingPreviousCharacter: "Delete Backward by Decomposing Previous Character",
  deleteWordBackward: "Delete Word Backward",
  deleteWordForward: "Delete Word Forward",
  deleteToBeginningOfLine: "Delete to Beginning of Line",
  deleteToEndOfLine: "Delete to End of Line",
  deleteToBeginningOfParagraph: "Delete to Beginning of Paragraph",
  deleteToEndOfParagraph: "Delete to End of Paragraph",
  selectWord: "Select Word",
  selectLine: "Select Line",
  selectParagraph: "Select Paragraph",
  selectToMark: "Select to Mark",
  setMark: "Set Mark",
  swapWithMark: "Swap with Mark",
  deleteToMark: "Delete to Mark",
  capitalizeWord: "Capitalize Word",
  uppercaseWord: "Uppercase Word",
  lowercaseWord: "Lowercase Word",
  transpose: "Transpose",
  transposeWords: "Transpose Words",
  insertNewline: "Insert Newline",
  insertLineBreak: "Insert Line Break",
  insertParagraphSeparator: "Insert Paragraph Separator",
  insertTab: "Insert Tab",
  insertBacktab: "Insert Backtab",
  insertTabIgnoringFieldEditor: "Insert Tab Ignoring Field Editor",
  insertNewlineIgnoringFieldEditor: "Insert Newline Ignoring Field Editor",
  yank: "Yank",
  yankAndSelect: "Yank and Select",
  complete: "Complete",
  cancelOperation: "Cancel Operation",
  indent: "Indent"
};

// .hutch/devkit/api/sdks/main/core/ApplicationMenu.ts
var setApplicationMenu = (menu) => {
  const menuWithDefaults = menuConfigWithDefaults2(menu);
  ffi.request.setApplicationMenu({
    menuConfig: JSON.stringify(menuWithDefaults)
  });
};
var on = (name, handler) => {
  const specificName = `${name}`;
  eventEmitter_default.on(specificName, handler);
};
var menuConfigWithDefaults2 = (menu) => {
  return menu.map((item) => {
    if (item.type === "divider" || item.type === "separator") {
      return { type: "divider" };
    } else {
      const menuItem = item;
      const actionWithDataId = ffi.internal.serializeMenuAction(menuItem.action || "", menuItem.data);
      return {
        label: menuItem.label || roleLabelMap[menuItem.role] || "",
        type: menuItem.type || "normal",
        ...menuItem.role ? { role: menuItem.role } : { action: actionWithDataId },
        enabled: menuItem.enabled === false ? false : true,
        checked: Boolean(menuItem.checked),
        hidden: Boolean(menuItem.hidden),
        tooltip: menuItem.tooltip || undefined,
        accelerator: menuItem.accelerator || undefined,
        ...menuItem.submenu ? { submenu: menuConfigWithDefaults2(menuItem.submenu) } : {}
      };
    }
  });
};

// .hutch/devkit/api/sdks/main/core/ContextMenu.ts
init_native();
init_eventEmitter();
var exports_ContextMenu = {};
__export(exports_ContextMenu, {
  showContextMenu: () => showContextMenu,
  on: () => on2
});
var showContextMenu = (menu) => {
  const menuWithDefaults = menuConfigWithDefaults3(menu);
  ffi.request.showContextMenu({
    menuConfig: JSON.stringify(menuWithDefaults)
  });
};
var on2 = (name, handler) => {
  const specificName = `${name}`;
  eventEmitter_default.on(specificName, handler);
};
var menuConfigWithDefaults3 = (menu) => {
  return menu.map((item) => {
    if (item.type === "divider" || item.type === "separator") {
      return { type: "divider" };
    } else {
      const menuItem = item;
      const actionWithDataId = ffi.internal.serializeMenuAction(menuItem.action || "", menuItem.data);
      return {
        label: menuItem.label || roleLabelMap[menuItem.role] || "",
        type: menuItem.type || "normal",
        ...menuItem.role ? { role: menuItem.role } : { action: actionWithDataId },
        enabled: menuItem.enabled === false ? false : true,
        checked: Boolean(menuItem.checked),
        hidden: Boolean(menuItem.hidden),
        tooltip: menuItem.tooltip || undefined,
        ...menuItem.accelerator ? { accelerator: menuItem.accelerator } : {},
        ...menuItem.submenu ? { submenu: menuConfigWithDefaults3(menuItem.submenu) } : {}
      };
    }
  });
};

// .hutch/devkit/api/sdks/main/core/Updater.ts
init_platform();
init_Utils();
import { execFileSync } from "child_process";
import { randomBytes as randomBytes3 } from "crypto";
import {
  chmodSync,
  closeSync as closeSync2,
  constants as fsConstants,
  read,
  fchmodSync,
  fstatSync,
  fsyncSync,
  lstatSync as lstatSync2,
  mkdirSync,
  openSync,
  opendirSync,
  readSync,
  readFileSync as readFileSync3,
  realpathSync,
  renameSync,
  rmSync,
  writeSync
} from "fs";
import { homedir as homedir2, tmpdir as tmpdir2 } from "os";
import {
  dirname as dirname2,
  isAbsolute as isAbsolute2,
  join as join4,
  posix as posix2,
  relative,
  resolve as resolve3,
  sep,
  win32 as win323
} from "path";

// .hutch/devkit/api/sdks/main/core/WindowsUpdateTask.ts
import { Buffer as Buffer2 } from "buffer";
import { win32 as win322 } from "path";
var TRANSACTION_ID_PATTERN = /^[a-f0-9]{32}$/;
var UPDATE_TASK_NAME_PATTERN = /^ApplicationUpdate_[a-f0-9]{24}$/;
function createWindowsUpdateTaskName(transactionId) {
  if (!TRANSACTION_ID_PATTERN.test(transactionId)) {
    throw new Error("Invalid update transaction ID");
  }
  return `ApplicationUpdate_${transactionId.slice(0, 24)}`;
}
function requireSafeAbsolutePath(path, description) {
  const root = win322.parse(path).root;
  const isFullyQualified = root !== "\\" && root !== "/";
  if (!win322.isAbsolute(path) || !isFullyQualified || /["\r\n]/.test(path)) {
    throw new Error(`Invalid Windows update ${description} path`);
  }
}
function createWindowsUpdateTaskPlan(taskName, helperPath, planPath) {
  if (!UPDATE_TASK_NAME_PATTERN.test(taskName)) {
    throw new Error(`Invalid application update task name: ${taskName}`);
  }
  requireSafeAbsolutePath(helperPath, "helper");
  requireSafeAbsolutePath(planPath, "plan");
  const literal = (value) => `'${value.replaceAll("'", "''")}'`;
  const taskArguments = `--apply-update "${planPath}" --quiet`;
  const createScript = [
    "$ErrorActionPreference = 'Stop'",
    `$action = New-ScheduledTaskAction -Execute ${literal(helperPath)} -Argument ${literal(taskArguments)}`,
    "$principal = New-ScheduledTaskPrincipal -UserId ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited",
    `Register-ScheduledTask -TaskName '${taskName}' -Action $action -Principal $principal -Force | Out-Null`
  ].join("; ");
  const settingsScript = [
    "$ErrorActionPreference = 'Stop'",
    "$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries",
    `Set-ScheduledTask -TaskName '${taskName}' -Settings $settings | Out-Null`
  ].join("; ");
  return {
    create: {
      executable: "powershell.exe",
      args: ["-NoProfile", "-NonInteractive", "-EncodedCommand", Buffer2.from(createScript, "utf16le").toString("base64")]
    },
    configure: {
      executable: "powershell.exe",
      args: ["-NoProfile", "-NonInteractive", "-Command", settingsScript]
    },
    run: {
      executable: "schtasks.exe",
      args: ["/run", "/tn", taskName]
    },
    deleteTask: {
      executable: "schtasks.exe",
      args: ["/delete", "/tn", taskName, "/f"]
    }
  };
}
function executeWindowsUpdateTaskPlan(plan, execute) {
  let created = false;
  try {
    execute(plan.create);
    created = true;
    execute(plan.configure);
    execute(plan.run);
  } catch (error) {
    if (created) {
      try {
        execute(plan.deleteTask);
      } catch (cleanupError) {
        throw new AggregateError([error, cleanupError], "Failed to start Windows update task and clean it up");
      }
    }
    throw error;
  }
}

// .hutch/devkit/api/sdks/main/core/Updater.ts
var MAX_UPDATE_DOCUMENT_BYTES = 1024 * 1024;
var SAFE_HASH_PATTERN = /^[a-z0-9]{1,13}$/;
var TRANSACTION_ID_PATTERN2 = /^[a-f0-9]{32}$/;
var MAX_TAR_METADATA_BYTES = 1024 * 1024;
var MAX_TAR_EXTENSION_BYTES = 64 * 1024;
var PREPARED_UPDATE_FILE = ".electrobun-prepared-update.json";
var OBSERVED_UPDATE_RESULT_FILE = ".electrobun-observed-update-result.json";
var UPDATE_RESULT_FILE_PATTERN = /^\.electrobun-update-([a-f0-9]{32})\.result\.json$/;
var UPDATE_RESULT_PHASES = new Set([
  "validating",
  "waiting_for_parent",
  "extracting",
  "validating_payload",
  "swapping",
  "integrating",
  "launching",
  "complete"
]);
var UPDATE_RESULT_FIELDS = [
  "channel",
  "hash",
  "identifier",
  "message",
  "phase",
  "schema_version",
  "success",
  "transaction_id",
  "version"
];
var MAX_UPDATE_RESULT_BYTES = 64 * 1024;
var MAX_UPDATE_RESULT_DIRECTORY_ENTRIES = 1024;
var MAX_UPDATE_RESULT_FILES = 64;
var UPDATE_RESULT_POLL_ATTEMPTS = 40;
var UPDATE_RESULT_POLL_INTERVAL_MS = 50;
var DOWNLOAD_PROGRESS_MIN_BYTES = 256 * 1024;
var statusHistory = [];
var onStatusChangeCallback = null;
var localInfo;
var updateInfo = {
  version: "",
  hash: "",
  updateAvailable: false,
  updateReady: false,
  error: ""
};
var checkedManifest;
var checkInFlight;
var downloadInFlight;
var applyInFlight;
var nativeResultReconciliation;
var nativeResultReconciliationScheduled = false;
var reconciledNativeResultPath;
function emitStatus(status, message, details) {
  const entry = {
    status,
    message,
    timestamp: Date.now(),
    details
  };
  statusHistory.push(entry);
  onStatusChangeCallback?.(entry);
}
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function requireString(record, key) {
  const value = record[key];
  if (typeof value !== "string") {
    throw new Error(`Invalid update manifest: ${key} must be a string`);
  }
  return value;
}
function isSafeVersion(value) {
  return value.length > 0 && value.length <= 256 && !/[\u0000-\u001f\u007f]/.test(value);
}
function isSafeIdentityComponent(value, platform2) {
  if (value.length === 0 || value.length > 256 || value === "." || value === "..") {
    return false;
  }
  if (platform2 === "win") {
    return !/[\u0000-\u001f"%*/:<>?\\|]/.test(value) && !/[ .]$/.test(value);
  }
  return platform2 === "macos" ? !/[\u0000-\u001f\u007f/\\]/.test(value) : !/[\u0000-\u001f\u007f/]/.test(value);
}
function isSafeArtifactFileName(value) {
  return value.length > ".tar.zst".length && value.length <= 1024 && value.endsWith(".tar.zst") && !/[\u0000-\u001f\u007f/\\:]/.test(value);
}
function validateUpdateManifest(document, expected) {
  if (!isRecord(document) || document["schemaVersion"] !== 1) {
    throw new Error("Invalid update manifest: unsupported schemaVersion");
  }
  const identifier = requireString(document, "identifier");
  const channel = requireString(document, "channel");
  const version = requireString(document, "version");
  const hash = requireString(document, "hash");
  const platform2 = requireString(document, "platform");
  const arch2 = requireString(document, "arch");
  if (!isBuildEnvironment(channel) || !isBuildEnvironment(expected.channel) || identifier !== expected.identifier || channel !== expected.channel || platform2 !== expected.platform || arch2 !== expected.arch) {
    throw new Error("Invalid update manifest: release identity does not match this app");
  }
  if (!isSafeIdentityComponent(identifier, expected.platform) || !isSafeIdentityComponent(channel, expected.platform) || !isSafeVersion(version) || !SAFE_HASH_PATTERN.test(hash)) {
    throw new Error("Invalid update manifest: unsafe release metadata");
  }
  const artifactValue = document["artifact"];
  if (!isRecord(artifactValue)) {
    throw new Error("Invalid update manifest: artifact is required");
  }
  const file = requireString(artifactValue, "file");
  const requiredPrefix = `${getPlatformPrefix(channel, expected.platform, expected.arch)}-`;
  if (!isSafeArtifactFileName(file) || !file.startsWith(requiredPrefix)) {
    throw new Error("Invalid update manifest: unsafe artifact filename");
  }
  const artifact = { file };
  const tarSha256 = artifactValue["tarSha256"];
  const tarSize = artifactValue["tarSize"];
  if (tarSha256 !== undefined || tarSize !== undefined) {
    if (typeof tarSha256 !== "string" || !/^[a-f0-9]{64}$/.test(tarSha256) || typeof tarSize !== "number" || !Number.isSafeInteger(tarSize) || tarSize <= 0) {
      throw new Error("Invalid update manifest: invalid tar integrity metadata");
    }
    artifact.tarSha256 = tarSha256;
    artifact.tarSize = tarSize;
  }
  return {
    schemaVersion: 1,
    identifier,
    channel,
    version,
    hash,
    platform: platform2,
    arch: arch2,
    artifact
  };
}
function getAppDataDir2() {
  switch (OS) {
    case "macos":
      return join4(homedir2(), "Library", "Application Support");
    case "win":
      return process.env["LOCALAPPDATA"] || join4(homedir2(), "AppData", "Local");
    case "linux": {
      const configured = process.env["XDG_DATA_HOME"];
      if (configured && isAbsolute2(configured)) {
        const normalized = resolve3(configured);
        if (normalized !== "/")
          return normalized;
      }
      return join4(homedir2(), ".local", "share");
    }
  }
}
function hasRegularFile(path) {
  const stat = lstatSync2(path, { throwIfNoEntry: false });
  return Boolean(stat?.isFile() && !stat.isSymbolicLink());
}
function resolveInstalledChannelRoot(info, executablePath = process.execPath, appDataRoot = getAppDataDir2()) {
  return resolveInstalledChannelRootForPlatform(info, OS, executablePath, appDataRoot);
}
function resolveInstalledChannelRootForPlatform(info, platform2, executablePath, appDataRoot, regularFileProbe = hasRegularFile) {
  if (!isSafeIdentityComponent(info.identifier, platform2) || !isSafeIdentityComponent(info.channel, platform2) || !isBuildEnvironment(info.channel)) {
    throw new Error("The installed update identity is unsafe");
  }
  const pathApi = platform2 === "win" ? win323 : posix2;
  const identifierRoot = pathApi.resolve(pathApi.join(appDataRoot, info.identifier));
  if (platform2 !== "macos") {
    const derivedRoot = pathApi.resolve(pathApi.dirname(executablePath), "..", "..");
    const derivedParent = pathApi.resolve(pathApi.dirname(derivedRoot));
    const normalizedParent = platform2 === "win" ? derivedParent.toLowerCase() : derivedParent;
    const normalizedIdentifierRoot = platform2 === "win" ? identifierRoot.toLowerCase() : identifierRoot;
    if (normalizedParent !== normalizedIdentifierRoot) {
      if (info.channel === "dev") {
        return pathApi.resolve(pathApi.join(identifierRoot, info.channel));
      }
      throw new Error("The running application is outside its managed update directory");
    }
    return derivedRoot;
  }
  const modernRoot = pathApi.resolve(pathApi.join(identifierRoot, info.channel));
  const candidates = [modernRoot];
  if (isSafeIdentityComponent(info.name, "macos")) {
    candidates.push(pathApi.resolve(pathApi.join(identifierRoot, info.name)));
  }
  if (info.displayName && isSafeIdentityComponent(info.displayName, "macos")) {
    const legacyDisplayRootName = info.channel === "stable" ? info.displayName : `${info.displayName}-${info.channel}`;
    if (isSafeIdentityComponent(legacyDisplayRootName, "macos")) {
      candidates.push(pathApi.resolve(pathApi.join(identifierRoot, legacyDisplayRootName)));
    }
  }
  const distinctCandidates = [...new Set(candidates)];
  const currentArchiveRoot = distinctCandidates.find((candidate) => regularFileProbe(pathApi.join(candidate, "self-extraction", `${info.hash}.recipe.json`)) || regularFileProbe(pathApi.join(candidate, "self-extraction", `${info.hash}.tar`)));
  if (currentArchiveRoot)
    return currentArchiveRoot;
  const manifestRoot = distinctCandidates.find((candidate) => regularFileProbe(pathApi.join(candidate, ".electrobun-uninstall.json")));
  if (manifestRoot)
    return manifestRoot;
  return modernRoot;
}
function appDataFolderFor(info) {
  return resolveInstalledChannelRoot(info);
}
function extractionFolderFor(channelRoot) {
  return join4(channelRoot, "self-extraction");
}
function preparedUpdatePathFor(channelRoot) {
  return join4(extractionFolderFor(channelRoot), PREPARED_UPDATE_FILE);
}
function writeAll(fileDescriptor, bytes) {
  let offset = 0;
  while (offset < bytes.byteLength) {
    const written = writeSync(fileDescriptor, bytes, offset, bytes.byteLength - offset);
    if (written <= 0)
      throw new Error("Failed to write update file");
    offset += written;
  }
}
function publishFileReplacingRegular(sourcePath, destinationPath) {
  const previousPath = `${destinationPath}.previous`;
  const destination = lstatSync2(destinationPath, { throwIfNoEntry: false });
  const previous = lstatSync2(previousPath, { throwIfNoEntry: false });
  if (destination && (!destination.isFile() || destination.isSymbolicLink()) || previous && (!previous.isFile() || previous.isSymbolicLink())) {
    throw new Error(`Refusing to replace unsafe update state: ${destinationPath}`);
  }
  if (!destination && previous)
    renameSync(previousPath, destinationPath);
  else if (destination && previous)
    rmSync(previousPath, { force: true });
  const current = lstatSync2(destinationPath, { throwIfNoEntry: false });
  if (current)
    renameSync(destinationPath, previousPath);
  try {
    renameSync(sourcePath, destinationPath);
  } catch (error) {
    if (current)
      renameSync(previousPath, destinationPath);
    throw error;
  }
  if (current) {
    try {
      rmSync(previousPath, { force: true });
    } catch {}
  }
}
function atomicWriteFile(path, contents) {
  const partialPath = `${path}.${randomBytes3(8).toString("hex")}.partial`;
  let fileDescriptor;
  try {
    fileDescriptor = openSync(partialPath, "wx+", 384);
    writeAll(fileDescriptor, contents);
    fsyncSync(fileDescriptor);
    closeSync2(fileDescriptor);
    fileDescriptor = undefined;
    publishFileReplacingRegular(partialPath, path);
  } finally {
    if (fileDescriptor !== undefined) {
      try {
        closeSync2(fileDescriptor);
      } catch {}
    }
    rmSync(partialPath, { force: true });
  }
}
function atomicWriteJson(path, value) {
  atomicWriteFile(path, new TextEncoder().encode(`${JSON.stringify(value)}
`));
}
function requireRegularFile(path, description) {
  const stat = lstatSync2(path, { throwIfNoEntry: false });
  if (!stat?.isFile() || stat.isSymbolicLink()) {
    throw new Error(`${description} is missing or is not a regular file: ${path}`);
  }
}
function installedAppBundlePath(channelRoot) {
  return OS === "macos" ? resolve3(dirname2(process.execPath), "..", "..") : join4(channelRoot, "app");
}
function validatePreparedUpdate(document, info, channelRoot, appBundlePath = installedAppBundlePath(channelRoot)) {
  if (!isRecord(document) || document["schema_version"] !== 1 && document["schema_version"] !== 2) {
    throw new Error("Invalid prepared update record");
  }
  const identifier = requireString(document, "identifier");
  const channel = requireString(document, "channel");
  const version = requireString(document, "version");
  const hash = requireString(document, "hash");
  const platform2 = requireString(document, "platform");
  const arch2 = requireString(document, "arch");
  const artifactFile = requireString(document, "artifact_file");
  if (identifier !== info.identifier || channel !== info.channel || !isBuildEnvironment(channel) || platform2 !== OS || arch2 !== ARCH || !isSafeVersion(version) || !SAFE_HASH_PATTERN.test(hash) || !isSafeArtifactFileName(artifactFile)) {
    throw new Error("Invalid prepared update record");
  }
  const identity = {
    identifier,
    channel,
    version,
    hash,
    platform: platform2,
    arch: arch2,
    artifact_file: artifactFile
  };
  if (document["schema_version"] === 2) {
    const stagingPath = requireString(document, "staging_path");
    const recipePath = requireString(document, "recipe_path");
    const recipeSha256 = requireString(document, "recipe_sha256");
    if (!/^[a-f0-9]{64}$/.test(recipeSha256) || !isCanonicalAbsolutePath(stagingPath) || !isCanonicalAbsolutePath(recipePath) || stagingPath !== `${appBundlePath}.prepared-${hash}` || recipePath !== join4(extractionFolderFor(channelRoot), `${hash}.recipe.json`) || !isPlainManagedFile(channelRoot, recipePath)) {
      throw new Error("Invalid prepared update paths");
    }
    const stage = lstatSync2(stagingPath, { throwIfNoEntry: false });
    if (!stage?.isDirectory() || stage.isSymbolicLink()) {
      throw new Error("Prepared update staging directory is missing or unsafe");
    }
    return { ...identity, schema_version: 2, staging_path: stagingPath, recipe_path: recipePath, recipe_sha256: recipeSha256 };
  }
  const retainedTarPath = requireString(document, "retained_tar_path");
  const expectedTarPath = resolve3(join4(extractionFolderFor(channelRoot), `${hash}.tar`));
  if (!isCanonicalAbsolutePath(retainedTarPath) || retainedTarPath !== expectedTarPath) {
    throw new Error("Invalid prepared update record");
  }
  requireRegularFile(retainedTarPath, "Prepared update archive");
  return { ...identity, schema_version: 1, retained_tar_path: retainedTarPath };
}
function loadPreparedUpdate(info, channelRoot, appBundlePath = installedAppBundlePath(channelRoot)) {
  const recordPath = preparedUpdatePathFor(channelRoot);
  const stat = lstatSync2(recordPath, { throwIfNoEntry: false });
  if (!stat?.isFile() || stat.isSymbolicLink() || stat.size > 64 * 1024) {
    throw new Error("No valid prepared update is available");
  }
  return validatePreparedUpdate(JSON.parse(readFileSync3(recordPath, "utf8")), info, channelRoot, appBundlePath);
}
function preparedMatchesManifest(prepared, manifest) {
  return prepared.hash === manifest.hash && prepared.version === manifest.version && prepared.artifact_file === manifest.artifact.file;
}
function hasExactUpdateResultFields(document) {
  const keys = Object.keys(document).sort();
  return keys.length === UPDATE_RESULT_FIELDS.length && UPDATE_RESULT_FIELDS.every((field, index) => keys[index] === field);
}
function validateNativeUpdateResult(document, expectedTransactionId, info) {
  if (!isRecord(document) || !hasExactUpdateResultFields(document) || document["schema_version"] !== 1 || document["transaction_id"] !== expectedTransactionId || !TRANSACTION_ID_PATTERN2.test(expectedTransactionId) || typeof document["success"] !== "boolean" || typeof document["phase"] !== "string" || !UPDATE_RESULT_PHASES.has(document["phase"]) || typeof document["message"] !== "string" || document["message"].length === 0 || document["message"].length > 4096 || /[\u0000-\u001f\u007f]/.test(document["message"]) || document["identifier"] !== info.identifier || document["channel"] !== info.channel || typeof document["version"] !== "string" || !isSafeVersion(document["version"]) || typeof document["hash"] !== "string" || !SAFE_HASH_PATTERN.test(document["hash"])) {
    throw new Error("Invalid native update result");
  }
  const success = document["success"];
  const phase = document["phase"];
  if (success !== (phase === "complete")) {
    throw new Error("Invalid native update result phase");
  }
  return {
    schema_version: 1,
    transaction_id: expectedTransactionId,
    success,
    phase,
    message: document["message"],
    identifier: info.identifier,
    channel: info.channel,
    version: document["version"],
    hash: document["hash"]
  };
}
function reconcileNativeUpdateResultState(result, info) {
  if (result.success) {
    return {
      updateInfo: {
        version: result.version,
        hash: result.hash,
        updateAvailable: false,
        updateReady: false,
        error: ""
      },
      status: "complete",
      message: `Update to ${result.version} completed successfully`,
      details: { currentHash: result.hash, latestHash: result.hash }
    };
  }
  const message = `Update to ${result.version} failed during ${result.phase}: ${result.message}`;
  return {
    updateInfo: {
      version: result.version,
      hash: result.hash,
      updateAvailable: result.hash !== info.hash,
      updateReady: false,
      error: message
    },
    status: "error",
    message,
    details: {
      errorMessage: result.message,
      currentHash: info.hash,
      latestHash: result.hash
    }
  };
}
function preparedUpdateForResult(info, channelRoot) {
  try {
    return loadPreparedUpdate(info, channelRoot);
  } catch {
    return;
  }
}
function resultMatchesRunningState(result, info) {
  if (result.success) {
    return result.version === info.version && result.hash === info.hash;
  }
  return result.hash !== info.hash;
}
function scanNativeUpdateResults(info, channelRoot) {
  const empty = () => ({
    candidates: [],
    truncated: false
  });
  if (resolve3(channelRoot) !== channelRoot)
    return { ...empty(), truncated: true };
  const rootStat = lstatSync2(channelRoot, { throwIfNoEntry: false });
  if (!rootStat)
    return empty();
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) {
    return { ...empty(), truncated: true };
  }
  const names = [];
  let directory;
  try {
    directory = opendirSync(channelRoot);
    let entriesSeen = 0;
    for (;; ) {
      const entry = directory.readSync();
      if (!entry)
        break;
      entriesSeen += 1;
      if (entriesSeen > MAX_UPDATE_RESULT_DIRECTORY_ENTRIES) {
        return { ...empty(), truncated: true };
      }
      if (!UPDATE_RESULT_FILE_PATTERN.test(entry.name))
        continue;
      names.push(entry.name);
      if (names.length > MAX_UPDATE_RESULT_FILES) {
        return { ...empty(), truncated: true };
      }
    }
  } catch {
    return { ...empty(), truncated: true };
  } finally {
    try {
      directory?.closeSync();
    } catch {}
  }
  const candidates = [];
  for (const name of names) {
    const match = UPDATE_RESULT_FILE_PATTERN.exec(name);
    if (!match)
      continue;
    const path = join4(channelRoot, name);
    const stat = lstatSync2(path, { throwIfNoEntry: false });
    if (!stat?.isFile() || stat.isSymbolicLink() || stat.size <= 0 || stat.size > MAX_UPDATE_RESULT_BYTES) {
      continue;
    }
    try {
      const result = validateNativeUpdateResult(JSON.parse(readFileSync3(path, "utf8")), match[1], info);
      candidates.push({
        path,
        modifiedAt: Number.isFinite(stat.mtimeMs) ? stat.mtimeMs : 0,
        result
      });
    } catch {}
  }
  candidates.sort((left, right) => right.modifiedAt - left.modifiedAt || right.path.localeCompare(left.path));
  return {
    candidates,
    selected: candidates.find((candidate) => resultMatchesRunningState(candidate.result, info)),
    truncated: false
  };
}
function observedUpdateTransaction(channelRoot) {
  const path = join4(channelRoot, OBSERVED_UPDATE_RESULT_FILE);
  const stat = lstatSync2(path, { throwIfNoEntry: false });
  if (!stat?.isFile() || stat.isSymbolicLink() || stat.size > 4096)
    return;
  try {
    const document = JSON.parse(readFileSync3(path, "utf8"));
    if (!isRecord(document) || Object.keys(document).length !== 2 || document["schema_version"] !== 1 || typeof document["transaction_id"] !== "string" || !TRANSACTION_ID_PATTERN2.test(document["transaction_id"])) {
      return;
    }
    return document["transaction_id"];
  } catch {
    return;
  }
}
function markUpdateTransactionObserved(channelRoot, transactionId) {
  atomicWriteJson(join4(channelRoot, OBSERVED_UPDATE_RESULT_FILE), {
    schema_version: 1,
    transaction_id: transactionId
  });
}
function pendingResultMayArrive(info, channelRoot) {
  const prepared = preparedUpdateForResult(info, channelRoot);
  return Boolean(prepared && prepared.version === info.version && prepared.hash === info.hash);
}
function waitForResultPoll() {
  return new Promise((resolvePoll) => setTimeout(resolvePoll, UPDATE_RESULT_POLL_INTERVAL_MS));
}
async function reconcileNativeUpdateResultOperation() {
  const info = await Updater.getLocalInfo();
  if (!info.identifier || !info.channel || !info.version || !info.hash)
    return;
  let channelRoot;
  try {
    channelRoot = appDataFolderFor(info);
  } catch {
    return;
  }
  for (let attempt = 0;attempt < UPDATE_RESULT_POLL_ATTEMPTS; attempt += 1) {
    const scan = scanNativeUpdateResults(info, channelRoot);
    if (scan.truncated)
      return;
    const candidate = scan.selected;
    if (candidate) {
      reconciledNativeResultPath = candidate.path;
      if (observedUpdateTransaction(channelRoot) === candidate.result.transaction_id) {
        return;
      }
      const result = candidate.result;
      const reconciled = reconcileNativeUpdateResultState(result, info);
      updateInfo = reconciled.updateInfo;
      try {
        emitStatus(reconciled.status, reconciled.message, reconciled.details);
      } finally {
        try {
          markUpdateTransactionObserved(channelRoot, result.transaction_id);
        } catch {}
      }
      return;
    }
    if (!pendingResultMayArrive(info, channelRoot))
      return;
    await waitForResultPoll();
  }
}
function reconcileNativeUpdateResultOnce() {
  if (nativeResultReconciliation)
    return nativeResultReconciliation;
  const operation = Promise.resolve().then(reconcileNativeUpdateResultOperation);
  nativeResultReconciliation = operation;
  return operation;
}
function scheduleNativeUpdateResultReconciliation() {
  if (nativeResultReconciliation || nativeResultReconciliationScheduled)
    return;
  nativeResultReconciliationScheduled = true;
  setTimeout(() => {
    nativeResultReconciliationScheduled = false;
    reconcileNativeUpdateResultOnce().catch(() => {});
  }, 0);
}
function cleanupOlderNativeUpdateResults(info, channelRoot) {
  const scan = scanNativeUpdateResults(info, channelRoot);
  if (scan.truncated)
    return [];
  const candidatePaths = new Set(scan.candidates.map((candidate) => candidate.path));
  const keepPath = scan.selected?.path ?? (reconciledNativeResultPath && candidatePaths.has(reconciledNativeResultPath) ? reconciledNativeResultPath : undefined);
  const removed = [];
  for (const candidate of scan.candidates) {
    if (candidate.path === keepPath)
      continue;
    const stat = lstatSync2(candidate.path, { throwIfNoEntry: false });
    if (!stat?.isFile() || stat.isSymbolicLink())
      continue;
    try {
      rmSync(candidate.path);
      removed.push(candidate.path);
    } catch {}
  }
  return removed;
}
async function readBoundedResponse(response, maximumBytes) {
  if (!response.body)
    throw new Error("Response has no body");
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  for (;; ) {
    const { done, value } = await reader.read();
    if (done)
      break;
    total += value.byteLength;
    if (total > maximumBytes) {
      await reader.cancel();
      throw new Error("Update metadata exceeds the size limit");
    }
    chunks.push(value);
  }
  const result = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return result;
}
class TarStreamReader {
  iterator;
  chunk = new Uint8Array(0);
  chunkOffset = 0;
  bytesRead = 0;
  constructor(stream) {
    this.iterator = stream[Symbol.asyncIterator]();
  }
  async fill() {
    while (this.chunkOffset >= this.chunk.byteLength) {
      const next = await this.iterator.next();
      if (next.done)
        return false;
      this.chunk = next.value;
      this.chunkOffset = 0;
    }
    return true;
  }
  async readExactly(length) {
    const result = new Uint8Array(length);
    let resultOffset = 0;
    while (resultOffset < length) {
      if (!await this.fill())
        throw new Error("Truncated update archive");
      const available = this.chunk.byteLength - this.chunkOffset;
      const count = Math.min(available, length - resultOffset);
      result.set(this.chunk.subarray(this.chunkOffset, this.chunkOffset + count), resultOffset);
      this.chunkOffset += count;
      resultOffset += count;
      this.bytesRead += count;
    }
    return result;
  }
  async skip(length) {
    let remaining = length;
    while (remaining > 0) {
      if (!await this.fill())
        throw new Error("Truncated update archive");
      const count = Math.min(this.chunk.byteLength - this.chunkOffset, remaining);
      this.chunkOffset += count;
      this.bytesRead += count;
      remaining -= count;
    }
  }
  async close() {
    try {
      await this.iterator.return?.();
    } catch {}
  }
}
var tarDecoder = new TextDecoder("utf-8", { fatal: true });
function isPlainManagedFile(root, path) {
  const relativePath = relative(resolve3(root), resolve3(path));
  if (relativePath === "" || relativePath === ".." || relativePath.startsWith(`..${sep}`) || isAbsolute2(relativePath)) {
    return false;
  }
  const rootStat = lstatSync2(root, { throwIfNoEntry: false });
  if (!rootStat?.isDirectory() || rootStat.isSymbolicLink())
    return false;
  let current = resolve3(root);
  const components = relativePath.split(sep);
  for (const [index, component] of components.entries()) {
    current = join4(current, component);
    const stat = lstatSync2(current, { throwIfNoEntry: false });
    if (!stat || stat.isSymbolicLink())
      return false;
    if (index === components.length - 1)
      return stat.isFile();
    if (!stat.isDirectory())
      return false;
  }
  return false;
}
function getUpdateHelperSourceCandidates(channelRoot, appBundlePath, platform2 = OS) {
  const standalone = join4(channelRoot, platform2 === "win" ? "uninstall.exe" : "uninstall");
  const bundled = platform2 === "macos" ? join4(appBundlePath, "Contents", "Resources", "uninstall") : join4(appBundlePath, "Resources", "uninstall");
  return [standalone, bundled];
}
function resolveUpdateHelperSource(channelRoot, appBundlePath, platform2 = OS, preferBundled = false) {
  const candidates = getUpdateHelperSourceCandidates(channelRoot, appBundlePath, platform2);
  const indexes = preferBundled ? [1, 0] : [0, 1];
  const index = indexes.find((index2) => isPlainManagedFile(index2 === 0 ? channelRoot : appBundlePath, candidates[index2]));
  const source = index === undefined ? undefined : candidates[index];
  if (!source) {
    throw new Error("No installed or bundled native update manager is available");
  }
  return source;
}
function physicalTemporaryDirectory() {
  const temporaryDirectory = resolve3(tmpdir2());
  return OS === "win" ? temporaryDirectory : realpathSync.native(temporaryDirectory);
}
function copyUpdateHelper(channelRoot, appBundlePath, transactionId, preferBundled = false) {
  const source = resolveUpdateHelperSource(channelRoot, appBundlePath, OS, preferBundled);
  const destination = join4(physicalTemporaryDirectory(), `electrobun-update-${transactionId}${OS === "win" ? ".exe" : ""}`);
  let sourceDescriptor;
  let destinationDescriptor;
  try {
    sourceDescriptor = openSync(source, fsConstants.O_RDONLY | (fsConstants.O_NOFOLLOW ?? 0));
    if (!fstatSync(sourceDescriptor).isFile()) {
      throw new Error("Native update manager source is not a regular file");
    }
    destinationDescriptor = openSync(destination, "wx+", 448);
    const buffer = new Uint8Array(64 * 1024);
    for (;; ) {
      const bytesRead = readSync(sourceDescriptor, buffer, 0, buffer.byteLength, null);
      if (bytesRead === 0)
        break;
      writeAll(destinationDescriptor, buffer.subarray(0, bytesRead));
    }
    if (OS !== "win")
      fchmodSync(destinationDescriptor, 448);
    fsyncSync(destinationDescriptor);
    closeSync2(destinationDescriptor);
    destinationDescriptor = undefined;
    closeSync2(sourceDescriptor);
    sourceDescriptor = undefined;
    return destination;
  } catch (error) {
    if (destinationDescriptor !== undefined) {
      try {
        closeSync2(destinationDescriptor);
      } catch {}
    }
    if (sourceDescriptor !== undefined) {
      try {
        closeSync2(sourceDescriptor);
      } catch {}
    }
    rmSync(destination, { force: true });
    throw error;
  }
}
function isCanonicalAbsolutePath(path) {
  return isAbsolute2(path) && resolve3(path) === path && !path.includes("\x00");
}
function createNativeUpdatePlan(plan) {
  if (plan.schema_version !== 1 && plan.schema_version !== 2 || !TRANSACTION_ID_PATTERN2.test(plan.transaction_id) || !isSafeIdentityComponent(plan.identifier, plan.platform) || !isSafeIdentityComponent(plan.channel, plan.platform) || !isBuildEnvironment(plan.channel) || !isSafeVersion(plan.version) || !SAFE_HASH_PATTERN.test(plan.hash) || !Number.isSafeInteger(plan.parent_pid) || plan.parent_pid <= 0 || plan.platform !== OS || plan.arch !== ARCH || !["win", "linux", "macos"].includes(plan.platform) || !["x64", "arm64"].includes(plan.arch) || ![
    plan.channel_root,
    plan.app_bundle_path,
    plan.result_path
  ].every(isCanonicalAbsolutePath)) {
    throw new Error("Invalid native update plan");
  }
  const expectedResultPath = join4(plan.channel_root, `.electrobun-update-${plan.transaction_id}.result.json`);
  if (plan.result_path !== expectedResultPath) {
    throw new Error("Invalid native update plan paths");
  }
  if (plan.schema_version === 2) {
    if (plan.retained_tar_path !== "" || typeof plan.recipe_sha256 !== "string" || !/^[a-f0-9]{64}$/.test(plan.recipe_sha256) || !isCanonicalAbsolutePath(plan.staging_path) || !isCanonicalAbsolutePath(plan.recipe_path) || plan.staging_path !== `${plan.app_bundle_path}.prepared-${plan.hash}` || plan.recipe_path !== join4(plan.channel_root, "self-extraction", `${plan.hash}.recipe.json`)) {
      throw new Error("Invalid native update plan paths");
    }
  } else if (!isCanonicalAbsolutePath(plan.retained_tar_path) || plan.retained_tar_path !== join4(plan.channel_root, "self-extraction", `${plan.hash}.tar`)) {
    throw new Error("Invalid native update plan paths");
  }
  return { ...plan };
}
function resolveUpdateParentPid(launcherPid = process.env["ELECTROBUN_LAUNCHER_PID"], runtimePid = process.pid) {
  if (typeof launcherPid === "string" && /^[1-9]\d{0,9}$/.test(launcherPid)) {
    const parsed = Number(launcherPid);
    if (Number.isSafeInteger(parsed) && parsed <= 2147483647)
      return parsed;
  }
  return runtimePid;
}
async function checkForUpdateOperation() {
  emitStatus("checking", "Checking for updates...");
  const info = await Updater.getLocalInfo();
  if (!isBuildEnvironment(info.channel)) {
    checkedManifest = undefined;
    const message = `Unsupported update channel: ${info.channel}`;
    updateInfo = {
      version: info.version,
      hash: info.hash,
      updateAvailable: false,
      updateReady: false,
      error: message
    };
    emitStatus("error", message, { errorMessage: message });
    return updateInfo;
  }
  if (info.channel === "dev") {
    checkedManifest = undefined;
    updateInfo = {
      version: info.version,
      hash: info.hash,
      updateAvailable: false,
      updateReady: false,
      error: ""
    };
    emitStatus("no-update", "Dev channel - updates disabled", {
      currentHash: info.hash
    });
    return updateInfo;
  }
  const platformPrefix = getPlatformPrefix(info.channel, OS, ARCH);
  const cacheBuster = randomBytes3(8).toString("hex");
  const manifestBase = `${info.baseUrl.replace(/\/+$/, "")}/${platformPrefix}`;
  let updateInfoUrl = `${manifestBase}-update-v2.json?${cacheBuster}`;
  try {
    let response = await fetch(updateInfoUrl, {
      signal: AbortSignal.timeout(30000)
    });
    const legacyManifest = response.status === 404;
    if (legacyManifest) {
      await response.body?.cancel();
      updateInfoUrl = `${manifestBase}-update.json?${cacheBuster}`;
      response = await fetch(updateInfoUrl, {
        signal: AbortSignal.timeout(30000)
      });
    }
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    const bytes = await readBoundedResponse(response, MAX_UPDATE_DOCUMENT_BYTES);
    let document;
    try {
      document = JSON.parse(new TextDecoder().decode(bytes));
    } catch {
      throw new Error("update.json is not valid JSON");
    }
    const manifest = validateUpdateManifest(document, {
      identifier: info.identifier,
      channel: info.channel,
      platform: OS,
      arch: ARCH
    });
    if (!legacyManifest && manifest.artifact.tarSha256 === undefined) {
      throw new Error("Invalid update manifest: archive integrity metadata is required");
    }
    checkedManifest = manifest;
    let ready = false;
    try {
      const existing = loadPreparedUpdate(info, appDataFolderFor(info));
      if (preparedMatchesManifest(existing, manifest)) {
        ready = true;
      }
    } catch {}
    updateInfo = {
      version: manifest.version,
      hash: manifest.hash,
      updateAvailable: manifest.hash !== info.hash,
      updateReady: ready && manifest.hash !== info.hash,
      error: ""
    };
    if (updateInfo.updateAvailable) {
      emitStatus("update-available", `Update available: ${info.hash.slice(0, 8)} \u2192 ${manifest.hash.slice(0, 8)}`, { currentHash: info.hash, latestHash: manifest.hash });
    } else {
      emitStatus("no-update", "Already on latest version", {
        currentHash: info.hash
      });
    }
    return updateInfo;
  } catch (error) {
    checkedManifest = undefined;
    const message = `Failed to check for updates: ${error.message}`;
    updateInfo = {
      version: "",
      hash: "",
      updateAvailable: false,
      updateReady: false,
      error: message
    };
    emitStatus("error", message, {
      errorMessage: error.message,
      url: updateInfoUrl
    });
    return updateInfo;
  }
}
function checkForUpdate() {
  if (checkInFlight)
    return checkInFlight;
  const operation = checkForUpdateOperation();
  checkInFlight = operation;
  operation.then(() => {
    if (checkInFlight === operation)
      checkInFlight = undefined;
  }, () => {
    if (checkInFlight === operation)
      checkInFlight = undefined;
  });
  return operation;
}
async function withNativePreparationHelper(platform2, source, copy, execute, remove = (helper) => rmSync(helper, { force: true })) {
  if (platform2 !== "win")
    return execute(source);
  const helper = copy();
  try {
    await execute(helper);
  } finally {
    try {
      remove(helper);
    } catch {}
  }
}
async function executeNativePreparation(helper, args) {
  const child = Bun.spawn([helper, ...args], {
    stdio: ["ignore", "ignore", "pipe"]
  });
  const diagnostics = (async () => {
    const reader = child.stderr.getReader();
    const decoder = new TextDecoder;
    let tail = "";
    try {
      for (;; ) {
        const { done, value } = await reader.read();
        if (done)
          break;
        tail = (tail + decoder.decode(value, { stream: true })).slice(-8192);
      }
      return (tail + decoder.decode()).slice(-8192).trim();
    } finally {
      reader.releaseLock();
    }
  })();
  const [exitCode, message] = await Promise.all([child.exited, diagnostics]);
  if (exitCode !== 0) {
    throw new Error(`Native update preparation failed (${exitCode})${message ? `: ${message}` : ""}`);
  }
  if (message)
    console.warn(`[Updater] Native preparation diagnostics: ${message}`);
}
async function prepareNativeUpdate(options) {
  const { info, channelRoot, appBundlePath, transactionId } = options;
  const manifest = validateUpdateManifest(options.manifest, {
    identifier: info.identifier,
    channel: info.channel,
    platform: OS,
    arch: ARCH
  });
  if (!SAFE_HASH_PATTERN.test(info.hash) || !TRANSACTION_ID_PATTERN2.test(transactionId) || !isCanonicalAbsolutePath(channelRoot) || !isCanonicalAbsolutePath(appBundlePath) || OS !== "macos" && appBundlePath !== join4(channelRoot, "app")) {
    throw new Error("Invalid native preparation request");
  }
  const base = new URL(info.baseUrl);
  const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(base.hostname);
  if (base.protocol !== "https:" && !(base.protocol === "http:" && loopback) || base.username || base.password || base.search || base.hash) {
    throw new Error("Invalid update base URL");
  }
  const helper = resolveUpdateHelperSource(channelRoot, appBundlePath, OS, true);
  const requestPath = join4(channelRoot, `.electrobun-prepare-${transactionId}.json`);
  const request = {
    schema_version: 1,
    transaction_id: transactionId,
    identifier: manifest.identifier,
    channel: manifest.channel,
    platform: manifest.platform,
    arch: manifest.arch,
    version: manifest.version,
    hash: manifest.hash,
    base_hash: info.hash,
    base_url: info.baseUrl,
    artifact_file: manifest.artifact.file,
    channel_root: channelRoot,
    app_bundle_path: appBundlePath,
    ...manifest.artifact.tarSha256 === undefined ? {} : {
      tar_sha256: manifest.artifact.tarSha256,
      tar_size: manifest.artifact.tarSize
    }
  };
  atomicWriteJson(requestPath, request);
  try {
    await withNativePreparationHelper(OS, helper, () => copyUpdateHelper(channelRoot, appBundlePath, transactionId, true), (helper2) => (options.execute ?? executeNativePreparation)(helper2, ["--prepare-update", requestPath, "--quiet"]));
    const prepared = loadPreparedUpdate(info, channelRoot, appBundlePath);
    if (prepared.schema_version !== 2 || !preparedMatchesManifest(prepared, manifest)) {
      throw new Error("Native preparation did not publish the requested staged update");
    }
    return prepared;
  } finally {
    try {
      rmSync(requestPath, { force: true });
    } catch {}
  }
}
async function downloadUpdateOperation() {
  if (applyInFlight) {
    throw new Error("Cannot download an update while one is being applied");
  }
  emitStatus("download-starting", "Starting update download...");
  const info = await Updater.getLocalInfo();
  if (checkInFlight)
    await checkInFlight;
  if (!checkedManifest)
    await checkForUpdate();
  const manifest = checkedManifest;
  if (!manifest || manifest.hash === info.hash)
    return;
  const channelRoot = appDataFolderFor(info);
  mkdirSync(extractionFolderFor(channelRoot), { recursive: true });
  try {
    const existing = loadPreparedUpdate(info, channelRoot);
    if (preparedMatchesManifest(existing, manifest)) {
      updateInfo = { ...updateInfo, updateReady: true, error: "" };
      emitStatus("download-complete", "Update is already prepared", { latestHash: manifest.hash });
      return;
    }
  } catch {}
  try {
    emitStatus("downloading", "Preparing the update with the native updater...", {
      latestHash: manifest.hash
    });
    await prepareNativeUpdate({
      info,
      manifest,
      channelRoot,
      appBundlePath: installedAppBundlePath(channelRoot),
      transactionId: randomBytes3(16).toString("hex")
    });
    updateInfo = {
      version: manifest.version,
      hash: manifest.hash,
      updateAvailable: true,
      updateReady: true,
      error: ""
    };
    emitStatus("download-complete", "Update downloaded, verified, and staged", {
      latestHash: manifest.hash
    });
  } catch (error) {
    const message = `Failed to download update: ${error.message}`;
    updateInfo = { ...updateInfo, updateReady: false, error: message };
    emitStatus("error", message, { errorMessage: error.message });
  }
}
function downloadUpdate() {
  if (downloadInFlight)
    return downloadInFlight;
  const operation = downloadUpdateOperation();
  downloadInFlight = operation;
  operation.then(() => {
    if (downloadInFlight === operation)
      downloadInFlight = undefined;
  }, () => {
    if (downloadInFlight === operation)
      downloadInFlight = undefined;
  });
  return operation;
}
async function applyUpdateOperation() {
  if (downloadInFlight)
    await downloadInFlight;
  const info = await Updater.getLocalInfo();
  const channelRoot = appDataFolderFor(info);
  let prepared;
  try {
    prepared = loadPreparedUpdate(info, channelRoot);
  } catch (error) {
    const message = `Cannot apply update: ${error.message}`;
    updateInfo = { ...updateInfo, updateReady: false, error: message };
    emitStatus("error", message, { errorMessage: error.message });
    return;
  }
  if (prepared.hash === info.hash) {
    emitStatus("no-update", "Already on latest version", {
      currentHash: info.hash
    });
    return;
  }
  const transactionId = randomBytes3(16).toString("hex");
  const appBundlePath = installedAppBundlePath(channelRoot);
  const planPath = join4(channelRoot, `.electrobun-update-${transactionId}.json`);
  const resultPath = join4(channelRoot, `.electrobun-update-${transactionId}.result.json`);
  const payload = prepared.schema_version === 2 ? { schema_version: 2, retained_tar_path: "", staging_path: prepared.staging_path, recipe_path: prepared.recipe_path, recipe_sha256: prepared.recipe_sha256 } : { schema_version: 1, retained_tar_path: prepared.retained_tar_path };
  const plan = createNativeUpdatePlan({
    ...payload,
    transaction_id: transactionId,
    identifier: info.identifier,
    channel: info.channel,
    platform: OS,
    arch: ARCH,
    version: prepared.version,
    hash: prepared.hash,
    channel_root: channelRoot,
    app_bundle_path: appBundlePath,
    parent_pid: resolveUpdateParentPid(),
    result_path: resultPath
  });
  const approval = requestQuitApproval();
  if (!approval) {
    emitStatus("idle", "Update restart was cancelled by a before-quit handler");
    return;
  }
  let helperPath;
  let planPublished = false;
  let windowsTaskPlan;
  try {
    emitStatus("applying", "Preparing update handoff...");
    cleanupOlderNativeUpdateResults(info, channelRoot);
    helperPath = copyUpdateHelper(channelRoot, appBundlePath, transactionId, prepared.schema_version === 2);
    atomicWriteJson(planPath, plan);
    planPublished = true;
    if (OS !== "win")
      chmodSync(planPath, 256);
    if (OS === "win") {
      const taskName = createWindowsUpdateTaskName(transactionId);
      windowsTaskPlan = createWindowsUpdateTaskPlan(taskName, helperPath, planPath);
      executeWindowsUpdateTaskPlan(windowsTaskPlan, (command) => {
        execFileSync(command.executable, command.args, {
          stdio: "ignore",
          windowsHide: true
        });
      });
    } else {
      const child = Bun.spawn([helperPath, "--apply-update", planPath, "--quiet"], {
        detached: true,
        stdio: ["ignore", "ignore", "ignore"]
      });
      child.unref();
    }
    emitStatus("launching-new-version", "Update prepared; restarting application...");
    quitAfterApproval(approval, 0);
  } catch (error) {
    cancelQuitApproval(approval);
    if (windowsTaskPlan) {
      try {
        execFileSync(windowsTaskPlan.deleteTask.executable, windowsTaskPlan.deleteTask.args, { stdio: "ignore", windowsHide: true });
      } catch {}
    }
    if (planPublished)
      rmSync(planPath, { force: true });
    if (helperPath)
      rmSync(helperPath, { force: true });
    const message = `Failed to start update helper: ${error.message}`;
    updateInfo = { ...updateInfo, error: message };
    emitStatus("error", message, { errorMessage: error.message });
  }
}
function applyUpdate() {
  if (applyInFlight)
    return applyInFlight;
  const operation = applyUpdateOperation();
  applyInFlight = operation;
  operation.then(() => {
    if (applyInFlight === operation)
      applyInFlight = undefined;
  }, () => {
    if (applyInFlight === operation)
      applyInFlight = undefined;
  });
  return operation;
}
var Updater = {
  updateInfo: () => updateInfo,
  getStatusHistory: () => [...statusHistory],
  clearStatusHistory: () => {
    statusHistory.length = 0;
  },
  onStatusChange: (callback) => {
    onStatusChangeCallback = callback;
    if (callback)
      scheduleNativeUpdateResultReconciliation();
  },
  checkForUpdate,
  downloadUpdate,
  applyUpdate,
  channelBucketUrl: async () => {
    return (await Updater.getLocalInfo()).baseUrl;
  },
  appDataFolder: async () => {
    return appDataFolderFor(await Updater.getLocalInfo());
  },
  localInfo: {
    version: async () => (await Updater.getLocalInfo()).version,
    hash: async () => (await Updater.getLocalInfo()).hash,
    channel: async () => (await Updater.getLocalInfo()).channel,
    baseUrl: async () => (await Updater.getLocalInfo()).baseUrl
  },
  getLocalInfo: async () => {
    if (localInfo) {
      scheduleNativeUpdateResultReconciliation();
      return localInfo;
    }
    try {
      localInfo = await Bun.file("../Resources/version.json").json();
    } catch (error) {
      console.error("Failed to read version.json", error);
      localInfo = {
        identifier: "",
        channel: "",
        version: "",
        hash: "",
        baseUrl: "",
        name: ""
      };
    }
    scheduleNativeUpdateResultReconciliation();
    return localInfo;
  },
  getLocallocalInfo: async () => {
    console.error("[Electrobun] Updater.getLocallocalInfo() is deprecated. Use Updater.getLocalInfo() instead.");
    return Updater.getLocalInfo();
  }
};

// .hutch/devkit/api/sdks/main/index.ts
init_Utils();
init_Socket();

// .hutch/devkit/api/sdks/main/webGPU.ts
import { existsSync } from "fs";
import { join as join5, dirname as dirname3 } from "path";
import { dlopen as dlopen2, suffix as suffix2, FFIType as FFIType2 } from "bun:ffi";
var WGPU_SYMBOLS = {
  wgpuCreateInstance: { args: [FFIType2.ptr], returns: FFIType2.ptr },
  wgpuGetInstanceFeatures: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuGetInstanceLimits: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuHasInstanceFeature: { args: [FFIType2.u32], returns: FFIType2.u32 },
  wgpuGetProcAddress: { args: [FFIType2.ptr], returns: FFIType2.ptr },
  wgpuAdapterCreateDevice: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuAdapterGetFeatures: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuAdapterGetFormatCapabilities: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuAdapterGetInfo: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuAdapterGetInstance: { args: [FFIType2.ptr], returns: FFIType2.ptr },
  wgpuAdapterGetLimits: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuAdapterHasFeature: { args: [FFIType2.ptr, FFIType2.u32], returns: FFIType2.u32 },
  wgpuAdapterRequestDevice: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u64 },
  wgpuAdapterAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuAdapterRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuAdapterInfoFreeMembers: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuAdapterPropertiesMemoryHeapsFreeMembers: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuAdapterPropertiesSubgroupMatrixConfigsFreeMembers: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuBindGroupSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuBindGroupAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuBindGroupRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuBindGroupLayoutSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuBindGroupLayoutAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuBindGroupLayoutRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuBufferCreateTexelView: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuBufferDestroy: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuBufferGetConstMappedRange: { args: [FFIType2.ptr, FFIType2.u64, FFIType2.u64], returns: FFIType2.ptr },
  wgpuBufferGetMappedRange: { args: [FFIType2.ptr, FFIType2.u64, FFIType2.u64], returns: FFIType2.ptr },
  wgpuBufferGetMapState: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuBufferGetSize: { args: [FFIType2.ptr], returns: FFIType2.u64 },
  wgpuBufferGetUsage: { args: [FFIType2.ptr], returns: FFIType2.u64 },
  wgpuBufferMapAsync: { args: [FFIType2.ptr, FFIType2.u64, FFIType2.u64, FFIType2.u64, FFIType2.ptr], returns: FFIType2.u64 },
  wgpuBufferReadMappedRange: { args: [FFIType2.ptr, FFIType2.u64, FFIType2.ptr, FFIType2.u64], returns: FFIType2.u32 },
  wgpuBufferSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuBufferUnmap: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuBufferWriteMappedRange: { args: [FFIType2.ptr, FFIType2.u64, FFIType2.ptr, FFIType2.u64], returns: FFIType2.u32 },
  wgpuBufferAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuBufferRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandBufferSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandBufferAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandBufferRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandEncoderBeginComputePass: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuCommandEncoderBeginRenderPass: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuCommandEncoderClearBuffer: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u64, FFIType2.u64], returns: FFIType2.void },
  wgpuCommandEncoderCopyBufferToBuffer: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u64, FFIType2.ptr, FFIType2.u64, FFIType2.u64], returns: FFIType2.void },
  wgpuCommandEncoderCopyBufferToTexture: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandEncoderCopyTextureToBuffer: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandEncoderCopyTextureToTexture: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandEncoderFinish: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuCommandEncoderInjectValidationError: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandEncoderInsertDebugMarker: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandEncoderPopDebugGroup: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandEncoderPushDebugGroup: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandEncoderResolveQuerySet: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u32, FFIType2.u32, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuCommandEncoderSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandEncoderWriteBuffer: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u64, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuCommandEncoderWriteTimestamp: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u32], returns: FFIType2.void },
  wgpuCommandEncoderAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuCommandEncoderRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePassEncoderDispatchWorkgroups: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.u32, FFIType2.u32], returns: FFIType2.void },
  wgpuComputePassEncoderDispatchWorkgroupsIndirect: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuComputePassEncoderEnd: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePassEncoderInsertDebugMarker: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePassEncoderPopDebugGroup: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePassEncoderPushDebugGroup: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePassEncoderSetBindGroup: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr, FFIType2.u64, FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePassEncoderSetImmediates: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuComputePassEncoderSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePassEncoderSetPipeline: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePassEncoderSetResourceTable: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePassEncoderWriteTimestamp: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u32], returns: FFIType2.void },
  wgpuComputePassEncoderAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePassEncoderRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePipelineGetBindGroupLayout: { args: [FFIType2.ptr, FFIType2.u32], returns: FFIType2.ptr },
  wgpuComputePipelineSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePipelineAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuComputePipelineRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuDawnDrmFormatCapabilitiesFreeMembers: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuDeviceCreateBindGroup: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateBindGroupLayout: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateBuffer: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateCommandEncoder: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateComputePipeline: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateComputePipelineAsync: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u64 },
  wgpuDeviceCreateErrorBuffer: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateErrorExternalTexture: { args: [FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateErrorShaderModule: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateErrorTexture: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateExternalTexture: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreatePipelineLayout: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateQuerySet: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateRenderBundleEncoder: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateRenderPipeline: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateRenderPipelineAsync: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u64 },
  wgpuDeviceCreateResourceTable: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateSampler: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateShaderModule: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceCreateTexture: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceDestroy: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuDeviceForceLoss: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr], returns: FFIType2.void },
  wgpuDeviceGetAdapter: { args: [FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceGetAdapterInfo: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuDeviceGetAHardwareBufferProperties: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuDeviceGetFeatures: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuDeviceGetLimits: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuDeviceGetLostFuture: { args: [FFIType2.ptr], returns: FFIType2.u64 },
  wgpuDeviceGetQueue: { args: [FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceHasFeature: { args: [FFIType2.ptr, FFIType2.u32], returns: FFIType2.u32 },
  wgpuDeviceImportSharedBufferMemory: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceImportSharedFence: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceImportSharedTextureMemory: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuDeviceInjectError: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr], returns: FFIType2.void },
  wgpuDevicePopErrorScope: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u64 },
  wgpuDevicePushErrorScope: { args: [FFIType2.ptr, FFIType2.u32], returns: FFIType2.void },
  wgpuDeviceSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuDeviceSetLoggingCallback: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuDeviceTick: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuDeviceValidateTextureDescriptor: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuDeviceAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuDeviceRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuExternalTextureDestroy: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuExternalTextureExpire: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuExternalTextureRefresh: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuExternalTextureSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuExternalTextureAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuExternalTextureRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuInstanceCreateSurface: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuInstanceGetWGSLLanguageFeatures: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuInstanceHasWGSLLanguageFeature: { args: [FFIType2.ptr, FFIType2.u32], returns: FFIType2.u32 },
  wgpuInstanceProcessEvents: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuInstanceRequestAdapter: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u64 },
  wgpuInstanceWaitAny: { args: [FFIType2.ptr, FFIType2.u64, FFIType2.ptr, FFIType2.u64], returns: FFIType2.u32 },
  wgpuInstanceAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuInstanceRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuPipelineLayoutSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuPipelineLayoutAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuPipelineLayoutRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuQuerySetDestroy: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuQuerySetGetCount: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuQuerySetGetType: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuQuerySetSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuQuerySetAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuQuerySetRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuQueueCopyExternalTextureForBrowser: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuQueueCopyTextureForBrowser: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuQueueOnSubmittedWorkDone: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u64 },
  wgpuQueueSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuQueueSubmit: { args: [FFIType2.ptr, FFIType2.u64, FFIType2.ptr], returns: FFIType2.void },
  wgpuQueueWriteBuffer: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u64, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuQueueWriteTexture: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr, FFIType2.u64, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuQueueAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuQueueRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleEncoderDraw: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.u32, FFIType2.u32, FFIType2.u32], returns: FFIType2.void },
  wgpuRenderBundleEncoderDrawIndexed: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.u32, FFIType2.u32, FFIType2.i32, FFIType2.u32], returns: FFIType2.void },
  wgpuRenderBundleEncoderDrawIndexedIndirect: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderBundleEncoderDrawIndirect: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderBundleEncoderFinish: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuRenderBundleEncoderInsertDebugMarker: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleEncoderPopDebugGroup: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleEncoderPushDebugGroup: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleEncoderSetBindGroup: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr, FFIType2.u64, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleEncoderSetImmediates: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderBundleEncoderSetIndexBuffer: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u32, FFIType2.u64, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderBundleEncoderSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleEncoderSetPipeline: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleEncoderSetResourceTable: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleEncoderSetVertexBuffer: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr, FFIType2.u64, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderBundleEncoderAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderBundleEncoderRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderBeginOcclusionQuery: { args: [FFIType2.ptr, FFIType2.u32], returns: FFIType2.void },
  wgpuRenderPassEncoderDraw: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.u32, FFIType2.u32, FFIType2.u32], returns: FFIType2.void },
  wgpuRenderPassEncoderDrawIndexed: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.u32, FFIType2.u32, FFIType2.i32, FFIType2.u32], returns: FFIType2.void },
  wgpuRenderPassEncoderDrawIndexedIndirect: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderPassEncoderDrawIndirect: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderPassEncoderEnd: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderEndOcclusionQuery: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderExecuteBundles: { args: [FFIType2.ptr, FFIType2.u64, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderInsertDebugMarker: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderMultiDrawIndexedIndirect: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u64, FFIType2.u32, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderPassEncoderMultiDrawIndirect: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u64, FFIType2.u32, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderPassEncoderPixelLocalStorageBarrier: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderPopDebugGroup: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderPushDebugGroup: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderSetBindGroup: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr, FFIType2.u64, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderSetBlendConstant: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderSetImmediates: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderPassEncoderSetIndexBuffer: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u32, FFIType2.u64, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderPassEncoderSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderSetPipeline: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderSetResourceTable: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderSetScissorRect: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.u32, FFIType2.u32, FFIType2.u32], returns: FFIType2.void },
  wgpuRenderPassEncoderSetStencilReference: { args: [FFIType2.ptr, FFIType2.u32], returns: FFIType2.void },
  wgpuRenderPassEncoderSetVertexBuffer: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr, FFIType2.u64, FFIType2.u64], returns: FFIType2.void },
  wgpuRenderPassEncoderSetViewport: { args: [FFIType2.ptr, FFIType2.f32, FFIType2.f32, FFIType2.f32, FFIType2.f32, FFIType2.f32, FFIType2.f32], returns: FFIType2.void },
  wgpuRenderPassEncoderWriteTimestamp: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.u32], returns: FFIType2.void },
  wgpuRenderPassEncoderAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPassEncoderRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPipelineGetBindGroupLayout: { args: [FFIType2.ptr, FFIType2.u32], returns: FFIType2.ptr },
  wgpuRenderPipelineSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPipelineAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuRenderPipelineRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuResourceTableDestroy: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuResourceTableGetSize: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuResourceTableInsertBinding: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuResourceTableRemoveBinding: { args: [FFIType2.ptr, FFIType2.u32], returns: FFIType2.u32 },
  wgpuResourceTableUpdate: { args: [FFIType2.ptr, FFIType2.u32, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuResourceTableAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuResourceTableRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSamplerSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuSamplerAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSamplerRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuShaderModuleGetCompilationInfo: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u64 },
  wgpuShaderModuleSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuShaderModuleAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuShaderModuleRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSharedBufferMemoryBeginAccess: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuSharedBufferMemoryCreateBuffer: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuSharedBufferMemoryEndAccess: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuSharedBufferMemoryGetProperties: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuSharedBufferMemoryIsDeviceLost: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuSharedBufferMemorySetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuSharedBufferMemoryAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSharedBufferMemoryRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSharedBufferMemoryEndAccessStateFreeMembers: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSharedFenceExportInfo: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuSharedFenceAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSharedFenceRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSharedTextureMemoryBeginAccess: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuSharedTextureMemoryCreateTexture: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuSharedTextureMemoryEndAccess: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuSharedTextureMemoryGetProperties: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuSharedTextureMemoryIsDeviceLost: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuSharedTextureMemorySetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuSharedTextureMemoryAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSharedTextureMemoryRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSharedTextureMemoryEndAccessStateFreeMembers: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSupportedFeaturesFreeMembers: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSupportedInstanceFeaturesFreeMembers: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSupportedWGSLLanguageFeaturesFreeMembers: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSurfaceConfigure: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuSurfaceGetCapabilities: { args: [FFIType2.ptr, FFIType2.ptr, FFIType2.ptr], returns: FFIType2.u32 },
  wgpuSurfaceGetCurrentTexture: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuSurfacePresent: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuSurfaceSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuSurfaceUnconfigure: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSurfaceAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSurfaceRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuSurfaceCapabilitiesFreeMembers: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuTexelBufferViewSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuTexelBufferViewAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuTexelBufferViewRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuTextureCreateErrorView: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuTextureCreateView: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.ptr },
  wgpuTextureDestroy: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuTextureGetDepthOrArrayLayers: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuTextureGetDimension: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuTextureGetFormat: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuTextureGetHeight: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuTextureGetMipLevelCount: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuTextureGetSampleCount: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuTextureGetTextureBindingViewDimension: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuTextureGetUsage: { args: [FFIType2.ptr], returns: FFIType2.u64 },
  wgpuTextureGetWidth: { args: [FFIType2.ptr], returns: FFIType2.u32 },
  wgpuTexturePin: { args: [FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuTextureSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuTextureSetOwnershipForMemoryDump: { args: [FFIType2.ptr, FFIType2.u64], returns: FFIType2.void },
  wgpuTextureUnpin: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuTextureAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuTextureRelease: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuTextureViewSetLabel: { args: [FFIType2.ptr, FFIType2.ptr], returns: FFIType2.void },
  wgpuTextureViewAddRef: { args: [FFIType2.ptr], returns: FFIType2.void },
  wgpuTextureViewRelease: { args: [FFIType2.ptr], returns: FFIType2.void }
};
var WGPU_LIB_NAMES = {
  darwin: ["libwebgpu_dawn.dylib"],
  win32: ["webgpu_dawn.dll", "libwebgpu_dawn.dll"],
  linux: ["libwebgpu_dawn.so"]
};
function findWgpuLibraryPath() {
  const envPath = process.env["ELECTROBUN_WGPU_PATH"];
  if (envPath && existsSync(envPath))
    return envPath;
  const names = WGPU_LIB_NAMES[process.platform] ?? ["libwebgpu_dawn." + suffix2];
  for (const name of names) {
    const cwdCandidate = join5(process.cwd(), name);
    if (existsSync(cwdCandidate))
      return cwdCandidate;
    const execDir = dirname3(process.execPath);
    const macCandidate = join5(execDir, "..", "MacOS", name);
    if (existsSync(macCandidate))
      return macCandidate;
    const resCandidate = join5(execDir, "..", "Resources", name);
    if (existsSync(resCandidate))
      return resCandidate;
    const execCandidate = join5(execDir, name);
    if (existsSync(execCandidate))
      return execCandidate;
  }
  return null;
}
var native2 = (() => {
  const libPath = findWgpuLibraryPath();
  if (!libPath) {
    return {
      available: false,
      path: null,
      symbols: {},
      close: () => {}
    };
  }
  try {
    const lib = dlopen2(libPath, WGPU_SYMBOLS);
    const symbols = process.platform === "linux" ? {
      ...lib.symbols,
      wgpuTextureRelease: (texture) => {
        if (texture)
          lib.symbols.wgpuTextureRelease(texture);
      }
    } : lib.symbols;
    return {
      available: true,
      path: libPath,
      symbols,
      close: lib.close
    };
  } catch {
    return {
      available: false,
      path: libPath,
      symbols: {},
      close: () => {}
    };
  }
})();
var WGPU = {
  native: native2
};
var webGPU_default = WGPU;

// .hutch/devkit/api/sdks/main/webgpuAdapter.ts
init_native();
import { ptr as ptr2, toArrayBuffer as toArrayBuffer2, JSCallback as JSCallback2 } from "bun:ffi";
import { inflateSync } from "zlib";

// .hutch/devkit/api/sdks/main/webgpuRenderPass.ts
var WGPULoadOp = {
  Undefined: 0,
  Load: 1,
  Clear: 2
};
var WGPUStoreOp = {
  Undefined: 0,
  Store: 1,
  Discard: 2
};
function mapLoadOp(op) {
  if (typeof op === "number")
    return op;
  return op === "load" ? WGPULoadOp.Load : WGPULoadOp.Clear;
}
function mapStoreOp(op) {
  if (typeof op === "number")
    return op;
  return op === "discard" ? WGPUStoreOp.Discard : WGPUStoreOp.Store;
}
function mapOptionalLoadOp(op) {
  return op == null ? WGPULoadOp.Undefined : mapLoadOp(op);
}
function mapOptionalStoreOp(op) {
  return op == null ? WGPUStoreOp.Undefined : mapStoreOp(op);
}
function normalizeRenderPassDepthStencilFields(descriptor) {
  return {
    depthLoadOp: mapOptionalLoadOp(descriptor.depthLoadOp),
    depthStoreOp: mapOptionalStoreOp(descriptor.depthStoreOp),
    depthClearValue: descriptor.depthClearValue ?? 0,
    depthReadOnly: !!descriptor.depthReadOnly,
    stencilLoadOp: mapOptionalLoadOp(descriptor.stencilLoadOp),
    stencilStoreOp: mapOptionalStoreOp(descriptor.stencilStoreOp),
    stencilClearValue: descriptor.stencilClearValue ?? 0,
    stencilReadOnly: !!descriptor.stencilReadOnly
  };
}

// .hutch/devkit/api/sdks/main/webgpuContextKey.ts
function getWebgpuContextKey(target) {
  return target.wgpuViewId ?? target.id;
}

// .hutch/devkit/api/sdks/main/webgpuAdapter.ts
init_webgpuContextRegistry();

// .hutch/devkit/api/sdks/main/webgpuPresentationState.ts
class WebgpuPresentationState {
  queueBySurface = new Map;
  surfacesByQueue = new Map;
  pendingSurfaces = new Set;
  attach(queue, surface) {
    const previousQueue = this.queueBySurface.get(surface);
    if (previousQueue === queue)
      return;
    if (previousQueue)
      this.detachSurface(surface);
    this.queueBySurface.set(surface, queue);
    let surfaces = this.surfacesByQueue.get(queue);
    if (!surfaces) {
      surfaces = new Set;
      this.surfacesByQueue.set(queue, surfaces);
    }
    surfaces.add(surface);
  }
  markPending(surface) {
    if (!this.queueBySurface.has(surface)) {
      throw new Error("WebGPU surface is not configured with a live queue");
    }
    this.pendingSurfaces.add(surface);
  }
  isPending(surface) {
    return this.pendingSurfaces.has(surface);
  }
  takePending(surface) {
    if (!this.pendingSurfaces.has(surface))
      return false;
    this.pendingSurfaces.delete(surface);
    return true;
  }
  presentPending(queue, present) {
    const surfaces = this.surfacesByQueue.get(queue);
    if (!surfaces)
      return 0;
    let presented = 0;
    let firstError;
    for (const surface of surfaces) {
      if (!this.takePending(surface))
        continue;
      try {
        present(surface);
        presented += 1;
      } catch (error) {
        firstError ??= error;
      }
    }
    if (firstError)
      throw firstError;
    return presented;
  }
  presentPendingSurface(queue, surface, present) {
    if (this.queueBySurface.get(surface) !== queue)
      return false;
    if (!this.takePending(surface))
      return false;
    present(surface);
    return true;
  }
  detachSurface(surface) {
    this.pendingSurfaces.delete(surface);
    const queue = this.queueBySurface.get(surface);
    if (!queue)
      return;
    this.queueBySurface.delete(surface);
    const surfaces = this.surfacesByQueue.get(queue);
    if (!surfaces)
      return;
    surfaces.delete(surface);
    if (surfaces.size === 0)
      this.surfacesByQueue.delete(queue);
  }
  detachQueue(queue) {
    const surfaces = [...this.surfacesByQueue.get(queue) ?? []];
    for (const surface of surfaces)
      this.detachSurface(surface);
    return surfaces;
  }
}

// .hutch/devkit/api/sdks/main/webgpuAdapter.ts
var WGPUNative = webGPU_default.native;
var WGPUTextureFormat_BGRA8Unorm = 27;
var WGPUTextureFormat_BGRA8UnormSrgb = 28;
var WGPUTextureFormat_RGBA8Unorm = 22;
var WGPUTextureFormat_RGBA8UnormSrgb = 23;
var WGPUTextureFormat_Depth24Plus = 46;
var WGPUTextureFormat_Depth24PlusStencil8 = 47;
var WGPUTextureFormat_Depth32Float = 48;
var WGPUTextureFormat_Depth16Unorm = 45;
var WGPUTextureFormat_Depth32FloatStencil8 = 49;
var WGPUTextureFormat_RGBA32Sint = 43;
var WGPUTextureFormat_RGBA32Uint = 42;
var WGPUTextureFormat_RGBA16Sint = 39;
var WGPUTextureFormat_RGBA16Uint = 38;
var WGPUTextureFormat_RGBA16Float = 40;
var WGPUTextureFormat_RG32Sint = 35;
var WGPUTextureFormat_RG32Uint = 34;
var WGPUTextureFormat_RG32Float = 33;
var WGPUTextureFormat_R32Sint = 16;
var WGPUTextureFormat_R32Uint = 15;
var WGPUTextureFormat_R32Float = 14;
var WGPUTextureFormat_RGBA8Snorm = 24;
var WGPUTextureFormat_RGBA8Uint = 25;
var WGPUTextureFormat_RGBA8Sint = 26;
var WGPUTextureFormat_RG8Unorm = 10;
var WGPUTextureFormat_RG8Snorm = 11;
var WGPUTextureFormat_RG8Uint = 12;
var WGPUTextureFormat_RG8Sint = 13;
var WGPUTextureFormat_R8Unorm = 1;
var WGPUTextureFormat_R8Snorm = 2;
var WGPUTextureFormat_R8Uint = 3;
var WGPUTextureFormat_R8Sint = 4;
var WGPUTextureUsage_RenderAttachment = 0x0000000000000010n;
var WGPUPresentMode_Fifo = 1;
var WGPUCompositeAlphaMode_Opaque = 1;
var WGPUCompositeAlphaMode_Premultiplied = 2;
var WGPUCompositeAlphaMode_Unpremultiplied = 3;
var WGPUVertexFormat_Float32 = 28;
var WGPUVertexFormat_Float32x2 = 29;
var WGPUVertexFormat_Float32x3 = 30;
var WGPUVertexFormat_Float32x4 = 31;
var WGPUVertexFormat_Uint32 = 32;
var WGPUVertexFormat_Uint32x2 = 33;
var WGPUVertexFormat_Uint32x3 = 34;
var WGPUVertexFormat_Uint32x4 = 35;
var WGPUVertexFormat_Sint32 = 36;
var WGPUVertexFormat_Sint32x2 = 37;
var WGPUVertexFormat_Sint32x3 = 38;
var WGPUVertexFormat_Sint32x4 = 39;
var WGPUVertexStepMode_Vertex = 1;
var WGPUVertexStepMode_Instance = 2;
var WGPUPrimitiveTopology_PointList = 1;
var WGPUPrimitiveTopology_LineList = 2;
var WGPUPrimitiveTopology_LineStrip = 3;
var WGPUPrimitiveTopology_TriangleList = 4;
var WGPUPrimitiveTopology_TriangleStrip = 5;
var WGPUFrontFace_CCW = 1;
var WGPUFrontFace_CW = 2;
var WGPUCullMode_None = 1;
var WGPUCullMode_Front = 2;
var WGPUCullMode_Back = 3;
var WGPULoadOp_Clear = 2;
var WGPUStoreOp_Store = 1;
var WGPUTextureDimension_2D = 2;
var WGPUTextureViewDimension_2D = 2;
var WGPUTextureViewDimension_2DArray = 3;
var WGPUTextureViewDimension_3D = 6;
var WGPUTextureViewDimension_Cube = 4;
var WGPUTextureViewDimension_CubeArray = 5;
var WGPUTextureAspect_All = 1;
var WGPUTextureAspect_StencilOnly = 2;
var WGPUTextureAspect_DepthOnly = 3;
var WGPUCompareFunction_Never = 1;
var WGPUCompareFunction_Less = 2;
var WGPUCompareFunction_Equal = 3;
var WGPUCompareFunction_LessEqual = 4;
var WGPUCompareFunction_Greater = 5;
var WGPUCompareFunction_NotEqual = 6;
var WGPUCompareFunction_GreaterEqual = 7;
var WGPUCompareFunction_Always = 8;
var WGPUAddressMode_ClampToEdge = 1;
var WGPUAddressMode_Repeat = 2;
var WGPUAddressMode_MirrorRepeat = 3;
var WGPUFilterMode_Nearest = 1;
var WGPUFilterMode_Linear = 2;
var WGPUMipmapFilterMode_Nearest = 1;
var WGPUMipmapFilterMode_Linear = 2;
var WGPUBufferUsage_MapRead = 0x0000000000000001n;
var WGPUMapMode_Read = 0x0000000000000001n;
var WGPUMapMode_Write = 0x0000000000000002n;
var WGPUCallbackMode_AllowSpontaneous = 3;
var WGPUBufferMapState_Mapped = 3;
var WGPUMapAsyncStatus_Success = 1;
var WGPUQueueWorkDoneStatus_Success = 1;
var WGPUColorWriteMask_All = 15;
var WGPUBlendOperation_Add = 1;
var WGPUBlendFactor_One = 2;
var WGPUBlendFactor_Zero = 1;
var WGPUBlendFactor_SrcAlpha = 5;
var WGPUBlendFactor_OneMinusSrcAlpha = 6;
var WGPUShaderStage_Vertex = 1;
var WGPUShaderStage_Fragment = 2;
var WGPUShaderStage_Compute = 4;
var WGPUBufferBindingType_Uniform = 2;
var WGPUBufferBindingType_Storage = 3;
var WGPUBufferBindingType_ReadOnlyStorage = 4;
var WGPUSamplerBindingType_Filtering = 2;
var WGPUSamplerBindingType_NonFiltering = 3;
var WGPUSamplerBindingType_Comparison = 4;
var WGPUTextureSampleType_Float = 2;
var WGPUTextureSampleType_UnfilterableFloat = 3;
var WGPUTextureSampleType_Depth = 4;
var WGPUTextureSampleType_Sint = 5;
var WGPUTextureSampleType_Uint = 6;
var WGPUStorageTextureAccess_WriteOnly = 2;
var WGPUStorageTextureAccess_ReadOnly = 3;
var WGPUStorageTextureAccess_ReadWrite = 4;
var WGPU_STRLEN = 0xffffffffffffffffn;
var WGPU_DEPTH_SLICE_UNDEFINED = 4294967295;
var WGPU_CALLBACK_KEEPALIVE = [];
var VIEW_CONTEXTS = new WebgpuContextRegistry;
var PRESENTATION_STATE = new WebgpuPresentationState;
var MAP_ASYNC_RESOLVERS = new Map;
var WORK_DONE_RESOLVERS = new Map;
var bufferMapCallback = new JSCallback2((status, _message, userdata1, _userdata2) => {
  const key = Number(userdata1);
  const resolve4 = MAP_ASYNC_RESOLVERS.get(key);
  if (resolve4) {
    MAP_ASYNC_RESOLVERS.delete(key);
    resolve4(status === WGPUMapAsyncStatus_Success);
  }
}, {
  args: ["u32", "ptr", "ptr", "ptr"],
  returns: "void",
  threadsafe: true
});
WGPU_CALLBACK_KEEPALIVE.push(bufferMapCallback);
var queueWorkDoneCallback = new JSCallback2((status, _message, userdata1, _userdata2) => {
  const key = Number(userdata1);
  const resolve4 = WORK_DONE_RESOLVERS.get(key);
  if (resolve4) {
    WORK_DONE_RESOLVERS.delete(key);
    resolve4(status === WGPUQueueWorkDoneStatus_Success);
  }
}, {
  args: ["u32", "ptr", "ptr", "ptr"],
  returns: "void",
  threadsafe: true
});
WGPU_CALLBACK_KEEPALIVE.push(queueWorkDoneCallback);
function toBigInt(value, fallback = 0n) {
  if (typeof value === "bigint")
    return value;
  if (typeof value === "number" && Number.isFinite(value)) {
    return BigInt(Math.trunc(value));
  }
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (/^(0x[0-9a-fA-F]+|\d+)$/.test(trimmed)) {
      return BigInt(trimmed);
    }
  }
  return fallback;
}
function writePtr(view, offset, value) {
  view.setBigUint64(offset, toBigInt(value ?? 0), true);
}
function writeU32(view, offset, value) {
  view.setUint32(offset, Number(value) >>> 0, true);
}
function writeU64(view, offset, value) {
  view.setBigUint64(offset, toBigInt(value), true);
}
function writeF32(view, offset, value) {
  view.setFloat32(offset, value, true);
}
function writeF64(view, offset, value) {
  view.setFloat64(offset, value, true);
}
function makeStringView(str) {
  if (!str) {
    return { ptr: 0, len: 0n, cstr: null };
  }
  const bytes = new TextEncoder().encode(str);
  return { ptr: ptr2(bytes), len: BigInt(bytes.byteLength), cstr: bytes };
}
function ptrOrNull(value) {
  return value.byteLength === 0 ? 0 : ptr2(value);
}
function makeSurfaceConfiguration(devicePtr, width, height, format, alphaMode, usage = WGPUTextureUsage_RenderAttachment) {
  const buffer = new ArrayBuffer(64);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, devicePtr);
  writeU32(view, 16, format);
  writeU32(view, 20, 0);
  writeU64(view, 24, usage);
  writeU32(view, 32, width);
  writeU32(view, 36, height);
  writeU64(view, 40, 0n);
  writePtr(view, 48, 0);
  writeU32(view, 56, alphaMode);
  writeU32(view, 60, WGPUPresentMode_Fifo);
  return { buffer, ptr: ptr2(buffer) };
}
function makeBufferDescriptor(size, usage, mappedAtCreation) {
  const buffer = new ArrayBuffer(48);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  writeU64(view, 24, usage);
  writeU64(view, 32, BigInt(size));
  writeU32(view, 40, mappedAtCreation ? 1 : 0);
  writeU32(view, 44, 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeTextureDescriptor(width, height, depthOrArrayLayers, format, usage, mipLevelCount = 1, sampleCount = 1, viewFormatsPtr = null, viewFormatCount = 0) {
  const buffer = new ArrayBuffer(80);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  writeU64(view, 24, usage);
  writeU32(view, 32, WGPUTextureDimension_2D);
  writeU32(view, 36, width);
  writeU32(view, 40, height);
  writeU32(view, 44, depthOrArrayLayers);
  writeU32(view, 48, format);
  writeU32(view, 52, mipLevelCount);
  writeU32(view, 56, sampleCount);
  writeU32(view, 60, 0);
  writeU64(view, 64, BigInt(viewFormatCount));
  writePtr(view, 72, viewFormatsPtr ?? 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeTextureViewDescriptor(options) {
  const buffer = new ArrayBuffer(64);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  writeU32(view, 24, options?.format ?? 0);
  writeU32(view, 28, options?.dimension ?? 0);
  writeU32(view, 32, options?.baseMipLevel ?? 0);
  writeU32(view, 36, options?.mipLevelCount ?? 4294967295);
  writeU32(view, 40, options?.baseArrayLayer ?? 0);
  writeU32(view, 44, options?.arrayLayerCount ?? 4294967295);
  writeU32(view, 48, options?.aspect ?? 0);
  writeU32(view, 52, 0);
  writeU64(view, 56, options?.usage ?? 0n);
  return { buffer, ptr: ptr2(buffer) };
}
function makeSamplerDescriptor(options) {
  const buffer = new ArrayBuffer(64);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  writeU32(view, 24, options?.addressModeU ?? WGPUAddressMode_ClampToEdge);
  writeU32(view, 28, options?.addressModeV ?? WGPUAddressMode_ClampToEdge);
  writeU32(view, 32, options?.addressModeW ?? WGPUAddressMode_ClampToEdge);
  writeU32(view, 36, options?.magFilter ?? WGPUFilterMode_Linear);
  writeU32(view, 40, options?.minFilter ?? WGPUFilterMode_Linear);
  writeU32(view, 44, options?.mipmapFilter ?? WGPUMipmapFilterMode_Linear);
  writeF32(view, 48, options?.lodMinClamp ?? 0);
  writeF32(view, 52, options?.lodMaxClamp ?? 32);
  writeU32(view, 56, options?.compare ?? 0);
  view.setUint16(60, options?.maxAnisotropy ?? 1, true);
  view.setUint16(62, 0, true);
  return { buffer, ptr: ptr2(buffer) };
}
function makeVertexAttribute(offset, shaderLocation, format) {
  const buffer = new ArrayBuffer(32);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU32(view, 8, format);
  writeU32(view, 12, 0);
  writeU64(view, 16, BigInt(offset));
  writeU32(view, 24, shaderLocation);
  writeU32(view, 28, 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeVertexBufferLayout(attributePtr, attributeCount, arrayStride, stepMode) {
  const buffer = new ArrayBuffer(40);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU32(view, 8, stepMode);
  writeU32(view, 12, 0);
  writeU64(view, 16, arrayStride);
  writeU64(view, 24, BigInt(attributeCount));
  writePtr(view, 32, attributePtr);
  return { buffer, ptr: ptr2(buffer) };
}
function makeVertexState(modulePtr, entryPoint, bufferLayoutPtr, bufferLayoutCount) {
  const buffer = new ArrayBuffer(64);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, modulePtr);
  writePtr(view, 16, entryPoint.ptr);
  writeU64(view, 24, entryPoint.len);
  writeU64(view, 32, 0n);
  writePtr(view, 40, 0);
  writeU64(view, 48, BigInt(bufferLayoutCount));
  writePtr(view, 56, bufferLayoutPtr);
  return { buffer, ptr: ptr2(buffer) };
}
function makeFragmentState(modulePtr, entryPoint, targetPtr, targetCount) {
  const buffer = new ArrayBuffer(64);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, modulePtr);
  writePtr(view, 16, entryPoint.ptr);
  writeU64(view, 24, entryPoint.len);
  writeU64(view, 32, 0n);
  writePtr(view, 40, 0);
  writeU64(view, 48, BigInt(targetCount));
  writePtr(view, 56, targetPtr);
  return { buffer, ptr: ptr2(buffer) };
}
function makeColorTargetState(format, blendPtr, writeMask = WGPUColorWriteMask_All) {
  const buffer = new ArrayBuffer(32);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU32(view, 8, format);
  writeU32(view, 12, 0);
  writePtr(view, 16, blendPtr ?? 0);
  writeU64(view, 24, BigInt(writeMask));
  return { buffer, ptr: ptr2(buffer) };
}
function makeBlendComponent(operation, srcFactor, dstFactor) {
  const buffer = new ArrayBuffer(12);
  const view = new DataView(buffer);
  writeU32(view, 0, operation);
  writeU32(view, 4, srcFactor);
  writeU32(view, 8, dstFactor);
  return { buffer, ptr: ptr2(buffer) };
}
function makeBlendState(color, alpha) {
  const buffer = new ArrayBuffer(24);
  new Uint8Array(buffer, 0, 12).set(new Uint8Array(color, 0, 12));
  new Uint8Array(buffer, 12, 12).set(new Uint8Array(alpha, 0, 12));
  return { buffer, ptr: ptr2(buffer) };
}
function makePrimitiveState(options) {
  const buffer = new ArrayBuffer(32);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU32(view, 8, options?.topology ?? WGPUPrimitiveTopology_TriangleList);
  writeU32(view, 12, options?.stripIndexFormat ?? 0);
  writeU32(view, 16, options?.frontFace ?? WGPUFrontFace_CCW);
  writeU32(view, 20, options?.cullMode ?? WGPUCullMode_None);
  writeU32(view, 24, options?.unclippedDepth ?? 0);
  writeU32(view, 28, 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeMultisampleState(options) {
  const buffer = new ArrayBuffer(24);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU32(view, 8, options?.count ?? 1);
  writeU32(view, 12, options?.mask ?? 4294967295);
  writeU32(view, 16, options?.alphaToCoverageEnabled ? 1 : 0);
  writeU32(view, 20, 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeDepthStencilState(options) {
  const buffer = new ArrayBuffer(72);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU32(view, 8, options?.format ?? 0);
  writeU32(view, 12, options?.depthWriteEnabled ? 1 : 0);
  writeU32(view, 16, options?.depthCompare ?? 0);
  writeU32(view, 20, 0);
  writeU32(view, 24, 0);
  writeU32(view, 28, 0);
  writeU32(view, 32, 0);
  writeU32(view, 36, 0);
  writeU32(view, 40, 0);
  writeU32(view, 44, 0);
  writeU32(view, 48, 0);
  writeU32(view, 52, options?.stencilReadMask ?? 4294967295);
  writeU32(view, 56, options?.stencilWriteMask ?? 4294967295);
  view.setInt32(60, options?.depthBias ?? 0, true);
  writeF32(view, 64, options?.depthBiasSlopeScale ?? 0);
  writeF32(view, 68, options?.depthBiasClamp ?? 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeRenderPipelineDescriptor(layoutPtr, vertexStateBuffer, primitiveStateBuffer, depthStencilPtr, multisampleBuffer, fragmentStatePtr) {
  const buffer = new ArrayBuffer(168);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  writePtr(view, 24, layoutPtr ?? 0);
  new Uint8Array(buffer, 32, 64).set(new Uint8Array(vertexStateBuffer, 0, 64));
  new Uint8Array(buffer, 96, 32).set(new Uint8Array(primitiveStateBuffer, 0, 32));
  writePtr(view, 128, depthStencilPtr ?? 0);
  new Uint8Array(buffer, 136, 24).set(new Uint8Array(multisampleBuffer, 0, 24));
  writePtr(view, 160, fragmentStatePtr ?? 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeProgrammableStageDescriptor(modulePtr, entryPoint) {
  const buffer = new ArrayBuffer(48);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, modulePtr);
  writePtr(view, 16, entryPoint.ptr);
  writeU64(view, 24, entryPoint.len);
  writeU64(view, 32, 0n);
  writePtr(view, 40, 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeComputePipelineDescriptor(layoutPtr, stageBuffer) {
  const buffer = new ArrayBuffer(80);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  writePtr(view, 24, layoutPtr ?? 0);
  new Uint8Array(buffer, 32, 48).set(new Uint8Array(stageBuffer, 0, 48));
  return { buffer, ptr: ptr2(buffer) };
}
function makeComputePassDescriptor() {
  const buffer = new ArrayBuffer(32);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  writePtr(view, 24, 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeBufferMapCallbackInfo(callbackPtr, userdata1, userdata2) {
  const buffer = new ArrayBuffer(40);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU32(view, 8, WGPUCallbackMode_AllowSpontaneous);
  writeU32(view, 12, 0);
  writePtr(view, 16, callbackPtr);
  writePtr(view, 24, userdata1);
  writePtr(view, 32, userdata2);
  return { buffer, ptr: ptr2(buffer) };
}
function makeQueueWorkDoneCallbackInfo(callbackPtr, userdata1, userdata2) {
  const buffer = new ArrayBuffer(40);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU32(view, 8, WGPUCallbackMode_AllowSpontaneous);
  writeU32(view, 12, 0);
  writePtr(view, 16, callbackPtr);
  writePtr(view, 24, userdata1);
  writePtr(view, 32, userdata2);
  return { buffer, ptr: ptr2(buffer) };
}
function makeBindGroupLayoutEntry(entry) {
  const buffer = new ArrayBuffer(120);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU32(view, 8, entry.binding);
  writeU32(view, 16, entry.visibility);
  writeU32(view, 24, entry.bindingArraySize ?? 0);
  writePtr(view, 32, 0);
  writeU32(view, 40, entry.buffer?.type ?? 0);
  writeU32(view, 44, entry.buffer?.hasDynamicOffset ? 1 : 0);
  writeU64(view, 48, entry.buffer?.minBindingSize ?? 0);
  writePtr(view, 56, 0);
  writeU32(view, 64, entry.sampler?.type ?? 0);
  writePtr(view, 72, 0);
  writeU32(view, 80, entry.texture?.sampleType ?? 0);
  writeU32(view, 84, entry.texture?.viewDimension ?? 0);
  writeU32(view, 88, entry.texture?.multisampled ? 1 : 0);
  writePtr(view, 96, 0);
  writeU32(view, 104, entry.storageTexture?.access ?? 0);
  writeU32(view, 108, entry.storageTexture?.format ?? 0);
  writeU32(view, 112, entry.storageTexture?.viewDimension ?? 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeBindGroupLayoutDescriptor(entriesPtr, count) {
  const buffer = new ArrayBuffer(40);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  writeU64(view, 24, BigInt(count));
  writePtr(view, 32, entriesPtr);
  return { buffer, ptr: ptr2(buffer) };
}
function makeBindGroupEntry(entry) {
  const buffer = new ArrayBuffer(56);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU32(view, 8, entry.binding);
  writeU32(view, 12, 0);
  writePtr(view, 16, entry.buffer ? entry.buffer.buffer.ptr : 0);
  writeU64(view, 24, BigInt(entry.buffer?.offset ?? 0));
  const sizeValue = entry.buffer?.size ?? 0xffffffffffffffffn;
  writeU64(view, 32, toBigInt(sizeValue, 0xffffffffffffffffn));
  writePtr(view, 40, entry.sampler ? entry.sampler.ptr : 0);
  writePtr(view, 48, entry.textureView ? entry.textureView.ptr : 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeBindGroupDescriptor(layoutPtr, entriesPtr, count) {
  const buffer = new ArrayBuffer(48);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  writePtr(view, 24, layoutPtr);
  writeU64(view, 32, BigInt(count));
  writePtr(view, 40, entriesPtr);
  return { buffer, ptr: ptr2(buffer) };
}
function makePipelineLayoutDescriptor(layoutsPtr, count) {
  const buffer = new ArrayBuffer(48);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  writeU64(view, 24, BigInt(count));
  writePtr(view, 32, layoutsPtr);
  writeU32(view, 40, 0);
  writeU32(view, 44, 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeCommandEncoderDescriptor() {
  const buffer = new ArrayBuffer(24);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  return { buffer, ptr: ptr2(buffer) };
}
function makeSurfaceTexture() {
  const buffer = new ArrayBuffer(24);
  return { buffer, view: new DataView(buffer), ptr: ptr2(buffer) };
}
function makeRenderPassColorAttachment(viewPtr, resolveTargetPtr, clear = { r: 0, g: 0, b: 0, a: 1 }, loadOp = WGPULoadOp_Clear, storeOp = WGPUStoreOp_Store) {
  const buffer = new ArrayBuffer(72);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, viewPtr);
  writeU32(view, 16, WGPU_DEPTH_SLICE_UNDEFINED);
  writeU32(view, 20, 0);
  writePtr(view, 24, resolveTargetPtr ?? 0);
  writeU32(view, 32, loadOp);
  writeU32(view, 36, storeOp);
  writeF64(view, 40, clear.r);
  writeF64(view, 48, clear.g);
  writeF64(view, 56, clear.b);
  writeF64(view, 64, clear.a);
  return { buffer, ptr: ptr2(buffer) };
}
function makeRenderPassDepthStencilAttachment(options) {
  const buffer = new ArrayBuffer(48);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, options.view);
  writeU32(view, 16, options.depthLoadOp);
  writeU32(view, 20, options.depthStoreOp);
  writeF32(view, 24, options.depthClearValue);
  writeU32(view, 28, options.depthReadOnly ? 1 : 0);
  writeU32(view, 32, options.stencilLoadOp);
  writeU32(view, 36, options.stencilStoreOp);
  writeU32(view, 40, options.stencilClearValue);
  writeU32(view, 44, options.stencilReadOnly ? 1 : 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeRenderPassDescriptor(colorAttachmentsPtr, colorAttachmentCount, depthStencilPtr) {
  const buffer = new ArrayBuffer(64);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  writeU64(view, 24, BigInt(colorAttachmentCount));
  writePtr(view, 32, colorAttachmentsPtr);
  writePtr(view, 40, depthStencilPtr ?? 0);
  writePtr(view, 48, 0);
  writePtr(view, 56, 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeSurfaceCapabilities() {
  const buffer = new ArrayBuffer(64);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU64(view, 8, 0n);
  writeU64(view, 16, 0n);
  writePtr(view, 24, 0);
  writeU64(view, 32, 0n);
  writePtr(view, 40, 0);
  writeU64(view, 48, 0n);
  writePtr(view, 56, 0);
  return { buffer, view, ptr: ptr2(buffer) };
}
function readU64(view, offset) {
  return Number(view.getBigUint64(offset, true));
}
function readPtr(view, offset) {
  const val = view.getBigUint64(offset, true);
  return val === 0n ? 0 : Number(val);
}
function pickSurfaceFormatAlpha(capsView, preferredFormat) {
  const formatCount = readU64(capsView, 16);
  const formatPtr = readPtr(capsView, 24);
  let format = preferredFormat;
  if (formatCount && formatPtr) {
    const formats = new Uint32Array(toArrayBuffer2(formatPtr, 0, formatCount * 4));
    if (formats.length) {
      format = formats[0];
    }
  }
  const alphaCount = readU64(capsView, 48);
  const alphaPtr = readPtr(capsView, 56);
  let alphaMode = WGPUCompositeAlphaMode_Opaque;
  const alphaModes = [];
  if (alphaCount && alphaPtr) {
    const alphas = new Uint32Array(toArrayBuffer2(alphaPtr, 0, alphaCount * 4));
    if (alphas.length) {
      alphaModes.push(...alphas);
      alphaMode = alphas[0];
    }
  }
  return { format, alphaMode, alphaModes };
}

class GPUTexture {
  ptr;
  format;
  _views = new Set;
  _presentationContext;
  constructor(ptr3, format, presentationContext) {
    this.ptr = ptr3;
    this.format = format;
    this._presentationContext = presentationContext;
  }
  createView(descriptor) {
    if (!this.ptr)
      throw new Error("WebGPU texture has been released");
    let descPtr = 0;
    let descBuffer;
    if (descriptor) {
      let format = mapTextureFormat(descriptor.format) ?? 0;
      const baseFormat = this.format ?? WGPUNative.symbols.wgpuTextureGetFormat(this.ptr);
      if (isDepthFormat(baseFormat) && !isDepthFormat(format)) {
        format = 0;
      }
      const desc = makeTextureViewDescriptor({
        format,
        dimension: mapTextureViewDimension(descriptor.dimension) ?? 0,
        baseMipLevel: descriptor.baseMipLevel ?? 0,
        mipLevelCount: descriptor.mipLevelCount ?? 4294967295,
        baseArrayLayer: descriptor.baseArrayLayer ?? 0,
        arrayLayerCount: descriptor.arrayLayerCount ?? 4294967295,
        aspect: mapTextureAspect(descriptor.aspect) ?? 0,
        usage: toBigInt(descriptor.usage ?? 0)
      });
      descBuffer = desc.buffer;
      descPtr = desc.ptr;
    }
    const view = WGPUNative.symbols.wgpuTextureCreateView(this.ptr, descPtr);
    if (!view)
      throw new Error("Failed to create WebGPU texture view");
    const textureView = new GPUTextureView(Number(view), this.format, () => this._views.delete(textureView), this._presentationContext);
    this._views.add(textureView);
    return textureView;
  }
  destroy() {
    if (!this.ptr)
      return;
    const texturePtr = this.ptr;
    this.ptr = 0;
    try {
      WGPUNative.symbols.wgpuTextureDestroy(texturePtr);
    } finally {
      try {
        this._releaseViews();
      } finally {
        WGPUNative.symbols.wgpuTextureRelease(texturePtr);
      }
    }
  }
  _releaseReference() {
    if (!this.ptr)
      return;
    const texturePtr = this.ptr;
    this.ptr = 0;
    try {
      this._releaseViews();
    } finally {
      WGPUNative.symbols.wgpuTextureRelease(texturePtr);
    }
  }
  _releaseViews() {
    for (const view of [...this._views]) {
      try {
        view._releaseReference();
      } catch {}
    }
    this._views.clear();
  }
}

class GPUTextureView {
  ptr;
  format;
  _presentationContext;
  _onRelease;
  constructor(ptr3, format, onRelease, presentationContext) {
    this.ptr = ptr3;
    this.format = format;
    this._onRelease = onRelease;
    this._presentationContext = presentationContext;
  }
  _releaseReference() {
    if (!this.ptr)
      return;
    const viewPtr = this.ptr;
    this.ptr = 0;
    this._onRelease?.();
    this._onRelease = undefined;
    WGPUNative.symbols.wgpuTextureViewRelease(viewPtr);
  }
  release() {
    this._releaseReference();
  }
}

class GPUQueue {
  ptr;
  _device;
  constructor(ptr3) {
    this.ptr = ptr3;
  }
  submit(commandBuffers) {
    if (!this.ptr || !this._device?.ptr) {
      throw new Error("WebGPU queue belongs to a destroyed device");
    }
    const buffer = new BigUint64Array(commandBuffers.length);
    const presentationContexts = new Set;
    for (let i = 0;i < commandBuffers.length; i += 1) {
      if (!commandBuffers[i].ptr) {
        throw new Error("WebGPU command buffer has already been submitted");
      }
      buffer[i] = BigInt(commandBuffers[i].ptr);
    }
    for (const commandBuffer of commandBuffers) {
      for (const context of commandBuffer._consumePresentationContexts()) {
        presentationContexts.add(context);
      }
    }
    try {
      WGPUNative.symbols.wgpuQueueSubmit(this.ptr, BigInt(commandBuffers.length), ptrOrNull(buffer));
    } finally {
      for (const commandBuffer of commandBuffers) {
        try {
          commandBuffer._releaseReference();
        } catch {}
      }
    }
    for (const context of presentationContexts) {
      PRESENTATION_STATE.presentPendingSurface(this, context, (surface) => surface._presentNative());
    }
  }
  writeBuffer(buffer, offset, data) {
    if (!this.ptr || !this._device?.ptr) {
      throw new Error("WebGPU queue belongs to a destroyed device");
    }
    WGPUNative.symbols.wgpuQueueWriteBuffer(this.ptr, buffer.ptr, BigInt(offset), ptrOrNull(data), data.byteLength);
  }
  writeTexture(destination, data, dataLayout, size) {
    if (!this.ptr || !this._device?.ptr) {
      throw new Error("WebGPU queue belongs to a destroyed device");
    }
    if (!data || data.byteLength === 0)
      return;
    let bytesPerPixel = bytesPerPixelForFormat(destination.texture.format);
    let width = Number.isFinite(size.width) && size.width > 0 ? size.width : Math.max(1, Math.floor((dataLayout.bytesPerRow ?? data.byteLength) / bytesPerPixel));
    let height = Number.isFinite(size.height) && size.height > 0 ? size.height : Math.max(1, dataLayout.rowsPerImage ?? 1);
    const layers = size.depthOrArrayLayers ?? 1;
    if (width <= 0 || height <= 0 || layers <= 0)
      return;
    const inferredBpp = Math.floor(data.byteLength / Math.max(1, width * height * layers));
    if (inferredBpp > bytesPerPixel) {
      bytesPerPixel = inferredBpp;
    }
    const exactRGBABytes = width * height * layers * 4;
    if (data.byteLength === exactRGBABytes) {
      bytesPerPixel = 4;
    }
    let minBytesPerRow = Math.max(1, width * bytesPerPixel);
    const minExpectedSize = minBytesPerRow * height * layers;
    if (data.byteLength > minExpectedSize && height > 0) {
      const widthFromData = Math.floor(data.byteLength / Math.max(1, height * layers * bytesPerPixel));
      if (widthFromData > width) {
        width = widthFromData;
        minBytesPerRow = Math.max(1, width * bytesPerPixel);
      }
    }
    let bytesPerRow = dataLayout.bytesPerRow ?? minBytesPerRow;
    if (bytesPerRow < minBytesPerRow)
      bytesPerRow = minBytesPerRow;
    const derivedRowBytes = Math.ceil(data.byteLength / Math.max(1, height * layers));
    if (bytesPerRow < derivedRowBytes) {
      bytesPerRow = derivedRowBytes;
    }
    let rowsPerImage = dataLayout.rowsPerImage ?? height;
    if (rowsPerImage === 0)
      rowsPerImage = height;
    let writeData = data;
    const needsPadding = bytesPerRow % 256 !== 0;
    if (needsPadding) {
      const aligned = alignTo(bytesPerRow, 256);
      const srcStride = Math.max(minBytesPerRow, dataLayout.bytesPerRow ?? minBytesPerRow);
      writeData = repackTextureData(data, srcStride, aligned, minBytesPerRow, height, rowsPerImage, layers);
      bytesPerRow = aligned;
    }
    const texInfo = makeTexelCopyTextureInfo(destination.texture.ptr, destination.mipLevel ?? 0, destination.origin ?? {});
    const layout = makeTexelCopyBufferLayout(dataLayout.offset ?? 0, bytesPerRow, rowsPerImage);
    const extent = makeExtent3D(width, height, layers);
    WGPUNative.symbols.wgpuQueueWriteTexture(this.ptr, texInfo.ptr, ptr2(writeData), writeData.byteLength, layout.ptr, extent.ptr);
    texInfo.buffer;
    layout.buffer;
    extent.buffer;
  }
  onSubmittedWorkDone() {
    if (!this.ptr || !this._device?.ptr)
      return Promise.resolve(false);
    const queuePtr = this.ptr;
    const callbackPtr = queueWorkDoneCallback.ptr ?? queueWorkDoneCallback;
    const info = makeQueueWorkDoneCallbackInfo(Number(callbackPtr), queuePtr, 0);
    return new Promise((resolve4) => {
      let done = false;
      const finish = (ok) => {
        if (done)
          return;
        done = true;
        WORK_DONE_RESOLVERS.delete(queuePtr);
        resolve4(ok);
      };
      WORK_DONE_RESOLVERS.set(queuePtr, finish);
      try {
        WGPUBridge.queueOnSubmittedWorkDone(queuePtr, info.ptr);
        info.buffer;
      } catch {
        finish(false);
        return;
      }
      const start = Date.now();
      const poll = () => {
        if (done)
          return;
        if (this.ptr !== queuePtr || !this._device?.ptr) {
          finish(false);
          return;
        }
        try {
          if (this._device?.instancePtr) {
            WGPUNative.symbols.wgpuInstanceProcessEvents(this._device.instancePtr);
          }
          WGPUNative.symbols.wgpuDeviceTick(this._device?.ptr ?? 0);
        } catch {}
        if (Date.now() - start > 5000) {
          finish(false);
          return;
        }
        setTimeout(poll, 5);
      };
      setTimeout(poll, 5);
    });
  }
  _releaseReference(releaseSurfaceContexts = false) {
    const configuredContexts = PRESENTATION_STATE.detachQueue(this);
    for (const context of configuredContexts) {
      if (releaseSurfaceContexts && context._releaseForDeviceDestroy(this)) {
        continue;
      }
      context._onQueueReleased(this);
    }
    if (!this.ptr)
      return;
    const queuePtr = this.ptr;
    this.ptr = 0;
    WORK_DONE_RESOLVERS.get(queuePtr)?.(false);
    WORK_DONE_RESOLVERS.delete(queuePtr);
    WGPUNative.symbols.wgpuQueueRelease(queuePtr);
  }
}

class GPUDevice {
  ptr;
  queue;
  features = new Set;
  limits = {};
  _uncapturedErrorListeners = [];
  instancePtr = null;
  constructor(ptr3, instancePtr) {
    if (!ptr3) {
      throw new Error("Failed to create WGPU device");
    }
    this.ptr = ptr3;
    this.instancePtr = instancePtr ?? null;
    this.queue = new GPUQueue(WGPUNative.symbols.wgpuDeviceGetQueue(ptr3));
    if (!this.queue.ptr) {
      WGPUNative.symbols.wgpuDeviceRelease(ptr3);
      throw new Error("Failed to get WGPU device queue");
    }
    this.queue._device = this;
  }
  destroy() {
    if (!this.ptr)
      return;
    const devicePtr = this.ptr;
    this.ptr = 0;
    this.instancePtr = null;
    try {
      this.queue._releaseReference(process.platform === "linux");
    } catch {}
    try {
      WGPUNative.symbols.wgpuDeviceDestroy(devicePtr);
    } catch {}
    try {
      WGPUNative.symbols.wgpuDeviceRelease(devicePtr);
    } catch {}
  }
  _invalidateInstance(instancePtr) {
    if (this.instancePtr === instancePtr)
      this.instancePtr = null;
  }
  _assertLive() {
    if (!this.ptr)
      throw new Error("WebGPU device has been destroyed");
  }
  createBuffer(descriptor) {
    this._assertLive();
    let usage = toBigInt(descriptor.usage ?? 0);
    const desc = makeBufferDescriptor(descriptor.size, usage, !!descriptor.mappedAtCreation);
    const bufferPtr = WGPUNative.symbols.wgpuDeviceCreateBuffer(this.ptr, desc.ptr);
    desc.buffer;
    return new GPUBuffer(bufferPtr, descriptor.size, usage, this, !!descriptor.mappedAtCreation);
  }
  createTexture(descriptor) {
    this._assertLive();
    const mappedFormat = mapTextureFormat(descriptor.format) ?? WGPUTextureFormat_BGRA8Unorm;
    const rawSample = Number(descriptor.sampleCount ?? 1);
    let sampleCount = Number.isFinite(rawSample) ? rawSample : 1;
    if (sampleCount > 1 && isIntegerFormat(mappedFormat)) {
      sampleCount = 1;
    }
    let viewFormatsPtr = null;
    let viewFormatCount = 0;
    let viewFormatsArray;
    if (descriptor.viewFormats && descriptor.viewFormats.length) {
      const arr = new Uint32Array(descriptor.viewFormats.length);
      descriptor.viewFormats.forEach((f, i) => {
        arr[i] = mapTextureFormat(f) ?? 0;
      });
      viewFormatsArray = arr;
      viewFormatsPtr = ptr2(arr);
      viewFormatCount = descriptor.viewFormats.length;
    }
    const desc = makeTextureDescriptor(descriptor.size.width, descriptor.size.height, descriptor.size.depthOrArrayLayers ?? 1, mappedFormat, toBigInt(descriptor.usage ?? 0), descriptor.mipLevelCount ?? 1, sampleCount, viewFormatsPtr, viewFormatCount);
    const texPtr = WGPUNative.symbols.wgpuDeviceCreateTexture(this.ptr, desc.ptr);
    desc.buffer;
    return new GPUTexture(texPtr, mappedFormat);
  }
  createSampler(descriptor) {
    this._assertLive();
    const desc = makeSamplerDescriptor({
      addressModeU: mapAddressMode(descriptor?.addressModeU),
      addressModeV: mapAddressMode(descriptor?.addressModeV),
      addressModeW: mapAddressMode(descriptor?.addressModeW),
      magFilter: mapFilterMode(descriptor?.magFilter),
      minFilter: mapFilterMode(descriptor?.minFilter),
      mipmapFilter: mapMipmapFilterMode(descriptor?.mipmapFilter),
      lodMinClamp: descriptor?.lodMinClamp,
      lodMaxClamp: descriptor?.lodMaxClamp,
      compare: mapCompareFunction(descriptor?.compare),
      maxAnisotropy: descriptor?.maxAnisotropy
    });
    const samplerPtr = WGPUNative.symbols.wgpuDeviceCreateSampler(this.ptr, desc.ptr);
    desc.buffer;
    return new GPUSampler(samplerPtr);
  }
  createBindGroupLayout(descriptor) {
    this._assertLive();
    const entries = descriptor.entries.map((entry) => {
      const hasBindingKind = !!entry.buffer || !!entry.sampler || !!entry.texture || !!entry.storageTexture;
      const normalized = hasBindingKind ? entry : {
        ...entry,
        buffer: { type: "uniform" }
      };
      const bindingEntry = makeBindGroupLayoutEntry({
        binding: normalized.binding ?? 0,
        visibility: mapShaderStage(normalized.visibility) ?? 0,
        bindingArraySize: normalized.bindingArraySize ?? 0,
        buffer: normalized.buffer ? {
          type: mapBufferBindingType(normalized.buffer.type),
          hasDynamicOffset: !!normalized.buffer.hasDynamicOffset,
          minBindingSize: normalized.buffer.minBindingSize ?? 0
        } : undefined,
        sampler: normalized.sampler ? { type: mapSamplerBindingType(normalized.sampler.type) } : undefined,
        texture: normalized.texture ? {
          sampleType: mapTextureSampleType(normalized.texture.sampleType),
          viewDimension: mapTextureViewDimension(normalized.texture.viewDimension),
          multisampled: !!normalized.texture.multisampled
        } : undefined,
        storageTexture: normalized.storageTexture ? {
          access: mapStorageTextureAccess(normalized.storageTexture.access),
          format: mapTextureFormat(normalized.storageTexture.format),
          viewDimension: mapTextureViewDimension(normalized.storageTexture.viewDimension)
        } : undefined
      });
      return bindingEntry;
    });
    const entryBuf = new ArrayBuffer(entries.length * 120);
    entries.forEach((entry, i) => {
      new Uint8Array(entryBuf, i * 120, 120).set(new Uint8Array(entry.buffer));
    });
    const entryPtr = ptrOrNull(entryBuf);
    const desc = makeBindGroupLayoutDescriptor(entryPtr, entries.length);
    const layoutPtr = WGPUNative.symbols.wgpuDeviceCreateBindGroupLayout(this.ptr, desc.ptr);
    desc.buffer;
    return new GPUBindGroupLayout(layoutPtr);
  }
  createBindGroup(descriptor) {
    this._assertLive();
    const entries = descriptor.entries.map((entry) => {
      const bufferResource = entry.resource?.buffer || entry.resource instanceof GPUBuffer ? entry.resource : entry.buffer;
      if (bufferResource) {
        const buffer = bufferResource.buffer ?? bufferResource;
        return makeBindGroupEntry({
          binding: entry.binding ?? 0,
          buffer: {
            buffer,
            offset: bufferResource.offset ?? 0,
            size: bufferResource.size ?? 0xffffffffffffffffn
          }
        });
      }
      const sampler = entry.resource instanceof GPUSampler ? entry.resource : entry.resource?.sampler ?? entry.sampler;
      if (sampler) {
        return makeBindGroupEntry({
          binding: entry.binding ?? 0,
          sampler
        });
      }
      const textureView = entry.resource instanceof GPUTextureView ? entry.resource : entry.resource?.textureView ?? entry.textureView;
      if (textureView) {
        return makeBindGroupEntry({
          binding: entry.binding ?? 0,
          textureView
        });
      }
      return makeBindGroupEntry({ binding: entry.binding ?? 0 });
    });
    const entryBuf = new ArrayBuffer(entries.length * 56);
    entries.forEach((entry, i) => {
      new Uint8Array(entryBuf, i * 56, 56).set(new Uint8Array(entry.buffer));
    });
    const entryPtr = ptrOrNull(entryBuf);
    const desc = makeBindGroupDescriptor(descriptor.layout.ptr, entryPtr, entries.length);
    const bindGroupPtr = WGPUNative.symbols.wgpuDeviceCreateBindGroup(this.ptr, desc.ptr);
    desc.buffer;
    return new GPUBindGroup(bindGroupPtr);
  }
  createPipelineLayout(descriptor) {
    this._assertLive();
    const layouts = new BigUint64Array(descriptor.bindGroupLayouts.length);
    for (let i = 0;i < layouts.length; i += 1) {
      layouts[i] = BigInt(descriptor.bindGroupLayouts[i].ptr);
    }
    const desc = makePipelineLayoutDescriptor(ptrOrNull(layouts), layouts.length);
    const layoutPtr = WGPUNative.symbols.wgpuDeviceCreatePipelineLayout(this.ptr, desc.ptr);
    desc.buffer;
    return new GPUPipelineLayout(layoutPtr);
  }
  createShaderModule(descriptor) {
    this._assertLive();
    const code = new TextEncoder().encode(descriptor.code + "\x00");
    const codeBuf = new Uint8Array(code);
    const codePtr = ptr2(codeBuf);
    const source = makeShaderSourceWGSL(codePtr, WGPU_STRLEN);
    const desc = makeShaderModuleDescriptor(source.ptr);
    const modulePtr = WGPUNative.symbols.wgpuDeviceCreateShaderModule(this.ptr, desc.ptr);
    source.buffer;
    desc.buffer;
    return new GPUShaderModule(modulePtr);
  }
  createRenderPipeline(descriptor) {
    this._assertLive();
    const ffiKeepalive = [];
    const vertexModule = descriptor.vertex.module;
    const vertexEntry = makeStringView(descriptor.vertex.entryPoint ?? "main");
    ffiKeepalive.push(vertexEntry);
    const vertexBuffers = descriptor.vertex.buffers ?? [];
    const vertexLayouts = [];
    const vertexLayoutPtrs = [];
    for (const buf of vertexBuffers) {
      const attrs = buf.attributes ?? [];
      const attrBuf = new ArrayBuffer(attrs.length * 32);
      attrs.forEach((attr, idx) => {
        const format = mapVertexFormat(attr.format);
        const attrStruct = makeVertexAttribute(attr.offset ?? 0, attr.shaderLocation ?? 0, format);
        new Uint8Array(attrBuf, idx * 32, 32).set(new Uint8Array(attrStruct.buffer));
      });
      const attrPtr = ptrOrNull(attrBuf);
      ffiKeepalive.push(attrBuf);
      const layout = makeVertexBufferLayout(attrPtr, attrs.length, BigInt(buf.arrayStride ?? 0), mapVertexStepMode(buf.stepMode));
      ffiKeepalive.push(layout.buffer);
      vertexLayouts.push(layout.buffer);
      vertexLayoutPtrs.push(layout.ptr);
    }
    const vertexLayoutsBuf = new ArrayBuffer(vertexLayouts.length * 40);
    vertexLayouts.forEach((layoutBuf, i) => {
      new Uint8Array(vertexLayoutsBuf, i * 40, 40).set(new Uint8Array(layoutBuf));
    });
    const vertexLayoutsPtr = ptrOrNull(vertexLayoutsBuf);
    ffiKeepalive.push(vertexLayoutsBuf);
    const vertexState = makeVertexState(vertexModule.ptr, { ptr: vertexEntry.ptr, len: vertexEntry.len }, vertexLayoutsPtr, vertexLayouts.length);
    ffiKeepalive.push(vertexState.buffer);
    let fragmentStatePtr = null;
    if (descriptor.fragment) {
      const fragModule = descriptor.fragment.module;
      const fragEntry = makeStringView(descriptor.fragment.entryPoint ?? "main");
      ffiKeepalive.push(fragEntry);
      const targets = descriptor.fragment.targets ?? [];
      const targetBuf = new ArrayBuffer(targets.length * 32);
      ffiKeepalive.push(targetBuf);
      targets.forEach((t, i) => {
        let blendPtr = null;
        if (t.blend) {
          const colorComp = makeBlendComponent(mapBlendOperation(t.blend.color?.operation), mapBlendFactor(t.blend.color?.srcFactor), mapBlendFactor(t.blend.color?.dstFactor));
          const alphaComp = makeBlendComponent(mapBlendOperation(t.blend.alpha?.operation), mapBlendFactor(t.blend.alpha?.srcFactor), mapBlendFactor(t.blend.alpha?.dstFactor));
          const blend = makeBlendState(colorComp.buffer, alphaComp.buffer);
          ffiKeepalive.push(colorComp.buffer, alphaComp.buffer, blend.buffer);
          blendPtr = blend.ptr;
        }
        const target = makeColorTargetState(mapTextureFormat(t.format) ?? WGPUTextureFormat_BGRA8Unorm, blendPtr, t.writeMask ?? WGPUColorWriteMask_All);
        new Uint8Array(targetBuf, i * 32, 32).set(new Uint8Array(target.buffer));
      });
      const targetPtr = ptrOrNull(targetBuf);
      const fragState = makeFragmentState(fragModule.ptr, { ptr: fragEntry.ptr, len: fragEntry.len }, targetPtr, targets.length);
      ffiKeepalive.push(fragState.buffer);
      fragmentStatePtr = fragState.ptr;
    }
    const primitive = makePrimitiveState({
      topology: mapPrimitiveTopology(descriptor.primitive?.topology),
      stripIndexFormat: mapIndexFormat(descriptor.primitive?.stripIndexFormat),
      frontFace: mapFrontFace(descriptor.primitive?.frontFace),
      cullMode: mapCullMode(descriptor.primitive?.cullMode),
      unclippedDepth: descriptor.primitive?.unclippedDepth ? 1 : 0
    });
    ffiKeepalive.push(primitive.buffer);
    let depthStencilPtr = null;
    if (descriptor.depthStencil) {
      const depth = makeDepthStencilState({
        format: mapTextureFormat(descriptor.depthStencil.format) ?? WGPUTextureFormat_Depth24Plus,
        depthWriteEnabled: !!descriptor.depthStencil.depthWriteEnabled,
        depthCompare: mapCompareFunction(descriptor.depthStencil.depthCompare),
        stencilReadMask: descriptor.depthStencil.stencilReadMask ?? 4294967295,
        stencilWriteMask: descriptor.depthStencil.stencilWriteMask ?? 4294967295,
        depthBias: descriptor.depthStencil.depthBias ?? 0,
        depthBiasSlopeScale: descriptor.depthStencil.depthBiasSlopeScale ?? 0,
        depthBiasClamp: descriptor.depthStencil.depthBiasClamp ?? 0
      });
      ffiKeepalive.push(depth.buffer);
      depthStencilPtr = depth.ptr;
    }
    const multisample = makeMultisampleState({
      count: descriptor.multisample?.count ?? 1,
      mask: descriptor.multisample?.mask ?? 4294967295,
      alphaToCoverageEnabled: !!descriptor.multisample?.alphaToCoverageEnabled
    });
    ffiKeepalive.push(multisample.buffer);
    const pipelineDesc = makeRenderPipelineDescriptor(descriptor.layout && descriptor.layout !== "auto" ? descriptor.layout.ptr : null, vertexState.buffer, primitive.buffer, depthStencilPtr, multisample.buffer, fragmentStatePtr);
    ffiKeepalive.push(pipelineDesc.buffer);
    const pipelinePtr = WGPUNative.symbols.wgpuDeviceCreateRenderPipeline(this.ptr, pipelineDesc.ptr);
    return new GPURenderPipeline(pipelinePtr);
  }
  createComputePipeline(descriptor) {
    this._assertLive();
    const ffiKeepalive = [];
    const module = descriptor.compute.module;
    const entry = makeStringView(descriptor.compute.entryPoint ?? "main");
    ffiKeepalive.push(entry);
    const stage = makeProgrammableStageDescriptor(module.ptr, { ptr: entry.ptr, len: entry.len });
    ffiKeepalive.push(stage.buffer);
    const pipelineDesc = makeComputePipelineDescriptor(descriptor.layout && descriptor.layout !== "auto" ? descriptor.layout.ptr : null, stage.buffer);
    ffiKeepalive.push(pipelineDesc.buffer);
    const pipelinePtr = WGPUNative.symbols.wgpuDeviceCreateComputePipeline(this.ptr, pipelineDesc.ptr);
    return new GPUComputePipeline(pipelinePtr);
  }
  createCommandEncoder() {
    this._assertLive();
    const desc = makeCommandEncoderDescriptor();
    const encoderPtr = WGPUNative.symbols.wgpuDeviceCreateCommandEncoder(this.ptr, desc.ptr);
    desc.buffer;
    return new GPUCommandEncoder(encoderPtr, this);
  }
  addEventListener(type, handler) {
    if (type !== "uncapturederror")
      return;
    this._uncapturedErrorListeners.push(handler);
  }
  pushErrorScope(_filter) {
    return;
  }
  popErrorScope() {
    return Promise.resolve(null);
  }
}

class GPUBuffer {
  ptr;
  size;
  usage;
  _device;
  _mapped;
  constructor(ptr3, size, usage, device, mapped = false) {
    this.ptr = ptr3;
    this.size = size;
    this.usage = usage;
    this._device = device;
    this._mapped = mapped;
  }
  _assertLive() {
    if (!this.ptr || !this._device.ptr) {
      throw new Error("WebGPU buffer has been destroyed");
    }
  }
  getMappedRange(_offset = 0, _size) {
    this._assertLive();
    if (!this._mapped) {
      return new ArrayBuffer(0);
    }
    const size = Math.max(0, _size ?? this.size - _offset);
    const mapped = WGPUNative.symbols.wgpuBufferGetMappedRange(this.ptr, BigInt(_offset), BigInt(size));
    if (!mapped) {
      return new ArrayBuffer(0);
    }
    return toArrayBuffer2(mapped, 0, size);
  }
  mapAsync(mode, offset = 0, size) {
    this._assertLive();
    const bufferPtr = this.ptr;
    const mapMode = mode ?? ((this.usage & WGPUBufferUsage_MapRead) !== 0n ? Number(WGPUMapMode_Read) : Number(WGPUMapMode_Write));
    const mapSize = size ?? this.size - offset;
    const callbackPtr = bufferMapCallback.ptr ?? bufferMapCallback;
    const info = makeBufferMapCallbackInfo(Number(callbackPtr), bufferPtr, 0);
    return new Promise((resolve4) => {
      let done = false;
      const finish = (mapped) => {
        if (done)
          return;
        done = true;
        MAP_ASYNC_RESOLVERS.delete(bufferPtr);
        if (mapped)
          this._mapped = true;
        resolve4(mapped);
      };
      MAP_ASYNC_RESOLVERS.set(bufferPtr, finish);
      try {
        WGPUBridge.bufferMapAsync(bufferPtr, BigInt(mapMode), BigInt(offset), BigInt(mapSize), info.ptr);
        info.buffer;
      } catch {
        finish(false);
        return;
      }
      const start = Date.now();
      const poll = () => {
        if (done)
          return;
        if (this.ptr !== bufferPtr || !this._device.ptr) {
          finish(false);
          return;
        }
        try {
          if (this._device.instancePtr) {
            WGPUNative.symbols.wgpuInstanceProcessEvents(this._device.instancePtr);
          }
          WGPUNative.symbols.wgpuDeviceTick(this._device.ptr);
        } catch {}
        const state = WGPUNative.symbols.wgpuBufferGetMapState(bufferPtr);
        if (state === WGPUBufferMapState_Mapped) {
          finish(true);
          return;
        }
        if (Date.now() - start > 2000) {
          finish(false);
          return;
        }
        setTimeout(poll, 5);
      };
      setTimeout(poll, 5);
    });
  }
  unmap() {
    this._assertLive();
    WGPUNative.symbols.wgpuBufferUnmap(this.ptr);
    this._mapped = false;
  }
  readSync(offset = 0, size, timeoutNs = 2000000000) {
    this._assertLive();
    if (!this._device.instancePtr)
      return null;
    const readSize = Math.max(0, size ?? this.size - offset);
    const out = new ArrayBuffer(readSize);
    const ok = WGPUBridge.bufferReadSyncInto(this._device.instancePtr, this.ptr, BigInt(offset), BigInt(readSize), BigInt(timeoutNs), ptr2(out));
    if (!ok)
      return null;
    return out;
  }
  readbackAsync(dst, offset = 0, size, timeoutMs = 2000) {
    this._assertLive();
    const readSize = Math.max(0, size ?? dst.byteLength);
    const jobPtr = WGPUBridge.bufferReadbackBegin(this.ptr, BigInt(offset), BigInt(readSize), ptr2(dst));
    if (!jobPtr)
      return Promise.resolve(0);
    return new Promise((resolve4) => {
      const start = Date.now();
      const poll = () => {
        if (!this._device.ptr) {
          WGPUBridge.bufferReadbackFree(jobPtr);
          resolve4(2);
          return;
        }
        try {
          if (this._device.instancePtr) {
            WGPUNative.symbols.wgpuInstanceProcessEvents(this._device.instancePtr);
          }
          WGPUNative.symbols.wgpuDeviceTick(this._device.ptr);
        } catch {}
        const status = WGPUBridge.bufferReadbackStatus(jobPtr);
        if (status === 1) {
          WGPUBridge.bufferReadbackFree(jobPtr);
          resolve4(1);
          return;
        }
        if (status === 2 || status === 3 || Date.now() - start > timeoutMs) {
          WGPUBridge.bufferReadbackFree(jobPtr);
          resolve4(status === 0 ? 2 : status);
          return;
        }
        setTimeout(poll, 5);
      };
      setTimeout(poll, 5);
    });
  }
  destroy() {
    if (!this.ptr)
      return;
    const bufferPtr = this.ptr;
    this.ptr = 0;
    MAP_ASYNC_RESOLVERS.get(bufferPtr)?.(false);
    MAP_ASYNC_RESOLVERS.delete(bufferPtr);
    try {
      WGPUNative.symbols.wgpuBufferDestroy(bufferPtr);
    } finally {
      WGPUNative.symbols.wgpuBufferRelease(bufferPtr);
    }
  }
}

class GPUSampler {
  ptr;
  constructor(ptr3) {
    this.ptr = ptr3;
  }
  release() {
    if (!this.ptr)
      return;
    const samplerPtr = this.ptr;
    this.ptr = 0;
    WGPUNative.symbols.wgpuSamplerRelease(samplerPtr);
  }
}

class GPUBindGroupLayout {
  ptr;
  constructor(ptr3) {
    this.ptr = ptr3;
  }
  release() {
    if (!this.ptr)
      return;
    const layoutPtr = this.ptr;
    this.ptr = 0;
    WGPUNative.symbols.wgpuBindGroupLayoutRelease(layoutPtr);
  }
}

class GPUBindGroup {
  ptr;
  constructor(ptr3) {
    this.ptr = ptr3;
  }
  release() {
    if (!this.ptr)
      return;
    const bindGroupPtr = this.ptr;
    this.ptr = 0;
    WGPUNative.symbols.wgpuBindGroupRelease(bindGroupPtr);
  }
}

class GPUPipelineLayout {
  ptr;
  constructor(ptr3) {
    this.ptr = ptr3;
  }
  release() {
    if (!this.ptr)
      return;
    const layoutPtr = this.ptr;
    this.ptr = 0;
    WGPUNative.symbols.wgpuPipelineLayoutRelease(layoutPtr);
  }
}

class GPUShaderModule {
  ptr;
  constructor(ptr3) {
    this.ptr = ptr3;
  }
  release() {
    if (!this.ptr)
      return;
    const modulePtr = this.ptr;
    this.ptr = 0;
    WGPUNative.symbols.wgpuShaderModuleRelease(modulePtr);
  }
}

class GPURenderPipeline {
  ptr;
  constructor(ptr3) {
    this.ptr = ptr3;
  }
  getBindGroupLayout(index) {
    if (!this.ptr)
      throw new Error("WebGPU render pipeline has been released");
    const layoutPtr = WGPUNative.symbols.wgpuRenderPipelineGetBindGroupLayout(this.ptr, index);
    return new GPUBindGroupLayout(layoutPtr);
  }
  release() {
    if (!this.ptr)
      return;
    const pipelinePtr = this.ptr;
    this.ptr = 0;
    WGPUNative.symbols.wgpuRenderPipelineRelease(pipelinePtr);
  }
}

class GPUComputePipeline {
  ptr;
  constructor(ptr3) {
    this.ptr = ptr3;
  }
  getBindGroupLayout(index) {
    if (!this.ptr)
      throw new Error("WebGPU compute pipeline has been released");
    const layoutPtr = WGPUNative.symbols.wgpuComputePipelineGetBindGroupLayout(this.ptr, index);
    return new GPUBindGroupLayout(layoutPtr);
  }
  release() {
    if (!this.ptr)
      return;
    const pipelinePtr = this.ptr;
    this.ptr = 0;
    WGPUNative.symbols.wgpuComputePipelineRelease(pipelinePtr);
  }
}

class GPUCommandBuffer {
  ptr;
  _presentationContexts;
  constructor(ptr3, presentationContexts) {
    this.ptr = ptr3;
    this._presentationContexts = presentationContexts;
  }
  _consumePresentationContexts() {
    const contexts = [...this._presentationContexts];
    this._presentationContexts.clear();
    return contexts;
  }
  _releaseReference() {
    if (!this.ptr)
      return;
    const commandBufferPtr = this.ptr;
    this.ptr = 0;
    WGPUNative.symbols.wgpuCommandBufferRelease(commandBufferPtr);
  }
}

class GPUCommandEncoder {
  ptr;
  _device;
  _presentationContexts = new Set;
  constructor(ptr3, device) {
    this.ptr = ptr3;
    this._device = device;
  }
  _assertLive() {
    if (!this.ptr || !this._device.ptr) {
      throw new Error("WebGPU command encoder has been released");
    }
  }
  beginRenderPass(descriptor) {
    this._assertLive();
    const ffiKeepalive = [];
    for (const attachment of descriptor.colorAttachments) {
      if (!attachment.view.ptr || attachment.resolveTarget && !attachment.resolveTarget.ptr) {
        throw new Error("WebGPU render pass uses a released texture view");
      }
      if (attachment.view._presentationContext) {
        this._presentationContexts.add(attachment.view._presentationContext);
      }
      if (attachment.resolveTarget?._presentationContext) {
        this._presentationContexts.add(attachment.resolveTarget._presentationContext);
      }
    }
    const colorAttachments = descriptor.colorAttachments.map((c) => makeRenderPassColorAttachment(c.view.ptr, c.resolveTarget ? c.resolveTarget.ptr : null, c.clearValue ?? { r: 0, g: 0, b: 0, a: 1 }, mapLoadOp(c.loadOp), mapStoreOp(c.storeOp)));
    const colorBuf = new ArrayBuffer(colorAttachments.length * 72);
    colorAttachments.forEach((c, i) => {
      new Uint8Array(colorBuf, i * 72, 72).set(new Uint8Array(c.buffer));
    });
    const colorPtr = ptrOrNull(colorBuf);
    ffiKeepalive.push(colorBuf);
    let depthPtr = null;
    if (descriptor.depthStencilAttachment) {
      const d = descriptor.depthStencilAttachment;
      if (!d.view.ptr) {
        throw new Error("WebGPU render pass uses a released depth view");
      }
      if (d.view._presentationContext) {
        this._presentationContexts.add(d.view._presentationContext);
      }
      const viewFormat = d.view.format ?? 0;
      if (viewFormat && !isDepthFormat(viewFormat)) {} else {
        const fields = normalizeRenderPassDepthStencilFields(d);
        const depth = makeRenderPassDepthStencilAttachment({
          view: d.view.ptr,
          ...fields
        });
        ffiKeepalive.push(depth.buffer);
        depthPtr = depth.ptr;
      }
    }
    const passDesc = makeRenderPassDescriptor(colorPtr, colorAttachments.length, depthPtr);
    ffiKeepalive.push(passDesc.buffer);
    const passPtr = WGPUNative.symbols.wgpuCommandEncoderBeginRenderPass(this.ptr, passDesc.ptr);
    return new GPURenderPassEncoder(passPtr);
  }
  beginComputePass() {
    this._assertLive();
    const desc = makeComputePassDescriptor();
    const passPtr = WGPUNative.symbols.wgpuCommandEncoderBeginComputePass(this.ptr, desc.ptr);
    desc.buffer;
    return new GPUComputePassEncoder(passPtr);
  }
  copyBufferToTexture(source, destination, size) {
    this._assertLive();
    const offset = source.offset ?? 0;
    const mapped = source.buffer.getMappedRange(0, source.buffer.size);
    const data = offset > 0 ? new Uint8Array(mapped, offset) : new Uint8Array(mapped);
    this._device.queue.writeTexture(destination, data, {
      bytesPerRow: source.bytesPerRow ?? 0,
      rowsPerImage: source.rowsPerImage ?? 0
    }, size);
  }
  copyBufferToBuffer(source, sourceOffset, destination, destinationOffset, size) {
    this._assertLive();
    if (!source.ptr || !destination.ptr) {
      throw new Error("WebGPU buffer has been destroyed");
    }
    WGPUNative.symbols.wgpuCommandEncoderCopyBufferToBuffer(this.ptr, source.ptr, BigInt(sourceOffset), destination.ptr, BigInt(destinationOffset), BigInt(size));
  }
  finish() {
    if (!this.ptr)
      throw new Error("WebGPU command encoder has been released");
    const encoderPtr = this.ptr;
    this.ptr = 0;
    let cmdPtr = 0;
    try {
      cmdPtr = Number(WGPUNative.symbols.wgpuCommandEncoderFinish(encoderPtr, 0));
    } finally {
      WGPUNative.symbols.wgpuCommandEncoderRelease(encoderPtr);
    }
    if (!cmdPtr)
      throw new Error("Failed to finish WebGPU command encoder");
    return new GPUCommandBuffer(cmdPtr, this._presentationContexts);
  }
}

class GPURenderPassEncoder {
  ptr;
  constructor(ptr3) {
    this.ptr = ptr3;
  }
  _assertLive() {
    if (!this.ptr)
      throw new Error("WebGPU render pass has ended");
  }
  setPipeline(pipeline) {
    this._assertLive();
    if (!pipeline.ptr)
      throw new Error("WebGPU render pipeline has been released");
    WGPUNative.symbols.wgpuRenderPassEncoderSetPipeline(this.ptr, pipeline.ptr);
  }
  setBindGroup(index, bindGroup, offsets) {
    this._assertLive();
    if (!bindGroup.ptr)
      throw new Error("WebGPU bind group has been released");
    let offsetsPtr = 0;
    let count = 0n;
    let offsetArray;
    if (offsets && offsets.length) {
      const arr = new BigUint64Array(offsets.length);
      offsetArray = arr;
      offsets.forEach((o, i) => {
        arr[i] = BigInt(o);
      });
      offsetsPtr = ptr2(arr);
      count = BigInt(offsets.length);
    }
    WGPUNative.symbols.wgpuRenderPassEncoderSetBindGroup(this.ptr, index, bindGroup.ptr, count, offsetsPtr);
  }
  setVertexBuffer(slot, buffer, offset = 0, size) {
    this._assertLive();
    if (!buffer.ptr)
      throw new Error("WebGPU buffer has been destroyed");
    WGPUNative.symbols.wgpuRenderPassEncoderSetVertexBuffer(this.ptr, slot, buffer.ptr, BigInt(offset), BigInt(size ?? buffer.size));
  }
  setIndexBuffer(buffer, indexFormat, offset = 0, size) {
    this._assertLive();
    if (!buffer.ptr)
      throw new Error("WebGPU buffer has been destroyed");
    const format = mapIndexFormat(indexFormat);
    WGPUNative.symbols.wgpuRenderPassEncoderSetIndexBuffer(this.ptr, buffer.ptr, format ?? 0, BigInt(offset), BigInt(size ?? buffer.size));
  }
  setViewport(x, y, width, height, minDepth = 0, maxDepth = 1) {
    this._assertLive();
    WGPUNative.symbols.wgpuRenderPassEncoderSetViewport(this.ptr, x, y, width, height, minDepth, maxDepth);
  }
  setScissorRect(x, y, width, height) {
    this._assertLive();
    WGPUNative.symbols.wgpuRenderPassEncoderSetScissorRect(this.ptr, x, y, width, height);
  }
  draw(vertexCount, instanceCount = 1, firstVertex = 0, firstInstance = 0) {
    this._assertLive();
    WGPUNative.symbols.wgpuRenderPassEncoderDraw(this.ptr, vertexCount, instanceCount, firstVertex, firstInstance);
  }
  drawIndexed(indexCount, instanceCount = 1, firstIndex = 0, baseVertex = 0, firstInstance = 0) {
    this._assertLive();
    WGPUNative.symbols.wgpuRenderPassEncoderDrawIndexed(this.ptr, indexCount, instanceCount, firstIndex, baseVertex, firstInstance);
  }
  end() {
    if (!this.ptr)
      return;
    const passPtr = this.ptr;
    this.ptr = 0;
    try {
      WGPUNative.symbols.wgpuRenderPassEncoderEnd(passPtr);
    } finally {
      WGPUNative.symbols.wgpuRenderPassEncoderRelease(passPtr);
    }
  }
}

class GPUComputePassEncoder {
  ptr;
  constructor(ptr3) {
    this.ptr = ptr3;
  }
  _assertLive() {
    if (!this.ptr)
      throw new Error("WebGPU compute pass has ended");
  }
  setPipeline(pipeline) {
    this._assertLive();
    if (!pipeline.ptr)
      throw new Error("WebGPU compute pipeline has been released");
    WGPUNative.symbols.wgpuComputePassEncoderSetPipeline(this.ptr, pipeline.ptr);
  }
  setBindGroup(index, bindGroup, offsets) {
    this._assertLive();
    if (!bindGroup.ptr)
      throw new Error("WebGPU bind group has been released");
    let offsetsPtr = 0;
    let count = 0n;
    let offsetArray;
    if (offsets && offsets.length) {
      const arr = new BigUint64Array(offsets.length);
      offsetArray = arr;
      offsets.forEach((o, i) => {
        arr[i] = BigInt(o);
      });
      offsetsPtr = ptr2(arr);
      count = BigInt(offsets.length);
    }
    WGPUNative.symbols.wgpuComputePassEncoderSetBindGroup(this.ptr, index, bindGroup.ptr, count, offsetsPtr);
  }
  dispatchWorkgroups(x, y = 1, z = 1) {
    this._assertLive();
    WGPUNative.symbols.wgpuComputePassEncoderDispatchWorkgroups(this.ptr, x, y, z);
  }
  end() {
    if (!this.ptr)
      return;
    const passPtr = this.ptr;
    this.ptr = 0;
    try {
      WGPUNative.symbols.wgpuComputePassEncoderEnd(passPtr);
    } finally {
      WGPUNative.symbols.wgpuComputePassEncoderRelease(passPtr);
    }
  }
}

class GPUAdapter {
  instancePtr;
  surfacePtr;
  features = new Set;
  limits = {};
  info = {};
  _compatibleSurface;
  _devices = new Set;
  constructor(instancePtr, surfacePtr, compatibleSurface) {
    this.instancePtr = instancePtr;
    this.surfacePtr = surfacePtr;
    this._compatibleSurface = compatibleSurface ?? null;
    this._compatibleSurface?._registerAdapter(this);
  }
  async requestDevice() {
    if (!this.instancePtr) {
      throw new Error("WebGPU adapter has been released");
    }
    if (this._compatibleSurface && !this._compatibleSurface._matchesNativeHandles(this.instancePtr, this.surfacePtr)) {
      this._invalidateFromSurface(this._compatibleSurface);
      throw new Error("WebGPU adapter's compatible surface has been released");
    }
    const adapterDevice = new BigUint64Array(2);
    try {
      WGPUBridge.createAdapterDeviceMainThread(this.instancePtr, this.surfacePtr, ptr2(adapterDevice));
      const devicePtr = Number(adapterDevice[1]);
      if (!devicePtr)
        throw new Error("Failed to create WGPU device");
      const device = new GPUDevice(devicePtr, this.instancePtr);
      this._devices.add(device);
      return device;
    } finally {
      const nativeAdapterPtr = Number(adapterDevice[0]);
      if (nativeAdapterPtr) {
        try {
          WGPUNative.symbols.wgpuAdapterRelease(nativeAdapterPtr);
        } catch {}
      }
    }
  }
  _invalidateFromSurface(surface) {
    if (this._compatibleSurface !== surface)
      return;
    const instancePtr = this.instancePtr;
    this.instancePtr = 0;
    this.surfacePtr = 0;
    this._compatibleSurface = null;
    for (const device of this._devices) {
      device._invalidateInstance(instancePtr);
    }
    this._devices.clear();
  }
}

class GPUCanvasContext {
  surfacePtr;
  instancePtr = null;
  devicePtr = null;
  format = WGPUTextureFormat_BGRA8UnormSrgb;
  alphaMode = WGPUCompositeAlphaMode_Opaque;
  supportedAlphaModes = new Set([WGPUCompositeAlphaMode_Opaque]);
  width = 1;
  height = 1;
  _usage = WGPUTextureUsage_RenderAttachment;
  _configured = false;
  _device = null;
  _currentTexture = null;
  _adapters = new Set;
  _contextKey;
  _fallbackSize;
  constructor(surfacePtr, instancePtr, contextKey) {
    this.surfacePtr = surfacePtr;
    this.instancePtr = instancePtr;
    this._contextKey = contextKey;
  }
  configure(options) {
    this._assertLive();
    if (!options.device?.ptr || !options.device.queue.ptr) {
      throw new Error("Cannot configure a WebGPU surface with a destroyed device");
    }
    if (!options.size && this._fallbackSize) {
      this.width = this._fallbackSize.width;
      this.height = this._fallbackSize.height;
    }
    if (options.format) {
      this.format = typeof options.format === "string" ? mapTextureFormat(options.format) ?? this.format : options.format;
    }
    if (options.alphaMode) {
      const requestedAlphaMode = typeof options.alphaMode === "string" ? mapAlphaMode(options.alphaMode) : options.alphaMode;
      if (typeof requestedAlphaMode === "number" && this.supportedAlphaModes.has(requestedAlphaMode)) {
        this.alphaMode = requestedAlphaMode;
      } else if (typeof requestedAlphaMode === "number" && !this.supportedAlphaModes.has(requestedAlphaMode)) {
        this.alphaMode = this.supportedAlphaModes.values().next().value ?? WGPUCompositeAlphaMode_Opaque;
      }
    }
    if (options.size) {
      this.width = options.size.width;
      this.height = options.size.height;
      this._fallbackSize = {
        width: options.size.width,
        height: options.size.height
      };
    }
    this._usage = toBigInt(options.usage ?? WGPUTextureUsage_RenderAttachment);
    PRESENTATION_STATE.detachSurface(this);
    this._releaseCurrentTexture();
    this.devicePtr = options.device.ptr;
    this._device = options.device;
    this._configureSurface();
    PRESENTATION_STATE.attach(options.device.queue, this);
  }
  _configureSurface() {
    this._assertLive();
    if (!this.devicePtr || !this._device?.ptr) {
      throw new Error("WebGPU surface is not configured with a live device");
    }
    PRESENTATION_STATE.takePending(this);
    this._releaseCurrentTexture();
    this._configured = false;
    const config = makeSurfaceConfiguration(this.devicePtr, this.width, this.height, this.format, this.alphaMode, this._usage);
    WGPUBridge.surfaceConfigure(this.surfacePtr, config.ptr);
    this._configured = true;
  }
  getCurrentTexture() {
    this._assertConfigured();
    if (this.devicePtr && this._fallbackSize && (this.width !== this._fallbackSize.width || this.height !== this._fallbackSize.height)) {
      this.width = this._fallbackSize.width;
      this.height = this._fallbackSize.height;
      this._configureSurface();
    }
    if (PRESENTATION_STATE.isPending(this) && this._currentTexture?.ptr) {
      return this._currentTexture;
    }
    PRESENTATION_STATE.takePending(this);
    this._releaseCurrentTexture();
    const surfaceTexture = makeSurfaceTexture();
    WGPUBridge.surfaceGetCurrentTexture(this.surfacePtr, surfaceTexture.ptr);
    const status = surfaceTexture.view.getUint32(16, true);
    const texPtr = Number(surfaceTexture.view.getBigUint64(8, true));
    if (status !== 1 && status !== 2) {
      if (texPtr)
        WGPUNative.symbols.wgpuTextureRelease(texPtr);
      throw new Error(`Surface status ${status}`);
    }
    if (!texPtr)
      throw new Error("WebGPU surface returned a null texture");
    this._currentTexture = new GPUTexture(texPtr, this.format, this);
    PRESENTATION_STATE.markPending(this);
    return this._currentTexture;
  }
  present() {
    this._assertLive();
    if (!PRESENTATION_STATE.takePending(this))
      return;
    return this._presentNative();
  }
  unconfigure() {
    PRESENTATION_STATE.detachSurface(this);
    this._releaseCurrentTexture();
    const shouldUnconfigure = this._configured && !!this.surfacePtr;
    this._configured = false;
    this.devicePtr = null;
    this._device = null;
    if (shouldUnconfigure) {
      return WGPUNative.symbols.wgpuSurfaceUnconfigure(this.surfacePtr);
    }
  }
  _presentNative() {
    this._assertConfigured();
    const surfacePtr = this.surfacePtr;
    try {
      return WGPUBridge.surfacePresent(surfacePtr);
    } finally {
      this._releaseCurrentTexture();
    }
  }
  _onQueueReleased(queue) {
    if (this._device?.queue !== queue)
      return;
    this._releaseCurrentTexture();
    const shouldUnconfigure = this._configured && !!this.surfacePtr;
    this._configured = false;
    this.devicePtr = null;
    this._device = null;
    if (shouldUnconfigure) {
      try {
        WGPUNative.symbols.wgpuSurfaceUnconfigure(this.surfacePtr);
      } catch {}
    }
  }
  _releaseForDeviceDestroy(queue) {
    if (this._device?.queue !== queue)
      return false;
    return releaseWebgpuContext(this._contextKey);
  }
  _registerAdapter(adapter) {
    this._adapters.add(adapter);
  }
  _matchesNativeHandles(instancePtr, surfacePtr) {
    return !!this.surfacePtr && !!this.instancePtr && this.instancePtr === instancePtr && this.surfacePtr === surfacePtr;
  }
  _prepareRelease() {
    PRESENTATION_STATE.detachSurface(this);
    this._releaseCurrentTexture();
    for (const adapter of this._adapters) {
      adapter._invalidateFromSurface(this);
    }
    this._adapters.clear();
    const wasConfigured = this._configured;
    this._configured = false;
    this.surfacePtr = 0;
    this.instancePtr = null;
    this.devicePtr = null;
    this._device = null;
    return wasConfigured;
  }
  _releaseCurrentTexture() {
    this._currentTexture?._releaseReference();
    this._currentTexture = null;
  }
  _assertLive() {
    if (!this.surfacePtr || !this.instancePtr) {
      throw new Error("WebGPU canvas context has been released");
    }
  }
  _assertConfigured() {
    this._assertLive();
    if (!this._configured || !this.devicePtr || !this._device?.ptr) {
      throw new Error("WebGPU canvas context is not configured");
    }
  }
}
function getViewPtr(view) {
  if (view instanceof GpuWindow)
    return view.wgpuView.ptr;
  return view.ptr;
}
function getViewContextKey(view) {
  return getWebgpuContextKey(view);
}
function createContext(view) {
  const key = getViewContextKey(view);
  const existing = VIEW_CONTEXTS.get(key);
  if (existing) {
    VIEW_CONTEXTS.lastCreatedContext = existing.context;
    return existing;
  }
  const viewPtr = getViewPtr(view);
  if (!viewPtr)
    throw new Error("WGPUView pointer not available");
  const nativeOps = {
    createInstance: () => Number(WGPUNative.symbols.wgpuCreateInstance(0)),
    createSurface: (instancePtr) => Number(WGPUBridge.createSurfaceForView(instancePtr, viewPtr)),
    unconfigureSurface: (surfacePtr) => WGPUNative.symbols.wgpuSurfaceUnconfigure(surfacePtr),
    releaseSurface: (surfacePtr) => WGPUBridge.releaseSurfaceForView(surfacePtr) || WGPUNative.symbols.wgpuSurfaceRelease(surfacePtr),
    releaseInstance: (instancePtr) => WGPUNative.symbols.wgpuInstanceRelease(instancePtr)
  };
  const created = createNativeWebgpuContext(nativeOps, ({ instance, surface }) => {
    const caps = makeSurfaceCapabilities();
    let pick;
    try {
      WGPUNative.symbols.wgpuSurfaceGetCapabilities(surface, 0, caps.ptr);
      pick = pickSurfaceFormatAlpha(caps.view, WGPUTextureFormat_BGRA8UnormSrgb);
    } finally {
      WGPUBridge.surfaceCapabilitiesFreeMembers(caps.ptr);
    }
    const ctx = new GPUCanvasContext(surface, instance, key);
    ctx.format = pick.format;
    ctx.alphaMode = pick.alphaMode;
    ctx.supportedAlphaModes = new Set(pick.alphaModes.length ? pick.alphaModes : [pick.alphaMode]);
    try {
      if (view instanceof GpuWindow) {
        const size = view.getSize();
        ctx.width = size.width;
        ctx.height = size.height;
        ctx._fallbackSize = { width: size.width, height: size.height };
      }
    } catch {}
    return {
      instance,
      surface,
      context: ctx,
      teardown: () => {
        const wasConfigured = ctx._prepareRelease();
        releaseNativeWebgpuContext({ instance, surface }, {
          unconfigureSurface: (surfacePtr) => {
            if (wasConfigured) {
              WGPUNative.symbols.wgpuSurfaceUnconfigure(surfacePtr);
            }
          },
          releaseSurface: nativeOps.releaseSurface,
          releaseInstance: nativeOps.releaseInstance
        });
      }
    };
  });
  let didRegisterEntry = false;
  try {
    VIEW_CONTEXTS.set(key, created);
    didRegisterEntry = true;
    registerWebgpuContextRelease(key, () => VIEW_CONTEXTS.release(key));
    return created;
  } catch (error) {
    if (didRegisterEntry)
      VIEW_CONTEXTS.release(key);
    else
      created.teardown();
    throw error;
  }
}
function createCanvasShim(win) {
  const size = win.getSize();
  const ctx = createContext(win);
  let width = size.width;
  let height = size.height;
  const syncFallbackSize = () => {
    ctx.context._fallbackSize = { width, height };
  };
  syncFallbackSize();
  return {
    get width() {
      return width;
    },
    set width(value) {
      width = value;
      syncFallbackSize();
    },
    get height() {
      return height;
    },
    set height(value) {
      height = value;
      syncFallbackSize();
    },
    clientWidth: size.width,
    clientHeight: size.height,
    style: {},
    getContext: (type) => {
      if (type !== "webgpu")
        return null;
      return ctx.context;
    },
    getBoundingClientRect: () => {
      const current = win.getSize();
      return {
        left: 0,
        top: 0,
        width: current.width,
        height: current.height
      };
    },
    addEventListener: () => {},
    removeEventListener: () => {},
    setAttribute: () => {}
  };
}
function decodePngRGBA(data) {
  if (data.byteLength < 8)
    throw new Error("Invalid PNG header");
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  const readU32 = (offset2) => view.getUint32(offset2, false);
  if (readU32(0) !== 2303741511) {
    throw new Error("Invalid PNG header");
  }
  let offset = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = 0;
  let compressed = null;
  while (offset < data.length) {
    const length = readU32(offset);
    const type = String.fromCharCode(data[offset + 4], data[offset + 5], data[offset + 6], data[offset + 7]);
    const chunkStart = offset + 8;
    if (type === "IHDR") {
      width = readU32(chunkStart);
      height = readU32(chunkStart + 4);
      bitDepth = data[chunkStart + 8];
      colorType = data[chunkStart + 9];
    } else if (type === "IDAT") {
      const chunk = data.subarray(chunkStart, chunkStart + length);
      if (!compressed) {
        compressed = chunk;
      } else {
        const combined = new Uint8Array(compressed.length + chunk.length);
        combined.set(compressed);
        combined.set(chunk, compressed.length);
        compressed = combined;
      }
    } else if (type === "IEND") {
      break;
    }
    offset += 12 + length;
  }
  if (!compressed)
    throw new Error("No IDAT chunk found");
  if (bitDepth !== 8)
    throw new Error("Only 8-bit PNG supported");
  if (colorType !== 6)
    throw new Error("Only RGBA PNG supported");
  const inflated = inflateSync(compressed);
  const stride = width * 4;
  const out = new Uint8Array(width * height * 4);
  let inOffset = 0;
  let outOffset = 0;
  let prior = new Uint8Array(stride);
  for (let y = 0;y < height; y += 1) {
    const filter = inflated[inOffset];
    inOffset += 1;
    const row = inflated.subarray(inOffset, inOffset + stride);
    inOffset += stride;
    const recon = new Uint8Array(stride);
    if (filter === 0) {
      recon.set(row);
    } else if (filter === 1) {
      for (let i = 0;i < stride; i += 1) {
        const left = i >= 4 ? recon[i - 4] : 0;
        recon[i] = row[i] + left & 255;
      }
    } else if (filter === 2) {
      for (let i = 0;i < stride; i += 1) {
        recon[i] = row[i] + prior[i] & 255;
      }
    } else if (filter === 3) {
      for (let i = 0;i < stride; i += 1) {
        const left = i >= 4 ? recon[i - 4] : 0;
        const up = prior[i];
        recon[i] = row[i] + Math.floor((left + up) / 2) & 255;
      }
    } else if (filter === 4) {
      const paeth = (a, b, c) => {
        const p = a + b - c;
        const pa = Math.abs(p - a);
        const pb = Math.abs(p - b);
        const pc = Math.abs(p - c);
        if (pa <= pb && pa <= pc)
          return a;
        if (pb <= pc)
          return b;
        return c;
      };
      for (let i = 0;i < stride; i += 1) {
        const left = i >= 4 ? recon[i - 4] : 0;
        const up = prior[i];
        const upLeft = i >= 4 ? prior[i - 4] : 0;
        recon[i] = row[i] + paeth(left, up, upLeft) & 255;
      }
    } else {
      throw new Error(`Unsupported PNG filter ${filter}`);
    }
    out.set(recon, outOffset);
    outOffset += stride;
    prior = recon;
  }
  return { width, height, data: out };
}
function mapTextureFormat(format) {
  if (typeof format === "number")
    return format;
  switch (format) {
    case "r8unorm":
      return WGPUTextureFormat_R8Unorm;
    case "r8snorm":
      return WGPUTextureFormat_R8Snorm;
    case "r8uint":
      return WGPUTextureFormat_R8Uint;
    case "r8sint":
      return WGPUTextureFormat_R8Sint;
    case "rg8unorm":
      return WGPUTextureFormat_RG8Unorm;
    case "rg8snorm":
      return WGPUTextureFormat_RG8Snorm;
    case "rg8uint":
      return WGPUTextureFormat_RG8Uint;
    case "rg8sint":
      return WGPUTextureFormat_RG8Sint;
    case "bgra8unorm":
      return WGPUTextureFormat_BGRA8Unorm;
    case "bgra8unorm-srgb":
      return WGPUTextureFormat_BGRA8UnormSrgb;
    case "rgba8unorm":
      return WGPUTextureFormat_RGBA8Unorm;
    case "rgba8unorm-srgb":
      return WGPUTextureFormat_RGBA8UnormSrgb;
    case "rgba8snorm":
      return WGPUTextureFormat_RGBA8Snorm;
    case "rgba8uint":
      return WGPUTextureFormat_RGBA8Uint;
    case "rgba8sint":
      return WGPUTextureFormat_RGBA8Sint;
    case "r32float":
      return WGPUTextureFormat_R32Float;
    case "r32uint":
      return WGPUTextureFormat_R32Uint;
    case "r32sint":
      return WGPUTextureFormat_R32Sint;
    case "rg32float":
      return WGPUTextureFormat_RG32Float;
    case "rg32uint":
      return WGPUTextureFormat_RG32Uint;
    case "rg32sint":
      return WGPUTextureFormat_RG32Sint;
    case "rgba16float":
      return WGPUTextureFormat_RGBA16Float;
    case "rgba16uint":
      return WGPUTextureFormat_RGBA16Uint;
    case "rgba16sint":
      return WGPUTextureFormat_RGBA16Sint;
    case "rgba32uint":
      return WGPUTextureFormat_RGBA32Uint;
    case "rgba32sint":
      return WGPUTextureFormat_RGBA32Sint;
    case "depth24plus":
      return WGPUTextureFormat_Depth24Plus;
    case "depth24plus-stencil8":
      return WGPUTextureFormat_Depth24PlusStencil8;
    case "depth32float":
      return WGPUTextureFormat_Depth32Float;
    case "depth16unorm":
      return WGPUTextureFormat_Depth16Unorm;
    case "depth32float-stencil8":
      return WGPUTextureFormat_Depth32FloatStencil8;
    default:
      return;
  }
}
function isIntegerFormat(format) {
  return format === WGPUTextureFormat_R8Uint || format === WGPUTextureFormat_R8Sint || format === WGPUTextureFormat_RG8Uint || format === WGPUTextureFormat_RG8Sint || format === WGPUTextureFormat_RGBA8Uint || format === WGPUTextureFormat_RGBA8Sint || format === WGPUTextureFormat_R32Uint || format === WGPUTextureFormat_R32Sint || format === WGPUTextureFormat_RG32Uint || format === WGPUTextureFormat_RG32Sint || format === WGPUTextureFormat_RGBA16Uint || format === WGPUTextureFormat_RGBA16Sint || format === WGPUTextureFormat_RGBA32Uint || format === WGPUTextureFormat_RGBA32Sint;
}
function isDepthFormat(format) {
  return format === WGPUTextureFormat_Depth24Plus || format === WGPUTextureFormat_Depth24PlusStencil8 || format === WGPUTextureFormat_Depth32Float || format === WGPUTextureFormat_Depth16Unorm || format === WGPUTextureFormat_Depth32FloatStencil8;
}
function mapTextureViewDimension(dim) {
  if (typeof dim === "number")
    return dim;
  switch (dim) {
    case "2d":
      return WGPUTextureViewDimension_2D;
    case "2d-array":
      return WGPUTextureViewDimension_2DArray;
    case "3d":
      return WGPUTextureViewDimension_3D;
    case "cube":
      return WGPUTextureViewDimension_Cube;
    case "cube-array":
      return WGPUTextureViewDimension_CubeArray;
    default:
      return;
  }
}
function mapTextureAspect(aspect) {
  if (typeof aspect === "number")
    return aspect;
  switch (aspect) {
    case "all":
      return WGPUTextureAspect_All;
    case "depth-only":
      return WGPUTextureAspect_DepthOnly;
    case "stencil-only":
      return WGPUTextureAspect_StencilOnly;
    default:
      return;
  }
}
function mapVertexFormat(format) {
  if (typeof format === "number")
    return format;
  switch (format) {
    case "float32":
      return WGPUVertexFormat_Float32;
    case "float32x2":
      return WGPUVertexFormat_Float32x2;
    case "float32x3":
      return WGPUVertexFormat_Float32x3;
    case "float32x4":
      return WGPUVertexFormat_Float32x4;
    case "uint32":
      return WGPUVertexFormat_Uint32;
    case "uint32x2":
      return WGPUVertexFormat_Uint32x2;
    case "uint32x3":
      return WGPUVertexFormat_Uint32x3;
    case "uint32x4":
      return WGPUVertexFormat_Uint32x4;
    case "sint32":
      return WGPUVertexFormat_Sint32;
    case "sint32x2":
      return WGPUVertexFormat_Sint32x2;
    case "sint32x3":
      return WGPUVertexFormat_Sint32x3;
    case "sint32x4":
      return WGPUVertexFormat_Sint32x4;
    default:
      return WGPUVertexFormat_Float32x3;
  }
}
function mapVertexStepMode(mode) {
  if (typeof mode === "number")
    return mode;
  switch (mode) {
    case "instance":
      return WGPUVertexStepMode_Instance;
    case "vertex":
    default:
      return WGPUVertexStepMode_Vertex;
  }
}
function mapPrimitiveTopology(topology) {
  if (typeof topology === "number")
    return topology;
  switch (topology) {
    case "point-list":
      return WGPUPrimitiveTopology_PointList;
    case "line-list":
      return WGPUPrimitiveTopology_LineList;
    case "line-strip":
      return WGPUPrimitiveTopology_LineStrip;
    case "triangle-strip":
      return WGPUPrimitiveTopology_TriangleStrip;
    case "triangle-list":
    default:
      return WGPUPrimitiveTopology_TriangleList;
  }
}
function mapFrontFace(face) {
  if (typeof face === "number")
    return face;
  switch (face) {
    case "cw":
      return WGPUFrontFace_CW;
    case "ccw":
    default:
      return WGPUFrontFace_CCW;
  }
}
function mapCullMode(mode) {
  if (typeof mode === "number")
    return mode;
  switch (mode) {
    case "front":
      return WGPUCullMode_Front;
    case "back":
      return WGPUCullMode_Back;
    case "none":
    default:
      return WGPUCullMode_None;
  }
}
function mapCompareFunction(fn) {
  if (fn == null)
    return 0;
  if (typeof fn === "number")
    return fn;
  switch (fn) {
    case "never":
      return WGPUCompareFunction_Never;
    case "less":
      return WGPUCompareFunction_Less;
    case "equal":
      return WGPUCompareFunction_Equal;
    case "less-equal":
      return WGPUCompareFunction_LessEqual;
    case "greater":
      return WGPUCompareFunction_Greater;
    case "not-equal":
      return WGPUCompareFunction_NotEqual;
    case "greater-equal":
      return WGPUCompareFunction_GreaterEqual;
    case "always":
    default:
      return WGPUCompareFunction_Always;
  }
}
function mapAddressMode(mode) {
  if (typeof mode === "number")
    return mode;
  switch (mode) {
    case "repeat":
      return WGPUAddressMode_Repeat;
    case "mirror-repeat":
      return WGPUAddressMode_MirrorRepeat;
    case "clamp-to-edge":
    default:
      return WGPUAddressMode_ClampToEdge;
  }
}
function mapFilterMode(mode) {
  if (typeof mode === "number")
    return mode;
  switch (mode) {
    case "nearest":
      return WGPUFilterMode_Nearest;
    case "linear":
    default:
      return WGPUFilterMode_Linear;
  }
}
function mapMipmapFilterMode(mode) {
  if (typeof mode === "number")
    return mode;
  switch (mode) {
    case "nearest":
      return WGPUMipmapFilterMode_Nearest;
    case "linear":
    default:
      return WGPUMipmapFilterMode_Linear;
  }
}
function mapShaderStage(stage) {
  if (typeof stage === "number")
    return stage;
  switch (stage) {
    case "vertex":
      return WGPUShaderStage_Vertex;
    case "fragment":
      return WGPUShaderStage_Fragment;
    case "compute":
      return WGPUShaderStage_Compute;
    default:
      return 0;
  }
}
function mapBufferBindingType(type) {
  if (typeof type === "number")
    return type;
  switch (type) {
    case "uniform":
      return WGPUBufferBindingType_Uniform;
    case "storage":
      return WGPUBufferBindingType_Storage;
    case "read-only-storage":
      return WGPUBufferBindingType_ReadOnlyStorage;
    default:
      return WGPUBufferBindingType_Uniform;
  }
}
function mapSamplerBindingType(type) {
  if (typeof type === "number")
    return type;
  switch (type) {
    case "comparison":
      return WGPUSamplerBindingType_Comparison;
    case "non-filtering":
      return WGPUSamplerBindingType_NonFiltering;
    case "filtering":
    default:
      return WGPUSamplerBindingType_Filtering;
  }
}
function mapTextureSampleType(type) {
  if (typeof type === "number")
    return type;
  switch (type) {
    case "unfilterable-float":
      return WGPUTextureSampleType_UnfilterableFloat;
    case "depth":
      return WGPUTextureSampleType_Depth;
    case "sint":
      return WGPUTextureSampleType_Sint;
    case "uint":
      return WGPUTextureSampleType_Uint;
    case "float":
    default:
      return WGPUTextureSampleType_Float;
  }
}
function mapStorageTextureAccess(access) {
  if (typeof access === "number")
    return access;
  switch (access) {
    case "read-only":
      return WGPUStorageTextureAccess_ReadOnly;
    case "read-write":
      return WGPUStorageTextureAccess_ReadWrite;
    case "write-only":
    default:
      return WGPUStorageTextureAccess_WriteOnly;
  }
}
function mapBlendOperation(op) {
  if (typeof op === "number")
    return op;
  switch (op) {
    case "add":
    default:
      return WGPUBlendOperation_Add;
  }
}
function mapBlendFactor(factor) {
  if (typeof factor === "number")
    return factor;
  switch (factor) {
    case "one":
      return WGPUBlendFactor_One;
    case "zero":
      return WGPUBlendFactor_Zero;
    case "src-alpha":
      return WGPUBlendFactor_SrcAlpha;
    case "one-minus-src-alpha":
      return WGPUBlendFactor_OneMinusSrcAlpha;
    default:
      return WGPUBlendFactor_One;
  }
}
function mapIndexFormat(format) {
  if (typeof format === "number")
    return format;
  switch (format) {
    case "uint32":
      return 2;
    case "uint16":
      return 1;
    default:
      return 0;
  }
}
function mapAlphaMode(mode) {
  if (typeof mode === "number")
    return mode;
  switch (mode) {
    case "premultiplied":
      return WGPUCompositeAlphaMode_Premultiplied;
    case "unpremultiplied":
      return WGPUCompositeAlphaMode_Unpremultiplied;
    case "opaque":
    default:
      return WGPUCompositeAlphaMode_Opaque;
  }
}
function makeShaderSourceWGSL(codePtr, codeLen) {
  const buffer = new ArrayBuffer(32);
  const view = new DataView(buffer);
  writePtr(view, 0, 0);
  writeU32(view, 8, 2);
  writeU32(view, 12, 0);
  writePtr(view, 16, codePtr);
  writeU64(view, 24, codeLen);
  return { buffer, ptr: ptr2(buffer) };
}
function makeShaderModuleDescriptor(nextInChainPtr) {
  const buffer = new ArrayBuffer(24);
  const view = new DataView(buffer);
  writePtr(view, 0, nextInChainPtr);
  writePtr(view, 8, 0);
  writeU64(view, 16, 0n);
  return { buffer, ptr: ptr2(buffer) };
}
function makeTexelCopyTextureInfo(texturePtr, mipLevel = 0, origin) {
  const buffer = new ArrayBuffer(32);
  const view = new DataView(buffer);
  writePtr(view, 0, texturePtr);
  writeU32(view, 8, mipLevel);
  writeU32(view, 12, origin?.x ?? 0);
  writeU32(view, 16, origin?.y ?? 0);
  writeU32(view, 20, origin?.z ?? 0);
  writeU32(view, 24, 0);
  writeU32(view, 28, 0);
  return { buffer, ptr: ptr2(buffer) };
}
function makeTexelCopyBufferLayout(offset, bytesPerRow, rowsPerImage) {
  const buffer = new ArrayBuffer(16);
  const view = new DataView(buffer);
  writeU64(view, 0, BigInt(offset));
  writeU32(view, 8, bytesPerRow);
  writeU32(view, 12, rowsPerImage);
  return { buffer, ptr: ptr2(buffer) };
}
function makeExtent3D(width, height, depth) {
  const buffer = new ArrayBuffer(12);
  const view = new DataView(buffer);
  writeU32(view, 0, width);
  writeU32(view, 4, height);
  writeU32(view, 8, depth);
  return { buffer, ptr: ptr2(buffer) };
}
function alignTo(value, alignment) {
  return Math.ceil(value / alignment) * alignment;
}
function bytesPerPixelForFormat(format) {
  switch (format) {
    case WGPUTextureFormat_R8Unorm:
    case WGPUTextureFormat_R8Snorm:
    case WGPUTextureFormat_R8Uint:
    case WGPUTextureFormat_R8Sint:
      return 1;
    case WGPUTextureFormat_RG8Unorm:
    case WGPUTextureFormat_RG8Snorm:
    case WGPUTextureFormat_RG8Uint:
    case WGPUTextureFormat_RG8Sint:
      return 2;
    case WGPUTextureFormat_BGRA8Unorm:
    case WGPUTextureFormat_BGRA8UnormSrgb:
    case WGPUTextureFormat_RGBA8Unorm:
    case WGPUTextureFormat_RGBA8UnormSrgb:
    case WGPUTextureFormat_Depth24Plus:
    case WGPUTextureFormat_Depth24PlusStencil8:
    case WGPUTextureFormat_Depth32Float:
      return 4;
    case WGPUTextureFormat_Depth32FloatStencil8:
      return 8;
    case WGPUTextureFormat_RG32Float:
    case WGPUTextureFormat_RG32Uint:
    case WGPUTextureFormat_RG32Sint:
    case WGPUTextureFormat_RGBA16Float:
    case WGPUTextureFormat_RGBA16Uint:
    case WGPUTextureFormat_RGBA16Sint:
      return 8;
    case WGPUTextureFormat_RGBA32Uint:
    case WGPUTextureFormat_RGBA32Sint:
      return 16;
    default:
      return 4;
  }
}
function repackTextureData(data, srcStride, dstStride, minRowBytes, height, rowsPerImage, layers) {
  const src = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  const totalRows = rowsPerImage * layers;
  const dst = new Uint8Array(dstStride * totalRows);
  let srcOffset = 0;
  let dstOffset = 0;
  for (let layer = 0;layer < layers; layer += 1) {
    for (let row = 0;row < rowsPerImage; row += 1) {
      if (row < height) {
        dst.set(src.subarray(srcOffset, srcOffset + minRowBytes), dstOffset);
      }
      srcOffset += srcStride;
      dstOffset += dstStride;
    }
  }
  return dst;
}
var webgpu = {
  navigator: {
    async requestAdapter(options) {
      const compatibleSurface = options?.compatibleSurface ?? VIEW_CONTEXTS.lastCreatedContext ?? undefined;
      if (compatibleSurface) {
        const instancePtr = compatibleSurface.instancePtr;
        const surfacePtr = compatibleSurface.surfacePtr;
        if (!instancePtr || !surfacePtr || !compatibleSurface._matchesNativeHandles(instancePtr, surfacePtr)) {
          throw new Error("Cannot request an adapter for a released WebGPU surface");
        }
        return new GPUAdapter(instancePtr, surfacePtr, compatibleSurface);
      }
      const instance = Number(WGPUNative.symbols.wgpuCreateInstance(0));
      if (!instance)
        throw new Error("Failed to create WGPU instance");
      return new GPUAdapter(instance, 0);
    },
    getPreferredCanvasFormat() {
      return "bgra8unorm";
    }
  },
  createContext,
  GPUCanvasContext,
  utils: {
    createCanvasShim,
    decodePngRGBA
  },
  install() {
    const nav = globalThis.navigator ?? {};
    nav.gpu = webgpu.navigator;
    globalThis.navigator = nav;
    globalThis.GPUCanvasContext = GPUCanvasContext;
  }
};
var webgpuAdapter_default = webgpu;

// .hutch/devkit/api/sdks/main/index.ts
init_native();
init_BuildConfig();
init_native();
var _carrotManifest = null;
var _carrotContext = null;
var _bootstrap = globalThis.__bunnyCarrotBootstrap;
if (_bootstrap) {
  _carrotManifest = _bootstrap.manifest ?? null;
  _carrotContext = _bootstrap.context ?? null;
}
if (bridge) {
  bridge.on("init", (payload) => {
    if (payload?.manifest)
      _carrotManifest = payload.manifest;
    if (payload?.context)
      _carrotContext = payload.context;
  });
  for (const eventName of ["application-menu-clicked", "context-menu-clicked"]) {
    bridge.on(eventName, (payload) => {
      eventEmitter_default.emitEvent({ type: eventName, data: payload });
    });
  }
  bridge.on("auth-token-changed", (payload) => {
    const token = payload?.token;
    if (token && _carrotContext) {
      _carrotContext.authToken = token;
    }
  });
  bridge.on("auth-token-cleared", () => {
    if (_carrotContext) {
      _carrotContext.authToken = null;
    }
  });
}
var app = {
  on(name, handler) {
    if (bridge) {
      return bridge.on(name, handler);
    }
    eventEmitter_default.on(name, (e) => handler(e.data));
    return () => {};
  },
  quit() {
    quit();
  },
  get isPackaged() {
    return BuildConfig.getSync().isPackaged;
  },
  get isCarrotMode() {
    return !hasFFI;
  },
  get manifest() {
    return _carrotManifest;
  },
  get currentDir() {
    return _carrotContext?.currentDir ?? "";
  },
  get statePath() {
    return _carrotContext?.statePath ?? "";
  },
  get logsPath() {
    return _carrotContext?.logsPath ?? "";
  },
  get authToken() {
    return _carrotContext?.authToken ?? null;
  },
  async fetchAuthToken() {
    if (!bridge)
      return null;
    const result = await bridge.requestHost("get-auth-token");
    if (result?.token && _carrotContext) {
      _carrotContext.authToken = result.token;
    }
    return result?.token ?? null;
  },
  async setAuthToken(token) {
    if (!bridge)
      return;
    await bridge.requestHost("set-auth-token", { token });
    if (_carrotContext) {
      _carrotContext.authToken = token;
    }
  },
  async setDeviceToken(token, tokenId) {
    if (!bridge)
      return;
    await bridge.requestHost("set-device-token", { token, tokenId });
  },
  async getMachineInfo() {
    if (!bridge) {
      return { machineId: "", hostname: "", platform: "" };
    }
    return bridge.requestHost("get-machine-info");
  },
  async updateCarrots() {
    if (!bridge)
      return;
    await bridge.requestHost("update-carrots");
  },
  async getWebBridgePort() {
    if (!bridge)
      return null;
    const result = await bridge.requestHost("get-web-bridge-port");
    return typeof result?.port === "number" ? result.port : null;
  },
  get channel() {
    return _carrotContext?.channel ?? "";
  },
  openManager() {
    if (bridge)
      bridge.sendAction("open-manager");
  },
  openBunnyWindow(payload) {
    if (bridge)
      bridge.sendAction("open-bunny-window", payload);
  },
  async getWindowFrame(windowId) {
    if (!bridge)
      return null;
    return bridge.requestHost("window-get-frame", { windowId });
  }
};
var Electrobun = {
  app,
  BrowserWindow,
  BrowserView,
  GpuWindow,
  WGPUView,
  Tray,
  Updater,
  Utils: exports_Utils,
  ApplicationMenu: exports_ApplicationMenu,
  ContextMenu: exports_ContextMenu,
  GlobalShortcut,
  Screen,
  Session,
  WGPUBridge,
  BuildConfig,
  events: eventEmitter_default,
  PATHS: exports_Paths,
  Socket: exports_Socket,
  WGPU: webGPU_default,
  webgpu: webgpuAdapter_default
};
var main_default = Electrobun;

// app/desktop.ts
import { access, readFile as readFile8, realpath as realpath2 } from "fs/promises";

// app/updates/bundle.ts
import { createHash } from "crypto";
import { createReadStream } from "fs";
import { lstat, readFile, readdir } from "fs/promises";
import { execFile } from "child_process";
import { join as join6 } from "path";
function command(program, args) {
  return new Promise((resolve4, reject) => {
    execFile(program, args, { encoding: "utf8", timeout: 120000, maxBuffer: 16 * 1024 * 1024 }, (error, stdout) => {
      if (error)
        reject(new Error("Update bundle validation failed."));
      else
        resolve4(stdout.trim());
    });
  });
}
async function fileDigest(path) {
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(path))
    hash.update(chunk);
  return hash.digest("hex");
}
async function bundleInventory(base, relative2 = "", found = Object.create(null)) {
  const path = join6(base, relative2), info = await lstat(path);
  if (!info.isFile() && !info.isDirectory())
    throw new Error("Unsupported update bundle entry.");
  const attrs = Object.create(null);
  const names = (await command("/usr/bin/xattr", [path])).split(`
`).filter(Boolean).sort();
  for (const name of names) {
    if (name !== "com.apple.provenance")
      attrs[name] = (await command("/usr/bin/xattr", ["-px", name, path])).replaceAll(/\s/g, "");
  }
  found[relative2] = {
    kind: info.isFile() ? "file" : "directory",
    mode: info.mode & 511,
    attrs,
    ...info.isFile() ? { sha256: await fileDigest(path) } : {}
  };
  if (info.isDirectory())
    for (const name of (await readdir(path)).sort())
      await bundleInventory(base, join6(relative2, name), found);
  return found;
}
async function restoreBundleAttributes(app2, inventoryPath) {
  const expected = JSON.parse(await readFile(inventoryPath, "utf8"));
  const actual = await bundleInventory(app2);
  if (Object.keys(expected).sort().join("\x00") !== Object.keys(actual).sort().join("\x00"))
    throw new Error("Prepared bundle paths differ from the signed inventory.");
  for (const [path, entry] of Object.entries(actual)) {
    const target = expected[path];
    if (!target || target.kind !== entry.kind || target.mode !== entry.mode || target.sha256 !== entry.sha256 || !target.attrs || typeof target.attrs !== "object" || Array.isArray(target.attrs))
      throw new Error("Prepared bundle bytes or modes differ from the signed inventory.");
    for (const [name, value] of Object.entries(target.attrs)) {
      if (!name || name.includes("\x00") || typeof value !== "string" || !/^(?:[a-fA-F0-9]{2})*$/.test(value))
        throw new Error("Invalid signed bundle attributes.");
    }
  }
  for (const [path, entry] of Object.entries(actual)) {
    const target = expected[path];
    for (const name of Object.keys(entry.attrs))
      if (!Object.hasOwn(target.attrs, name))
        await command("/usr/bin/xattr", ["-d", name, join6(app2, path)]);
    for (const [name, value] of Object.entries(target.attrs))
      if (entry.attrs[name] !== value)
        await command("/usr/bin/xattr", ["-wx", name, value, join6(app2, path)]);
  }
}
async function verifyBundle(app2, inventoryPath, release) {
  const expected = await readFile(inventoryPath, "utf8");
  if (JSON.stringify(await bundleInventory(app2)) !== expected)
    throw new Error("Prepared bundle differs from the signed inventory.");
  const resources = join6(app2, "Contents/Resources");
  const version = JSON.parse(await readFile(join6(resources, "version.json"), "utf8"));
  const plist = JSON.parse(await command("/usr/bin/plutil", ["-convert", "json", "-o", "-", join6(app2, "Contents/Info.plist")]));
  const config = JSON.parse(await readFile(join6(resources, "cardslop-update.json"), "utf8"));
  if (version.identifier !== release.identifier || version.channel !== release.channel || version.version !== release.version || plist.CFBundleIdentifier !== release.identifier || plist.CFBundleVersion !== release.version || config.release !== release.release || config.version !== release.version)
    throw new Error("Prepared app identity differs from the signed release.");
  await command("/usr/bin/codesign", ["--verify", "--deep", "--strict", app2]);
}

// app/updates/health.ts
import { readFile as readFile3 } from "fs/promises";
import { join as join8 } from "path";

// app/filesystem.ts
import { link, mkdir, open, readFile as readFile2, readdir as readdir2, rename, rm, stat } from "fs/promises";
import { join as join7 } from "path";
import { spawn } from "child_process";
async function acquireHostLock(privateFolder) {
  await mkdir(privateFolder, { recursive: true, mode: 448 });
  const child = spawn("/usr/bin/lockf", ["-k", "-s", "-t", "0", join7(privateFolder, "instance.lock"), "/bin/cat"], { stdio: ["pipe", "pipe", "ignore"] });
  let owned = false, releasing = false;
  const exited = new Promise((resolve4) => child.once("close", () => {
    if (owned && !releasing)
      process.exit(1);
    resolve4();
  }));
  await new Promise((resolve4, reject) => {
    child.once("error", () => reject(new Error("Unable to lock the private save.")));
    child.once("exit", () => reject(new Error("Cardslop is already open, or its private save cannot be locked.")));
    child.stdin.on("error", () => {});
    child.stdout.once("data", () => {
      owned = true;
      resolve4();
    });
    child.stdin.write(`locked
`);
  });
  return async () => {
    releasing = true;
    child.stdin.end();
    await exited;
  };
}
function hostFiles(privateFolder, chooseFolder, filesystem = { rename }) {
  const name = (value) => {
    if (!/^[a-zA-Z0-9-]{1,100}$/.test(value))
      throw new Error("Invalid storage name.");
    return value;
  };
  const atomic = async (folder, file, value) => {
    await mkdir(folder, { recursive: true, mode: 448 });
    const temporary = join7(folder, `.${file}-${crypto.randomUUID()}.tmp`);
    try {
      const handle = await open(temporary, "wx", 384);
      try {
        await handle.writeFile(value);
        await handle.sync();
      } finally {
        await handle.close();
      }
      await filesystem.rename(temporary, join7(folder, file));
      const directory = await open(folder, "r");
      try {
        await directory.sync();
      } finally {
        await directory.close();
      }
    } finally {
      await rm(temporary, { force: true });
    }
  };
  return {
    async readPrivate(key) {
      try {
        return await readFile2(join7(privateFolder, name(key)), "utf8");
      } catch (error) {
        if (error.code === "ENOENT")
          return "";
        throw error;
      }
    },
    async writePrivate(key, value) {
      await atomic(privateFolder, name(key), value);
    },
    async chooseRecordsFolder() {
      return chooseFolder();
    },
    async writeGame(folder, year, month, id, value) {
      if (!/^\d{4}$/.test(year) || !/^(0[1-9]|1[0-2])$/.test(month))
        throw new Error("Invalid record date.");
      if (!(await stat(folder)).isDirectory())
        throw new Error("Records folder is unavailable.");
      const directory = join7(folder, "games", year, month);
      await mkdir(directory, { recursive: true, mode: 448 });
      const destination = join7(directory, `${name(id)}.json`);
      const temporary = join7(directory, `.${name(id)}-${crypto.randomUUID()}.tmp`);
      try {
        const handle = await open(temporary, "wx", 384);
        try {
          await handle.writeFile(value);
          await handle.sync();
        } finally {
          await handle.close();
        }
        try {
          await link(temporary, destination);
        } catch (error) {
          if (error.code !== "EEXIST")
            throw error;
          if (await readFile2(destination, "utf8") !== value)
            throw new Error("Game record conflict: existing content differs.");
        }
        const directoryHandle = await open(directory, "r");
        try {
          await directoryHandle.sync();
        } finally {
          await directoryHandle.close();
        }
      } finally {
        await rm(temporary, { force: true });
      }
    },
    async writePlayer(folder, id, value) {
      await atomic(join7(folder, "players"), `${name(id)}.json`, value);
    },
    async readGames(folder) {
      if (!(await stat(folder)).isDirectory())
        throw new Error("Records folder is unavailable.");
      const records = [];
      const scan = async (directory, depth) => {
        let entries;
        try {
          entries = await readdir2(directory, { withFileTypes: true });
        } catch (error) {
          if (depth === 0 && error.code === "ENOENT")
            return;
          throw error;
        }
        for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
          if (depth < 2) {
            const pattern = depth === 0 ? /^\d{4}$/ : /^(0[1-9]|1[0-2])$/;
            if (!pattern.test(entry.name))
              continue;
            if (!entry.isDirectory())
              throw new Error("Invalid game records directory.");
            await scan(join7(directory, entry.name), depth + 1);
          } else if (entry.name.endsWith(".json")) {
            if (!entry.isFile())
              throw new Error("Invalid game record file.");
            const record = JSON.parse(await readFile2(join7(directory, entry.name), "utf8"));
            if (`${name(record.id)}.json` !== entry.name)
              throw new Error("Game ID does not match record file.");
            records.push(record);
          }
        }
      };
      await scan(join7(folder, "games"), 0);
      return JSON.stringify(records);
    },
    async readPlayers(folder) {
      const directory = join7(folder, "players");
      let entries;
      try {
        entries = await readdir2(directory, { withFileTypes: true });
      } catch (error) {
        if (error.code === "ENOENT")
          return "[]";
        throw error;
      }
      const players = await Promise.all(entries.filter((entry) => entry.name.endsWith(".json")).map(async (entry) => {
        if (!entry.isFile())
          throw new Error("Invalid player roster file.");
        const player = JSON.parse(await readFile2(join7(directory, entry.name), "utf8"));
        if (`${name(player.id)}.json` !== entry.name)
          throw new Error("Player ID does not match roster file.");
        return player;
      }));
      return JSON.stringify(players);
    }
  };
}

// app/updates/health.ts
async function acknowledgeStartup(root, hash, readable) {
  await readable();
  let journal;
  try {
    journal = JSON.parse(await readFile3(join8(root, "journal"), "utf8"));
  } catch (error) {
    if (error.code === "ENOENT")
      return;
    throw error;
  }
  const expected = journal.healthyHash ?? (["restored", "cancelled"].includes(journal.phase) ? journal.previous : journal.candidate);
  if (hash !== expected)
    throw new Error("Startup version does not match the update transaction.");
  await hostFiles(root, async () => "").writePrivate("health", JSON.stringify({ transaction: journal.transaction, hash, pid: process.pid }));
}

// app/desktop.ts
import { homedir as homedir5 } from "os";
import { join as join13 } from "path";
import { pathToFileURL } from "url";

// app/host-lifecycle.ts
class HostLifecycle {
  actions = new Set;
  operations = 0;
  failedWrites = new Map;
  writeNumber = 0;
  hosted = false;
  restarting = false;
  askingToQuit = false;
  changed;
  constructor(changed = () => {}) {
    this.changed = changed;
  }
  get canInstall() {
    return !this.hosted && !this.actions.size && !this.operations && !this.failedWrites.size && !this.restarting;
  }
  get canQuit() {
    return this.askingToQuit || !this.restarting && !this.actions.size && !this.operations && !this.failedWrites.size;
  }
  beginAction() {
    this.requireRunning();
    const id = crypto.randomUUID();
    this.actions.add(id);
    this.changed();
    return id;
  }
  endAction(id, hosted) {
    if (!this.actions.delete(id))
      throw new Error("Unknown host action.");
    this.hosted = hosted;
    this.changed();
  }
  async run(name, write, effect) {
    this.requireRunning();
    const attempt = ++this.writeNumber;
    this.operations++;
    this.changed();
    try {
      const result = await effect();
      if (write && (this.failedWrites.get(name) ?? 0) <= attempt)
        this.failedWrites.delete(name);
      return result;
    } catch (error) {
      if (write)
        this.failedWrites.set(name, Math.max(attempt, this.failedWrites.get(name) ?? 0));
      throw error;
    } finally {
      this.operations--;
      this.changed();
    }
  }
  async restart(prepare, ports) {
    if (!this.canInstall)
      throw new Error("Close the table and finish or retry pending saves before installing.");
    this.restarting = true;
    this.changed();
    let released = false;
    let prepared;
    try {
      prepared = await prepare();
      this.askingToQuit = true;
      let approved;
      try {
        approved = ports.approve();
      } finally {
        this.askingToQuit = false;
      }
      if (!approved)
        throw new Error("Restart cancelled. The update is still ready.");
      if (this.hosted || this.actions.size || this.operations || this.failedWrites.size)
        throw new Error("Table state changed. Try again from startup.");
      await ports.release();
      released = true;
      ports.quit();
    } catch (error) {
      try {
        await prepared?.cancel();
      } finally {
        ports.cancelApproval?.();
        if (released)
          await ports.recover?.();
        this.restarting = false;
        this.changed();
      }
      throw error;
    }
  }
  requireRunning() {
    if (this.restarting)
      throw new Error("Cardslop is restarting to install an update. Try again if restart is cancelled.");
  }
}

// app/update-menu.ts
import { readFile as readFile7 } from "fs/promises";
import { join as join12 } from "path";

// app/updates/updater.ts
import { createHash as createHash2 } from "crypto";
import { mkdir as mkdir4, mkdtemp, open as open2, readFile as readFile6, readdir as readdir4, rename as rename2, rm as rm4, stat as stat2, writeFile as writeFile2 } from "fs/promises";
import { basename, dirname as dirname5, join as join11 } from "path";

// app/updates/release.ts
import { createPublicKey, verify } from "crypto";
var signatureDomain = Buffer.from("cardslop-update-release-v1\x00");
var versionPattern = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
function compareVersions(a, b) {
  const left = a.split(".").map(BigInt), right = b.split(".").map(BigInt);
  for (let i = 0;i < 3; i++)
    if (left[i] !== right[i])
      return left[i] > right[i] ? 1 : -1;
  return 0;
}
function validateConfig(value) {
  const config = value;
  if (!config || Object.keys(config).sort().join() !== "feed,publicKey,release,schema,version" || config.schema !== 1 || !Number.isSafeInteger(config.release) || config.release < 1 || typeof config.version !== "string" || !versionPattern.test(config.version) || typeof config.publicKey !== "string")
    throw new Error("Invalid update configuration.");
  const url = new URL(config.feed);
  if (url.protocol !== "https:" && !(url.protocol === "http:" && ["127.0.0.1", "[::1]"].includes(url.hostname)) || url.username || url.password || url.hash || url.search || !url.pathname.endsWith("/index.json"))
    throw new Error("Invalid update feed.");
  const key = createPublicKey({ key: Buffer.from(config.publicKey, "base64"), type: "spki", format: "der" });
  if (key.asymmetricKeyType !== "ed25519")
    throw new Error("Expected an Ed25519 publisher key.");
  return { schema: 1, feed: url.href, publicKey: config.publicKey, release: config.release, version: config.version };
}
function authenticateRelease(envelope, config) {
  if (Buffer.byteLength(envelope) > 16384)
    throw new Error("Release metadata is too large.");
  const signed = JSON.parse(envelope);
  if (typeof signed.payload !== "string" || typeof signed.signature !== "string")
    throw new Error("Missing release signature.");
  const payload = Buffer.from(signed.payload, "base64"), signature = Buffer.from(signed.signature, "base64");
  const key = createPublicKey({ key: Buffer.from(config.publicKey, "base64"), type: "spki", format: "der" });
  if (signature.length !== 64 || !verify(null, Buffer.concat([signatureDomain, payload]), key, signature))
    throw new Error("Publisher signature rejected.");
  const release = JSON.parse(payload.toString("utf8"));
  if (JSON.stringify(release) !== payload.toString("utf8") || Object.keys(release).sort().join() !== "arch,archive,channel,identifier,inventory,platform,release,schema,version" || release.schema !== 1 || release.identifier !== "org.tomgreen.cardslop" || release.platform !== "macos" || release.arch !== "arm64" || release.channel !== "stable" || !Number.isSafeInteger(release.release) || release.release < 1 || typeof release.version !== "string" || !versionPattern.test(release.version))
    throw new Error("Release identity rejected.");
  for (const [artifact, extension, limit] of [[release.archive, "zip", 2147483648], [release.inventory, "json", 8388608]]) {
    if (!artifact || Object.keys(artifact).sort().join() !== "file,sha256,size" || !/^[a-f0-9]{64}$/.test(artifact.sha256) || artifact.file !== `${artifact.sha256}.${extension}` || !Number.isSafeInteger(artifact.size) || artifact.size < 1 || artifact.size > limit)
      throw new Error("Invalid release artifact.");
  }
  return release;
}

// app/updates/install.ts
import { chmod, copyFile as copyFile2, mkdir as mkdir3, readFile as readFile5, realpath, rm as rm3, writeFile } from "fs/promises";
import { dirname as dirname4, join as join10 } from "path";
import { homedir as homedir4 } from "os";
import { randomBytes as randomBytes4 } from "crypto";

// app/updates/recovery.ts
import { spawn as spawn2 } from "child_process";
import { copyFile, mkdir as mkdir2, readFile as readFile4, readdir as readdir3, rm as rm2 } from "fs/promises";
import { join as join9 } from "path";
import { homedir as homedir3, userInfo } from "os";
async function superviseReplacement(plan, planPath, helper, privateFolder) {
  const root = join9(plan.channel_root, "recovery");
  await mkdir2(root, { recursive: true, mode: 448 });
  try {
    await readFile4(join9(root, "journal"));
    throw new Error("An update is still being recovered. Reopen Cardslop before retrying.");
  } catch (error) {
    if (error.code !== "ENOENT")
      throw error;
  }
  for (const name of await readdir3(root))
    if (name.startsWith("process-"))
      await rm2(join9(root, name));
  const recovery = join9(root, "cardslop-recovery");
  const app2 = plan.app_bundle_path;
  const label = `org.tomgreen.cardslop.recovery.${plan.transaction_id}`;
  const plist = join9(homedir3(), "Library/LaunchAgents", `${label}.plist`);
  const domain = `gui/${userInfo().uid}`;
  const backup = `${app2}.recovery-${plan.transaction_id}`;
  const previous = JSON.parse(await readFile4(join9(app2, "Contents/Resources/version.json"), "utf8"));
  const journal = {
    transaction: plan.transaction_id,
    phase: "prepared",
    app: app2,
    backup,
    restore: `${app2}.restore-${plan.transaction_id}`,
    discard: `${app2}.failed-${plan.transaction_id}`,
    result: plan.result_path,
    stage: plan.staging_path,
    plan: planPath,
    helper,
    plist,
    label,
    privateFolder,
    channelRoot: plan.channel_root,
    previous: previous.hash,
    candidate: plan.hash,
    version: plan.version,
    parentProcess: await nativeIdentity(join9(app2, "Contents/Resources/cardslop-recovery"))
  };
  const cancel = async () => {
    await command("/bin/launchctl", ["bootout", `${domain}/${label}`]).catch(() => {});
    try {
      await command(recovery, ["--cancel", root]);
    } catch (error) {
      await command("/bin/launchctl", ["bootstrap", domain, plist]).catch(() => {});
      throw error;
    }
  };
  try {
    await copyFile(join9(app2, "Contents/Resources/cardslop-recovery"), recovery);
    const inventory = join9(root, "previous-inventory");
    await hostFiles(root, async () => "").writePrivate("previous-inventory", JSON.stringify(await bundleInventory(app2)));
    await command("/usr/bin/ditto", ["--rsrc", "--extattr", app2, backup]);
    await restoreBundleAttributes(backup, inventory);
    await command("/usr/bin/codesign", ["--verify", "--deep", "--strict", backup]);
    await command(recovery, ["--sync-backup", backup]);
    await mkdir2(join9(homedir3(), "Library/LaunchAgents"), { recursive: true, mode: 448 });
    await rm2(join9(root, "health"), { force: true });
    for (const name of ["native.log", "outcome"])
      await rm2(join9(root, name), { force: true });
    await hostFiles(root, async () => "").writePrivate("journal", JSON.stringify(journal));
    const plistJSON = join9(root, "agent");
    await hostFiles(root, async () => "").writePrivate("agent", JSON.stringify({
      Label: label,
      ProgramArguments: [recovery, "--supervise", root],
      RunAtLoad: true,
      KeepAlive: { SuccessfulExit: false },
      ThrottleInterval: 10,
      StandardErrorPath: join9(root, "supervisor.log")
    }));
    await command("/usr/bin/plutil", ["-convert", "xml1", "-o", plist, plistJSON]);
    await command("/bin/launchctl", ["bootstrap", domain, plist]);
    const deadline = Date.now() + 120000;
    while (Date.now() < deadline) {
      try {
        const result = JSON.parse(await readFile4(plan.result_path, "utf8"));
        if (!result.success)
          throw new Error("Native update verification failed. The update is still ready.");
      } catch (error) {
        if (error.code !== "ENOENT")
          throw error;
      }
      const output = await readFile4(join9(root, "native.log"), "utf8").catch(() => "");
      if (output.includes("Cardslop preflight authenticated"))
        return { cancel };
      await new Promise((resolve4) => setTimeout(resolve4, 100));
    }
    throw new Error("Update preparation timed out.");
  } catch (error) {
    const ownsJournal = await readFile4(join9(root, "journal"), "utf8").then((bytes) => JSON.parse(bytes).transaction === plan.transaction_id, () => false);
    if (ownsJournal)
      await cancel();
    else
      for (const path of [backup, plan.staging_path, planPath, helper])
        await rm2(path, { recursive: true, force: true });
    throw error;
  }
}
async function nativeIdentity(recovery) {
  return new Promise((resolve4, reject) => {
    const child = spawn2(recovery, ["--identity", String(process.pid)], { stdio: ["ignore", "pipe", "ignore"] });
    let output = "";
    child.stdout.on("data", (bytes) => {
      output += bytes;
    });
    child.once("error", reject);
    child.once("close", (code) => {
      try {
        if (code !== 0)
          throw new Error("Cannot identify update owner.");
        resolve4(JSON.parse(output));
      } catch (error) {
        reject(error);
      }
    });
  });
}

// app/updates/install.ts
async function prepareReplacement(ready, release, resources, privateFolder) {
  const app2 = await realpath(join10(resources, "../.."));
  if (app2.includes("/AppTranslocation/") || !app2.endsWith("/Cardslop.app"))
    throw new Error("Move Cardslop to its installation folder and reopen it before installing.");
  const version = JSON.parse(await readFile5(join10(app2, "Contents/Resources/version.json"), "utf8"));
  if (version.identifier !== release.identifier || version.channel !== release.channel)
    throw new Error("The installed app identity differs.");
  await command("/usr/bin/codesign", ["--verify", "--deep", "--strict", app2]);
  const root = join10(homedir4(), "Library/Application Support", release.identifier, "stable");
  await mkdir3(join10(root, "self-extraction"), { recursive: true, mode: 448 });
  const manager = join10(resources, "uninstall");
  await command(manager, ["--bootstrap-install", root, "--quiet"]);
  const registered = JSON.parse(await readFile5(join10(root, ".electrobun-uninstall.json"), "utf8"));
  if (registered.app_bundle_path !== app2 || registered.identifier !== release.identifier || registered.channel !== "stable")
    throw new Error("Unable to establish the installed app location.");
  const expanded = join10(ready, "expanded/Cardslop.app");
  await verifyBundle(expanded, join10(ready, "inventory.json"), release);
  const target = JSON.parse(await readFile5(join10(expanded, "Contents/Resources/version.json"), "utf8"));
  if (!/^[a-z0-9]{1,13}$/.test(target.hash))
    throw new Error("Unsupported native release hash.");
  const tar = join10(root, "self-extraction", `${target.hash}.tar`);
  await command("/usr/bin/tar", ["--format=pax", "--no-xattrs", "--no-mac-metadata", "-cf", tar, "-C", dirname4(expanded), "Cardslop.app"]);
  const recipe = join10(root, "self-extraction", `${target.hash}.recipe.json`);
  await command(manager, ["--cardslop-index-tar", tar, recipe]);
  const stage = `${app2}.prepared-${target.hash}`;
  await rm3(stage, { recursive: true, force: true });
  await mkdir3(stage, { mode: 448 });
  await command("/usr/bin/ditto", ["--rsrc", "--extattr", expanded, join10(stage, "Cardslop.app")]);
  await restoreBundleAttributes(join10(stage, "Cardslop.app"), join10(ready, "inventory.json"));
  await verifyBundle(join10(stage, "Cardslop.app"), join10(ready, "inventory.json"), release);
  await copyFile2(join10(ready, "release.json"), join10(root, "cardslop-release.json"));
  await copyFile2(join10(ready, "inventory.json"), join10(root, "cardslop-inventory.json"));
  const transaction = randomBytes4(16).toString("hex");
  const helper = join10(ready, `electrobun-update-${transaction}`);
  await copyFile2(manager, helper);
  await chmod(helper, 448);
  const plan = {
    schema_version: 2,
    transaction_id: transaction,
    identifier: release.identifier,
    channel: "stable",
    platform: "macos",
    arch: "arm64",
    version: release.version,
    hash: target.hash,
    channel_root: root,
    app_bundle_path: app2,
    staging_path: stage,
    recipe_path: recipe,
    recipe_sha256: await fileDigest(recipe),
    parent_pid: process.pid,
    result_path: join10(root, `.electrobun-update-${transaction}.result.json`)
  };
  await writeFile(join10(root, "self-extraction/.electrobun-prepared-update.json"), JSON.stringify(plan), { mode: 384 });
  await rm3(tar, { force: true });
  const planPath = join10(root, `.electrobun-update-${transaction}.json`);
  await writeFile(planPath, JSON.stringify(plan), { mode: 384, flag: "wx" });
  return superviseReplacement(plan, planPath, helper, privateFolder);
}

// app/updates/updater.ts
class ManualUpdater {
  config;
  selected;
  busy = false;
  ready;
  current = { status: "idle", message: "Check for Updates\u2026" };
  folder;
  changed;
  constructor(config, folder, changed = () => {}) {
    this.folder = folder;
    this.changed = changed;
    this.config = validateConfig(config);
  }
  get state() {
    return this.current;
  }
  get prepared() {
    return !!this.ready && !this.busy;
  }
  async restore() {
    if (this.busy || this.ready)
      return;
    this.busy = true;
    try {
      const name = JSON.parse(await readFile6(join11(this.folder, "ready.json"), "utf8"));
      if (typeof name !== "string" || !/^ready-\d+-[a-f0-9-]{36}$/.test(name))
        throw new Error("Invalid preparation path.");
      const folder = join11(this.folder, name);
      const envelope = await readFile6(join11(folder, "release.json"), "utf8");
      const release = authenticateRelease(envelope, this.config);
      if (release.release <= this.config.release || compareVersions(release.version, this.config.version) <= 0)
        return;
      const ready = { folder, envelope, release };
      await this.verifyReady(ready);
      this.ready = ready;
      this.set("ready", `Cardslop ${release.version} is ready to install.`, release.version);
    } catch (error) {
      if (error.code !== "ENOENT")
        this.set("error", "The saved update could not be verified. Choose Check for Updates\u2026 to try again.");
    } finally {
      this.busy = false;
    }
  }
  async prepareInstall(resources) {
    if (this.busy || !this.ready)
      throw new Error("No prepared update is ready.");
    this.busy = true;
    try {
      const ready = this.ready;
      try {
        await this.verifyReady(ready);
      } catch (error) {
        this.ready = undefined;
        this.selected = undefined;
        this.set("error", "The prepared update failed verification. Choose Check for Updates\u2026 to try again.");
        throw error;
      }
      return await prepareReplacement(ready.folder, ready.release, resources, dirname5(this.folder));
    } finally {
      this.busy = false;
    }
  }
  async verifyReady(ready) {
    const envelope = await readFile6(join11(ready.folder, "release.json"), "utf8");
    const release = authenticateRelease(envelope, this.config);
    if (envelope !== ready.envelope || release.release <= this.config.release || compareVersions(release.version, this.config.version) <= 0)
      throw new Error("The prepared release changed.");
    const accepted = authenticateRelease(await readFile6(join11(this.folder, "accepted.json"), "utf8"), this.config);
    if (JSON.stringify(accepted) !== JSON.stringify(release))
      throw new Error("A different release was accepted. Prepare it first.");
    for (const [name, artifact] of [["update.zip", release.archive], ["inventory.json", release.inventory]]) {
      const path = join11(ready.folder, name);
      if ((await stat2(path)).size !== artifact.size || await fileDigest(path) !== artifact.sha256)
        throw new Error("The prepared artifact changed.");
    }
    await verifyBundle(join11(ready.folder, "expanded/Cardslop.app"), join11(ready.folder, "inventory.json"), release);
  }
  async check() {
    if (this.busy)
      return;
    this.busy = true;
    this.selected = undefined;
    this.set("checking", "Checking for updates\u2026");
    try {
      await mkdir4(this.folder, { recursive: true, mode: 448 });
      const envelope = await this.fetchText(this.config.feed, 16384);
      const release = authenticateRelease(envelope, this.config);
      let previous;
      try {
        previous = authenticateRelease(await readFile6(join11(this.folder, "accepted.json"), "utf8"), this.config);
      } catch (error) {
        if (error.code !== "ENOENT")
          throw error;
      }
      if (release.release < this.config.release || compareVersions(release.version, this.config.version) < 0 || release.release === this.config.release && release.version !== this.config.version || release.release > this.config.release && compareVersions(release.version, this.config.version) <= 0 || previous && (release.release < previous.release || compareVersions(release.version, previous.version) < 0 || release.release > previous.release && compareVersions(release.version, previous.version) <= 0 || release.release === previous.release && JSON.stringify(release) !== JSON.stringify(previous)))
        throw new Error("An older or conflicting release was rejected.");
      const temporary = join11(this.folder, `accepted-${crypto.randomUUID()}.tmp`);
      try {
        await writeFile2(temporary, envelope, { mode: 384, flag: "wx" });
        await rename2(temporary, join11(this.folder, "accepted.json"));
      } finally {
        await rm4(temporary, { force: true });
      }
      if (release.release === this.config.release)
        this.set("up-to-date", "Cardslop is up to date.", release.version);
      else if (this.ready && JSON.stringify(this.ready.release) === JSON.stringify(release))
        this.set("ready", `Cardslop ${release.version} is ready to install.`, release.version);
      else {
        this.ready = undefined;
        this.selected = { envelope, release };
        this.set("available", `Cardslop ${release.version} is available.`, release.version);
      }
    } catch {
      this.set("error", "Unable to verify an update. Check your connection and try again.");
    } finally {
      this.busy = false;
    }
  }
  async download() {
    if (this.busy || !this.selected)
      return;
    this.busy = true;
    const selected = this.selected;
    this.set("downloading", `Downloading and verifying Cardslop ${selected.release.version}\u2026`, selected.release.version);
    let temporary;
    try {
      temporary = await mkdtemp(join11(this.folder, ".preparing-"));
      await this.downloadArtifact(selected.release.archive, join11(temporary, "update.zip"));
      await this.downloadArtifact(selected.release.inventory, join11(temporary, "inventory.json"));
      const expanded = join11(temporary, "expanded");
      await mkdir4(expanded, { mode: 448 });
      await command("/usr/bin/ditto", ["-x", "-k", join11(temporary, "update.zip"), expanded]);
      if ((await readdir4(expanded)).join() !== "Cardslop.app")
        throw new Error("Unexpected archive root.");
      await restoreBundleAttributes(join11(expanded, "Cardslop.app"), join11(temporary, "inventory.json"));
      await verifyBundle(join11(expanded, "Cardslop.app"), join11(temporary, "inventory.json"), selected.release);
      await writeFile2(join11(temporary, "release.json"), selected.envelope, { flag: "wx", mode: 384 });
      const ready = join11(this.folder, `ready-${selected.release.release}-${crypto.randomUUID()}`);
      await rename2(temporary, ready);
      temporary = undefined;
      const pointer = join11(this.folder, `ready-${crypto.randomUUID()}.tmp`);
      try {
        await writeFile2(pointer, JSON.stringify(basename(ready)), { flag: "wx", mode: 384 });
        await rename2(pointer, join11(this.folder, "ready.json"));
      } finally {
        await rm4(pointer, { force: true });
      }
      this.ready = { folder: ready, ...selected };
      this.set("ready", `Cardslop ${selected.release.version} is ready to install.`, selected.release.version);
    } catch {
      this.set("error", "The update could not be prepared. Choose Check for Updates\u2026 to try again.");
    } finally {
      if (temporary)
        await rm4(temporary, { recursive: true, force: true }).catch(() => {});
      this.busy = false;
    }
  }
  set(status, message, version) {
    this.current = Object.freeze({ status, message, ...version ? { version } : {} });
    this.changed(this.current);
  }
  async response(url) {
    const response = await fetch(url, { redirect: "error", cache: "no-store", signal: AbortSignal.timeout(120000) });
    if (!response.ok || !response.body)
      throw new Error("Update feed unavailable.");
    return response;
  }
  async fetchText(url, limit) {
    const response = await this.response(url), reader = response.body.getReader();
    const chunks = [];
    let size = 0;
    try {
      while (true) {
        const next = await reader.read();
        if (next.done)
          break;
        size += next.value.length;
        if (size > limit)
          throw new Error("Release metadata is too large.");
        chunks.push(next.value);
      }
      return Buffer.concat(chunks).toString("utf8");
    } finally {
      await reader.cancel();
    }
  }
  async downloadArtifact(artifact, path) {
    const url = new URL(artifact.file, this.config.feed);
    const response = await this.response(url.href), reader = response.body.getReader();
    const file = await open2(path, "wx", 384), hash = createHash2("sha256");
    let size = 0;
    try {
      while (true) {
        const next = await reader.read();
        if (next.done)
          break;
        size += next.value.length;
        if (size > artifact.size)
          throw new Error("Artifact size differs.");
        hash.update(next.value);
        let offset = 0;
        while (offset < next.value.length) {
          const { bytesWritten } = await file.write(next.value, offset, next.value.length - offset);
          if (!bytesWritten)
            throw new Error("Unable to store update.");
          offset += bytesWritten;
        }
      }
      if (size !== artifact.size || hash.digest("hex") !== artifact.sha256)
        throw new Error("Artifact digest differs.");
      await file.sync();
    } finally {
      await file.close();
      await reader.cancel();
    }
  }
}

// app/updates/automatic.ts
class AutomaticUpdates {
  timer;
  running;
  loading;
  updater;
  started = false;
  offered = false;
  installing = false;
  load;
  host;
  ports;
  constructor(load, host, ports) {
    this.load = load;
    this.host = host;
    this.ports = ports;
  }
  get restarting() {
    return this.installing;
  }
  start() {
    if (!this.started) {
      this.started = true;
      this.timer = setInterval(() => {
        this.check();
      }, 3600000);
      this.timer.unref?.();
    }
    return this.check();
  }
  stop() {
    clearInterval(this.timer);
    this.started = false;
  }
  check() {
    if (!this.running)
      this.running = this.run().finally(() => {
        this.running = undefined;
        this.refresh();
      });
    return this.running;
  }
  refresh() {
    this.ports.changed();
    if (this.started && !this.running && !this.offered && !this.installing && this.updater?.prepared && this.host.canInstall) {
      this.offered = true;
      this.restart(this.ports.offer);
    }
  }
  async restart(confirm) {
    if (this.installing || !this.updater?.prepared)
      return;
    this.installing = true;
    this.offered = true;
    this.ports.changed();
    try {
      if (await confirm())
        await this.ports.install();
    } catch (error) {
      this.ports.changed(error instanceof Error ? error.message : "Restart failed. The update is ready for retry.");
    } finally {
      this.installing = false;
      this.ports.changed();
    }
  }
  async run() {
    if (this.installing)
      return;
    try {
      if (!this.loading)
        this.loading = (async () => {
          const updater2 = await this.load();
          await updater2.restore();
          this.updater = updater2;
          return updater2;
        })();
      const updater = await this.loading;
      if (this.installing)
        return;
      await updater.check();
      if (updater.state.status === "available" && !updater.prepared)
        await updater.download();
    } catch {
      this.loading = undefined;
      this.ports.changed("Updates are not configured for this candidate. Try again with a configured release.");
    }
  }
}

// app/update-menu.ts
function installUpdateMenu(privateFolder, lifecycle, release, recover) {
  let updater;
  let state = { status: "idle", message: "Check for Updates\u2026" };
  const refresh = () => exports_ApplicationMenu.setApplicationMenu([
    { label: "Cardslop", submenu: [
      { label: "Check for Updates\u2026", action: "check-updates", enabled: !automatic.restarting && !["checking", "downloading"].includes(state.status) },
      ...state.status === "idle" ? [] : [{ label: state.message, enabled: false }],
      ...updater?.prepared ? [
        { label: "Restart to Install Update\u2026", action: "install-update", enabled: lifecycle.canInstall && !automatic.restarting },
        ...!lifecycle.canInstall && !automatic.restarting ? [{ label: "Close the table and finish pending saves to install.", enabled: false }] : []
      ] : [],
      { type: "separator" },
      { role: "quit" }
    ] },
    { label: "Edit", submenu: [
      { role: "undo" },
      { role: "redo" },
      { type: "separator" },
      { role: "cut" },
      { role: "copy" },
      { role: "paste" },
      { role: "selectAll" }
    ] }
  ]);
  const render = (next) => {
    state = next;
    refresh();
  };
  const automatic = new AutomaticUpdates(async () => {
    const config = JSON.parse(await readFile7(join12(exports_Paths.RESOURCES_FOLDER, "cardslop-update.json"), "utf8"));
    const version = JSON.parse(await readFile7(join12(exports_Paths.RESOURCES_FOLDER, "version.json"), "utf8"));
    if (version.identifier !== "org.tomgreen.cardslop" || version.channel !== "stable" || version.version !== config.version || process.platform !== "darwin" || process.arch !== "arm64")
      throw new Error("Unsupported update target.");
    updater = new ManualUpdater(config, join12(privateFolder, "updates"), render);
    return updater;
  }, lifecycle, {
    changed: (error) => {
      if (error)
        render({ status: updater?.prepared ? "ready" : "error", message: error });
      else
        refresh();
    },
    offer: async () => {
      const confirmed = await exports_Utils.showMessageBox({
        type: "question",
        title: "Cardslop update ready",
        message: `Cardslop ${state.version ?? "update"} is ready to install.`,
        detail: "Restart to install it now, or choose Later to keep using Cardslop. Your saved table and player data will be retained.",
        buttons: ["Later", "Restart and Install"],
        defaultId: 0,
        cancelId: 0
      });
      return confirmed.response === 1;
    },
    install: async () => {
      let approval = null;
      await lifecycle.restart(() => updater.prepareInstall(exports_Paths.RESOURCES_FOLDER), {
        approve: () => !!(approval = exports_Utils.requestQuitApproval()),
        release,
        quit: () => exports_Utils.quitAfterApproval(approval),
        recover,
        cancelApproval: () => {
          if (approval)
            exports_Utils.cancelQuitApproval(approval);
        }
      });
    }
  });
  refresh();
  readFile7(join12(privateFolder, "recovered-update"), "utf8").then(async (bytes) => {
    const recovered = JSON.parse(bytes);
    const version = JSON.parse(await readFile7(join12(exports_Paths.RESOURCES_FOLDER, "version.json"), "utf8"));
    if (version.version === recovered.version)
      return;
    render({ status: "error", message: `Cardslop recovered from an unsuccessful update to ${recovered.version}. Choose Check for Updates\u2026 to retry.` });
    return exports_Utils.showMessageBox({
      type: "info",
      title: "Cardslop recovered",
      message: "The update could not start safely. Your previous version has been restored.",
      detail: "Your saved table and player data have been kept. Choose Check for Updates\u2026 when you want to try again.",
      buttons: ["OK"],
      defaultId: 0
    });
  }).catch(() => {});
  exports_ApplicationMenu.on("application-menu-clicked", (event) => {
    const action = event.data?.action;
    if (action === "install-update")
      automatic.restart(async () => {
        const confirmed = await exports_Utils.showMessageBox({
          type: "question",
          title: "Install Cardslop update?",
          message: "Restart Cardslop to install the verified update?",
          detail: "Your saved table and player data will be retained.",
          buttons: ["Cancel", "Restart and Install"],
          defaultId: 0,
          cancelId: 0
        });
        return confirmed.response === 1;
      });
    if (action === "check-updates")
      automatic.check();
  });
  return { refresh: () => automatic.refresh(), start: () => automatic.start() };
}

// app/webkit.ts
import { dlopen as dlopen3, FFIType as FFIType3 } from "bun:ffi";
var objc = "/usr/lib/libobjc.A.dylib";
var id = FFIType3.u64;
var { sel_registerName, objc_getClass } = dlopen3(objc, {
  sel_registerName: { args: [FFIType3.ptr], returns: id },
  objc_getClass: { args: [FFIType3.ptr], returns: id }
}).symbols;
var message = (returns, ...args) => dlopen3(objc, { objc_msgSend: { args: [id, id, ...args], returns } }).symbols.objc_msgSend;
var send = message(id, id);
var sendBytes = message(id, FFIType3.ptr);
var sendInteger = message(id, FFIType3.i64);
var readInteger = message(FFIType3.i64);
var setArgument = message(FFIType3.void, FFIType3.ptr, FFIType3.i64);
var performOnMain = message(FFIType3.void, id, id, FFIType3.bool);
var text = (value) => Buffer.from(`${value}\x00`);
var selector = (name) => sel_registerName(text(name));
var objcClass = (name) => objc_getClass(text(name));
var WKInactiveSchedulingPolicyNone = 2;
var policyPath = () => sendBytes(objcClass("NSString"), selector("stringWithUTF8String:"), text("webView.configuration.preferences.inactiveSchedulingPolicy"));
function onMain(target, name, hasResult, ...args) {
  const invocation = send(objcClass("NSInvocation"), selector("invocationWithMethodSignature:"), send(target, selector("methodSignatureForSelector:"), selector(name)));
  send(invocation, selector("setSelector:"), selector(name));
  args.forEach((arg, index) => setArgument(invocation, selector("setArgument:atIndex:"), new BigUint64Array([arg]), index + 2));
  performOnMain(invocation, selector("performSelectorOnMainThread:withObject:waitUntilDone:"), selector("invokeWithTarget:"), target, true);
  const result = new BigUint64Array(1);
  if (hasResult)
    sendBytes(invocation, selector("getReturnValue:"), result);
  return result[0];
}
function nativeView(view) {
  const native3 = BigInt(view.ptr ?? 0);
  if (!native3 || !send(native3, selector("methodSignatureForSelector:"), selector("webView")))
    throw new Error("This Electrobun version does not expose its WKWebView.");
  return native3;
}
function inactiveSchedulingPolicy(view) {
  const value = onMain(nativeView(view), "valueForKeyPath:", true, policyPath());
  return value ? Number(readInteger(value, selector("integerValue"))) : -1;
}
async function createUnsuspendedView(url, options) {
  const view = new BrowserView({ ...options, url: null, html: null, renderer: "native" });
  for (let attempt = 0;inactiveSchedulingPolicy(view) < 0; attempt++) {
    if (attempt === 100)
      throw new Error("Electrobun did not build its WKWebView.");
    await new Promise((resolve4) => setTimeout(resolve4, 20));
  }
  onMain(nativeView(view), "setValue:forKeyPath:", false, sendInteger(objcClass("NSNumber"), selector("numberWithInteger:"), WKInactiveSchedulingPolicyNone), policyPath());
  if (inactiveSchedulingPolicy(view) !== WKInactiveSchedulingPolicyNone)
    throw new Error("WebKit did not accept the inactive scheduling policy.");
  view.loadURL(url);
  return view;
}

// app/desktop.ts
async function createHostWindow(privateFolder = join13(homedir5(), "Library/Application Support/Cardslop"), chooseFolder = async () => {
  const folders = await exports_Utils.openFileDialog({ canChooseFiles: false, canChooseDirectory: true, allowsMultipleSelection: false });
  return folders[0] ?? "";
}) {
  const app2 = join13(exports_Paths.RESOURCES_FOLDER, "../..");
  const recoveryHelper = join13(exports_Paths.RESOURCES_FOLDER, "cardslop-recovery");
  const hasRecovery = await access(recoveryHelper).then(() => true, (error) => {
    if (error.code === "ENOENT")
      return false;
    throw error;
  });
  if (hasRecovery)
    await command(recoveryHelper, ["--register", await realpath2(app2), String(process.pid)]);
  let release = await acquireHostLock(privateFolder);
  try {
    const backendUrl = pathToFileURL(join13(exports_Paths.RESOURCES_FOLDER, "app/scala/backend-fastopt/main.js")).href;
    const { createHostStorage } = await import(backendUrl);
    const storage = createHostStorage(hostFiles(privateFolder, chooseFolder));
    let refreshMenu = () => {};
    const lifecycle = new HostLifecycle(() => refreshMenu());
    const updates = installUpdateMenu(privateFolder, lifecycle, () => release(), async () => {
      release = await acquireHostLock(privateFolder);
    });
    refreshMenu = updates.refresh;
    main_default.events.on("before-quit", (event) => {
      if (!lifecycle.canQuit)
        event.response = { allow: false };
    });
    const run = (name, write, effect) => lifecycle.run(name, write, effect);
    const rpc = BrowserView.defineRPC({ handlers: { requests: {
      startupHealthy: async () => {
        await run("startupHealthy", false, async () => {
          const version = JSON.parse(await readFile8(join13(exports_Paths.RESOURCES_FOLDER, "version.json"), "utf8"));
          const root = join13(homedir5(), "Library/Application Support", version.identifier, "stable/recovery");
          await acknowledgeStartup(root, version.hash, async () => {
            const files = hostFiles(privateFolder, chooseFolder);
            for (const key of ["host-player", "private-table", "pending-results"]) {
              const value = await files.readPrivate(key);
              if (value)
                JSON.parse(value);
            }
            await storage.hostKey();
            await storage.recordsFolder();
          });
        });
        updates.start();
      },
      beginHostAction: () => lifecycle.beginAction(),
      endHostAction: ({ id: id2, hosted }) => lifecycle.endAction(id2, hosted),
      retryResults: () => run("retryResults", true, () => storage.retryResults()),
      statistics: ({ args }) => run("statistics", false, () => storage.statistics(...args)),
      privateTable: () => run("privateTable", false, () => storage.privateTable()),
      savePrivateTable: ({ args }) => run("savePrivateTable", true, () => storage.savePrivateTable(...args)),
      hostKey: () => run("hostKey", false, () => storage.hostKey()),
      saveHostKey: ({ args }) => run("saveHostKey", true, () => storage.saveHostKey(...args)),
      hostPlayer: () => run("hostPlayer", false, () => storage.hostPlayer()),
      saveHostPlayer: ({ args }) => run("saveHostPlayer", true, () => storage.saveHostPlayer(...args)),
      recordsFolder: () => run("recordsFolder", false, () => storage.recordsFolder()),
      chooseRecordsFolder: () => run("chooseRecordsFolder", true, () => storage.chooseRecordsFolder()),
      savePlayer: ({ args }) => run("savePlayer", true, () => storage.savePlayer(...args)),
      players: () => run("players", false, () => storage.players())
    }, messages: {} } });
    const window = new BrowserWindow({ title: "Cardslop", url: "about:blank", sandbox: true, frame: { width: 1000, height: 800 } });
    window.on("will-close", (event) => {
      if (!lifecycle.canQuit)
        event.response = { allow: false };
    });
    window.webview.remove();
    const view = await createUnsuspendedView("views://main/index.html", {
      windowId: window.id,
      partition: "persist:cardslop",
      rpc,
      frame: { x: 0, y: 0, width: 1000, height: 800 },
      autoResize: true
    });
    window.webviewId = view.id;
    rpc.setTransport({ ...view.createTransport(), send: (message2) => view.sendHostMessageToWebviewViaExecute(message2) });
    return window;
  } catch (error) {
    await release();
    throw error;
  }
}

// app/main.ts
await createHostWindow();
