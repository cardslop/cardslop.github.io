// .hutch/devkit/api/shared/rpc.ts
var MAX_ID = 10000000000;
var DEFAULT_MAX_REQUEST_TIME = 1000;
function missingTransportMethodError(methods, action) {
  const methodsString = methods.map((m) => `"${m}"`).join(", ");
  return new Error(`This RPC instance cannot ${action} because the transport did not provide one or more of these methods: ${methodsString}`);
}
function createRPC(options = {}) {
  let debugHooks = {};
  let transport = {};
  let requestHandler = undefined;
  function setTransport(newTransport) {
    if (transport.unregisterHandler)
      transport.unregisterHandler();
    transport = newTransport;
    transport.registerHandler?.(handler);
  }
  function setRequestHandler(h) {
    if (typeof h === "function") {
      requestHandler = h;
      return;
    }
    requestHandler = (method, params) => {
      const handlerFn = h[method];
      if (handlerFn)
        return handlerFn(params);
      const fallbackHandler = h._;
      if (!fallbackHandler)
        throw new Error(`The requested method has no handler: ${String(method)}`);
      return fallbackHandler(method, params);
    };
  }
  const { maxRequestTime = DEFAULT_MAX_REQUEST_TIME } = options;
  if (options.transport)
    setTransport(options.transport);
  if (options.requestHandler)
    setRequestHandler(options.requestHandler);
  if (options._debugHooks)
    debugHooks = options._debugHooks;
  let lastRequestId = 0;
  function getRequestId() {
    if (lastRequestId <= MAX_ID)
      return ++lastRequestId;
    return lastRequestId = 0;
  }
  const requestListeners = new Map;
  const requestTimeouts = new Map;
  const requestDeadlines = new Map;
  function startRequestTimeout(requestId, requestOptions) {
    const requestMaxRequestTime = requestOptions?.maxRequestTime ?? maxRequestTime;
    if (requestMaxRequestTime === Infinity || !requestListeners.has(requestId))
      return;
    requestDeadlines.set(requestId, performance.now() + requestMaxRequestTime);
    requestTimeouts.set(requestId, setTimeout(() => {
      requestTimeouts.delete(requestId);
      requestDeadlines.delete(requestId);
      const listener = requestListeners.get(requestId);
      requestListeners.delete(requestId);
      listener?.reject(new Error("RPC request timed out."));
    }, requestMaxRequestTime));
  }
  function rejectRequestSend(requestId, error) {
    const listener = requestListeners.get(requestId);
    if (!listener)
      return;
    requestListeners.delete(requestId);
    listener.reject(error instanceof Error ? error : new Error(String(error)));
  }
  function requestFn(method, ...args) {
    const params = args[0];
    const requestOptions = args[1];
    return new Promise((resolve, reject) => {
      if (!transport.send)
        throw missingTransportMethodError(["send"], "make requests");
      const requestId = getRequestId();
      const request2 = {
        type: "request",
        id: requestId,
        method,
        params
      };
      requestListeners.set(requestId, { resolve, reject });
      try {
        debugHooks.onSend?.(request2);
        const sendResult = transport.send(request2);
        if (sendResult && typeof sendResult.then === "function") {
          Promise.resolve(sendResult).then(() => startRequestTimeout(requestId, requestOptions), (error) => rejectRequestSend(requestId, error));
        } else {
          startRequestTimeout(requestId, requestOptions);
        }
      } catch (error) {
        rejectRequestSend(requestId, error);
      }
    });
  }
  const request = new Proxy(requestFn, {
    get: (target, prop, receiver) => {
      if (prop in target)
        return Reflect.get(target, prop, receiver);
      return (params, requestOptions) => requestFn(prop, params, requestOptions);
    }
  });
  const requestProxy = request;
  function sendFn(message, ...args) {
    const payload = args[0];
    if (!transport.send)
      throw missingTransportMethodError(["send"], "send messages");
    const rpcMessage = {
      type: "message",
      id: message,
      payload
    };
    debugHooks.onSend?.(rpcMessage);
    return transport.send(rpcMessage);
  }
  const send = new Proxy(sendFn, {
    get: (target, prop, receiver) => {
      if (prop in target)
        return Reflect.get(target, prop, receiver);
      return (payload) => sendFn(prop, payload);
    }
  });
  const sendProxy = send;
  const messageListeners = new Map;
  const wildcardMessageListeners = new Set;
  function addMessageListener(message, listener) {
    if (!transport.registerHandler)
      throw missingTransportMethodError(["registerHandler"], "register message listeners");
    if (message === "*") {
      wildcardMessageListeners.add(listener);
      return;
    }
    if (!messageListeners.has(message))
      messageListeners.set(message, new Set);
    messageListeners.get(message).add(listener);
  }
  function removeMessageListener(message, listener) {
    if (message === "*") {
      wildcardMessageListeners.delete(listener);
      return;
    }
    messageListeners.get(message)?.delete(listener);
    if (messageListeners.get(message)?.size === 0)
      messageListeners.delete(message);
  }
  async function handler(message) {
    debugHooks.onReceive?.(message);
    if (!("type" in message))
      throw new Error("Message does not contain a type.");
    if (message.type === "request") {
      if (!transport.send || !requestHandler)
        throw missingTransportMethodError(["send", "requestHandler"], "handle requests");
      const { id, method, params } = message;
      let response;
      try {
        response = {
          type: "response",
          id,
          success: true,
          payload: await requestHandler(method, params)
        };
      } catch (error) {
        if (!(error instanceof Error))
          throw error;
        response = {
          type: "response",
          id,
          success: false,
          error: error.message
        };
      }
      debugHooks.onSend?.(response);
      transport.send(response);
      return;
    }
    if (message.type === "response") {
      const timeout = requestTimeouts.get(message.id);
      if (timeout != null)
        clearTimeout(timeout);
      requestTimeouts.delete(message.id);
      const deadline = requestDeadlines.get(message.id);
      requestDeadlines.delete(message.id);
      const { resolve, reject } = requestListeners.get(message.id) ?? {};
      requestListeners.delete(message.id);
      if (deadline !== undefined && performance.now() >= deadline)
        reject?.(new Error("RPC request timed out."));
      else if (!message.success)
        reject?.(new Error(message.error));
      else
        resolve?.(message.payload);
      return;
    }
    if (message.type === "message") {
      for (const listener of wildcardMessageListeners)
        listener(message.id, message.payload);
      const listeners = messageListeners.get(message.id);
      if (!listeners)
        return;
      for (const listener of listeners)
        listener(message.payload);
      return;
    }
    throw new Error(`Unexpected RPC message type: ${message.type}`);
  }
  const proxy = { send: sendProxy, request: requestProxy };
  return {
    setTransport,
    setRequestHandler,
    request,
    requestProxy,
    send,
    sendProxy,
    addMessageListener,
    removeMessageListener,
    proxy
  };
}
function defineElectrobunRPC(_side, config) {
  const rpcOptions = {
    maxRequestTime: config.maxRequestTime,
    requestHandler: {
      ...config.handlers.requests,
      ...config.extraRequestHandlers
    },
    transport: {
      registerHandler: () => {}
    }
  };
  const rpc = createRPC(rpcOptions);
  const messageHandlers = config.handlers.messages;
  if (messageHandlers) {
    rpc.addMessageListener("*", (messageName, payload) => {
      const globalHandler = messageHandlers["*"];
      if (globalHandler) {
        globalHandler(messageName, payload);
      }
      const messageHandler = messageHandlers[messageName];
      if (messageHandler) {
        messageHandler(payload);
      }
    });
  }
  return rpc;
}

// .hutch/devkit/api/browser/index.ts
var WEBVIEW_ID = window.__electrobunWebviewId;
var HOST_SOCKET_PORT = window.__electrobunHostSocketPort ?? window.__electrobunRpcSocketPort;

class Electroview {
  hostSocket;
  hostSocketCanSend = false;
  pendingHostSocketMessages = [];
  flushingHostSocketMessages = false;
  hostSocketSendQueue = [];
  flushingHostSocketSendQueue = false;
  linuxHostSocketDispatchTail = Promise.resolve();
  rpc;
  rpcHandler;
  carrots = {
    invoke: (carrotId, method, params, options) => this.invokeCarrot(carrotId, method, params, options)
  };
  constructor(config) {
    this.rpc = config.rpc;
    this.init();
  }
  init() {
    this.initSocketToHost();
    const hostMessageHandler = this.receiveMessageFromHost.bind(this);
    window.__electrobun.receiveMessageFromHost = hostMessageHandler;
    window.__electrobun.receiveMessageFromBun = hostMessageHandler;
    if (this.rpc) {
      this.rpc.setTransport(this.createTransport());
    }
    const pendingMessages = window.__electrobunPendingHostMessages;
    if (pendingMessages?.length) {
      window.__electrobunPendingHostMessages = [];
      for (const message of pendingMessages) {
        hostMessageHandler(message);
      }
    }
  }
  initSocketToHost() {
    if (!HOST_SOCKET_PORT || !WEBVIEW_ID) {
      return;
    }
    const socket = new WebSocket(`ws://127.0.0.1:${HOST_SOCKET_PORT}/socket?webviewId=${WEBVIEW_ID}`);
    this.hostSocket = socket;
    socket.addEventListener("open", () => {
      this.hostSocketCanSend = true;
      this.flushPendingHostSocketMessages();
    });
    socket.addEventListener("message", async (event) => {
      const message = event.data;
      if (typeof message === "string") {
        try {
          const packet = JSON.parse(message);
          this.hostSocketCanSend = true;
          if (typeof packet?.encryptedData === "string" && typeof packet?.iv === "string" && typeof packet?.tag === "string") {
            if (window.__electrobunPlatform === "linux") {
              const decodedMessage = window.__electrobun_decrypt(packet.encryptedData, packet.iv, packet.tag).then((decrypted2) => JSON.parse(decrypted2));
              this.queueLinuxHostSocketDispatch(decodedMessage);
              return;
            }
            const decrypted = await window.__electrobun_decrypt(packet.encryptedData, packet.iv, packet.tag);
            this.rpcHandler?.(JSON.parse(decrypted));
          } else {
            this.rpcHandler?.(packet);
          }
        } catch (err) {
          console.error("Error parsing bun message:", err);
        }
      } else if (message instanceof Blob) {} else {
        console.error("UNKNOWN DATA TYPE RECEIVED:", event.data);
      }
    });
    socket.addEventListener("error", (event) => {
      this.hostSocketCanSend = false;
      console.error("Socket error:", event);
    });
    socket.addEventListener("close", (_event) => {
      this.hostSocketCanSend = false;
      this.flushHostMessagesViaFallback(this.pendingHostSocketMessages);
      this.flushHostMessagesViaFallback(this.hostSocketSendQueue);
    });
  }
  queueLinuxHostSocketDispatch(decodedMessage) {
    const settledMessage = decodedMessage.then((value) => ({ status: "fulfilled", value }), (reason) => ({ status: "rejected", reason }));
    this.linuxHostSocketDispatchTail = this.linuxHostSocketDispatchTail.then(async () => {
      const result = await settledMessage;
      if (result.status === "rejected") {
        console.error("Error parsing bun message:", result.reason);
        return;
      }
      this.rpcHandler?.(result.value);
    }).catch((err) => {
      console.error("Error parsing bun message:", err);
    });
  }
  createTransport() {
    const that = this;
    return {
      send(message) {
        try {
          const messageString = JSON.stringify(message);
          return that.sendMessageToHost(messageString);
        } catch (error) {
          console.error("host: failed to serialize message to webview", error);
        }
      },
      registerHandler(handler) {
        that.rpcHandler = handler;
      }
    };
  }
  sendMessageToHost(msg) {
    return new Promise((markSent) => {
      const queuedMessage = { message: msg, markSent };
      if (this.canSendToHostSocket()) {
        this.hostSocketSendQueue.push(queuedMessage);
        this.flushHostSocketSendQueue();
        return;
      }
      if (this.hostSocket?.readyState === WebSocket.CONNECTING) {
        this.pendingHostSocketMessages.push(queuedMessage);
        return;
      }
      this.sendMessageToHostViaFallback(queuedMessage);
    });
  }
  canSendToHostSocket() {
    return this.hostSocketCanSend && this.hostSocket?.readyState === WebSocket.OPEN;
  }
  async sendMessageToHostSocket(msg) {
    if (!this.canSendToHostSocket()) {
      return false;
    }
    try {
      if (window.__electrobunPlaintextHostSocket) {
        this.hostSocket.send(msg);
        return true;
      }
      const { encryptedData, iv, tag } = await window.__electrobun_encrypt(msg);
      const encryptedPacket = {
        encryptedData,
        iv,
        tag
      };
      const encryptedPacketString = JSON.stringify(encryptedPacket);
      this.hostSocket.send(encryptedPacketString);
      return true;
    } catch (error) {
      console.error("Error sending message to host via socket:", error);
      return false;
    }
  }
  sendMessageToHostViaFallback(queuedMessage) {
    try {
      window.__electrobunHostBridge?.postMessage(queuedMessage.message);
    } catch (error) {
      console.error("Error sending message to host via native bridge:", error);
    } finally {
      queuedMessage.markSent();
    }
  }
  flushHostMessagesViaFallback(queue) {
    while (queue.length > 0) {
      this.sendMessageToHostViaFallback(queue.shift());
    }
  }
  async flushHostSocketSendQueue() {
    if (this.flushingHostSocketSendQueue) {
      return;
    }
    this.flushingHostSocketSendQueue = true;
    try {
      while (this.hostSocketSendQueue.length > 0 && this.canSendToHostSocket()) {
        const queuedMessage = this.hostSocketSendQueue[0];
        this.hostSocketSendQueue.shift();
        if (!await this.sendMessageToHostSocket(queuedMessage.message)) {
          this.sendMessageToHostViaFallback(queuedMessage);
        } else {
          queuedMessage.markSent();
        }
      }
    } finally {
      this.flushingHostSocketSendQueue = false;
    }
  }
  async flushPendingHostSocketMessages() {
    if (this.flushingHostSocketMessages) {
      return;
    }
    this.flushingHostSocketMessages = true;
    try {
      while (this.pendingHostSocketMessages.length > 0) {
        const queuedMessage = this.pendingHostSocketMessages.shift();
        this.hostSocketSendQueue.push(queuedMessage);
      }
      await this.flushHostSocketSendQueue();
    } finally {
      this.flushingHostSocketMessages = false;
    }
  }
  receiveMessageFromHost(msg) {
    if (this.rpcHandler) {
      this.rpcHandler(msg);
    }
  }
  async invokeCarrot(carrotId, method, params, options) {
    const requestProxy = this.rpc?.request;
    if (!requestProxy || typeof requestProxy.invokeCarrot !== "function") {
      throw new Error("Renderer carrot invocation is not available in this Electrobun host.");
    }
    return requestProxy.invokeCarrot({
      carrotId,
      method,
      params,
      windowId: options?.windowId
    });
  }
  static defineRPC(config) {
    return defineElectrobunRPC("webview", {
      ...config,
      extraRequestHandlers: {
        evaluateJavascriptWithResponse: ({ script }) => {
          return new Promise((resolve) => {
            try {
              const resultFunction = new Function(script);
              const result = resultFunction();
              if (result instanceof Promise) {
                result.then((resolvedResult) => {
                  resolve(resolvedResult);
                }).catch((error) => {
                  console.error("bun: async script execution failed", error);
                  resolve(String(error));
                });
              } else {
                resolve(result);
              }
            } catch (error) {
              console.error("bun: failed to eval script", error);
              resolve(String(error));
            }
          });
        }
      }
    });
  }
}

// app/about.ts
function mountAbout(actions) {
  const element = (id) => document.getElementById(id);
  const check = element("check-updates");
  const install = element("install-update");
  const result = element("update-result");
  const title = element("update-title");
  const message = element("update-message");
  let state;
  let pending = false;
  let installing = false;
  let request = 0;
  function render() {
    if (!state)
      return;
    element("app-version").textContent = `Version ${state.version}`;
    element("app-channel").textContent = state.channel;
    element("app-build").textContent = state.build;
    const busy = pending || state.update.status === "checking" || state.update.status === "downloading";
    const status = pending && !["checking", "downloading"].includes(state.update.status) ? "checking" : state.update.status;
    const titles = {
      idle: "Keep CardSlop up to date",
      checking: "Checking for updates…",
      "up-to-date": "You’re up to date",
      available: "An update is available",
      downloading: "Preparing your update…",
      ready: "Your update is ready",
      error: "Update check failed"
    };
    title.textContent = titles[status];
    message.textContent = status === "idle" ? "Check for the latest version of CardSlop." : status === "checking" ? "Looking for the latest version of CardSlop…" : state.update.message;
    result.dataset.status = status;
    element("update-spinner").hidden = !busy;
    check.disabled = busy || installing || state.restarting;
    install.hidden = !state.prepared;
    install.disabled = busy || installing || !state.canInstall || state.restarting;
    install.textContent = installing || state.restarting ? "Restarting…" : "Restart and Install…";
    element("install-help").hidden = !state.prepared || state.canInstall || state.restarting;
  }
  async function refresh() {
    const current = ++request;
    try {
      const next = await actions.state();
      if (current !== request)
        return;
      state = next;
      render();
    } catch {
      if (current === request)
        showError("Unable to read update information. Please try again.", "Update information unavailable");
    }
  }
  function showError(detail, heading = "Unable to check for updates") {
    state = {
      version: "Unavailable",
      channel: "Unavailable",
      build: "Unavailable",
      prepared: false,
      canInstall: false,
      restarting: false,
      ...state,
      update: { status: "error", message: detail }
    };
    render();
    title.textContent = heading;
  }
  check.addEventListener("click", async () => {
    if (pending)
      return;
    pending = true;
    render();
    const minimum = new Promise((resolve) => setTimeout(resolve, 600));
    let failed = false;
    try {
      await actions.check();
    } catch {
      failed = true;
    }
    await minimum;
    pending = false;
    await refresh();
    if (failed)
      showError("Unable to contact the updater. Please try again.");
  });
  install.addEventListener("click", async () => {
    if (installing)
      return;
    installing = true;
    render();
    let failed = false;
    try {
      await actions.install();
    } catch {
      failed = true;
    } finally {
      installing = false;
      await refresh();
    }
    if (failed)
      showError("Unable to restart for the update. Please try again.", "Unable to install the update");
  });
  element("close-about").addEventListener("click", () => actions.close());
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape")
      actions.close();
  });
  refresh();
  return { refresh };
}

// app/about-view.ts
var about;
var rpc = Electroview.defineRPC({ handlers: { requests: {}, messages: {
  aboutChanged: () => {
    about?.refresh();
  }
} } });
new Electroview({ rpc });
about = mountAbout({
  state: () => rpc.request.aboutState({}),
  check: () => rpc.request.checkUpdates({}, { maxRequestTime: Infinity }),
  install: () => rpc.request.installUpdate({}, { maxRequestTime: Infinity }),
  close: () => rpc.send.closeAbout({})
});
